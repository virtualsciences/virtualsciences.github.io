from idland.settings import *
DEBUG=True
TEMPLATE_DEBUG=DEBUG
EMAIL_HOST='webmail.pareto.nl'
USER_ID = 'username'
