from django.core.urlresolvers import resolve
from urlparse import urlsplit
import datetime
import urllib


from idland.settingsimporter import settings_import
from django.conf import settings
User = settings_import(settings.USER)


def get_path(url):
    """Get the path of a given url."""
    return urlsplit(url).path

def get_uname(identity_url):
    """Get the django username given a identity url."""
    path = urlsplit(identity_url).path
    return urllib.unquote(resolve(path)[2]['username'])

def get_domain(request):
    """Gets the complete domain."""
    uri = request.build_absolute_uri()
    parsed = urlsplit(uri)
    domain = parsed.scheme + '://' + parsed.netloc
    return {'domain' : domain }

def strip_http(url):
    """Strips http[s]:// from a url."""
    parsed = urlsplit(url)
    return parsed.netloc + parsed.path

def get_url(url):
    """Get the url without postdata."""
    parsed = urlsplit(url)
    return parsed.scheme + '://' + parsed.netloc + parsed.path

def new_expiry_date():
    """Returns the new password expiry date."""
    return datetime.date.today() + datetime.timedelta(days=settings.EXPIRY_DAYS)

def get_user(username):
    """Get the User object according to the USER_ID setting."""

    if settings.USER_ID == 'email':
        try:
            user = User.objects.get(email__exact=username)
        except User.DoesNotExist:
            user = None

    elif settings.USER_ID == 'username':
        try:
            user = User.objects.get(username=username)
        except User.DoesNotExist:
            user = None

    else:
        # wrong value for settings.USER_ID
        raise ValueError('Invalid USER_ID in settings.')

    return user

