from django.contrib.auth import backends

from idland.settingsimporter import settings_import
from idland.utils import get_user

from django.conf import settings
User = settings_import(settings.USER)


class IDLandBackend(backends.ModelBackend):
    """Email and username backend.

    IDLandBackend gets the user from get_user. get_user
    knows if the USER_ID should be an emailaddress or an username."""

    def authenticate(self, username=None, password=None):
        user = get_user(username)
        if user:
            if user.check_password(password):
                return user
        return None
