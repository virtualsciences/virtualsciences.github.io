from django import template
from cgi import parse_qs
from urlparse import urlsplit
from exceptions import KeyError
from django.conf import settings

register = template.Library()

@register.tag
def get_consumer_domain(parser, token):
    try:
        tag_name = token.split_contents()
    except ValueError:
        raise template.TemplateSyntaxError , "%r tag requires no arguments" % \
                token.contents.split()[0]
    return GetConsumerDomain()

class GetConsumerDomain(template.Node):
    def __init__(self):
        pass
    def render(self, context):
        try:
            consumer_domain = parse_qs(urlsplit(context['next']).query)\
                ['openid.realm'][0]
            context['consumer_domain'] = consumer_domain
        except KeyError:
            pass
        return ''

@register.tag
def get_settings_user_id(parser, token):
    try:
        tag_name = token.split_contents()
    except ValueError:
        raise template.TemplateSyntaxError, "%r tag requires no arguments" % \
            token.contents.split()[0]
    return GetSettingsUserId()

class GetSettingsUserId(template.Node):
    def __init__(self):
        pass
    def render(self, context):
        try:
            USER_ID = settings.USER_ID
            context['user_id'] = USER_ID
        except KeyError:
            pass
        return ''
