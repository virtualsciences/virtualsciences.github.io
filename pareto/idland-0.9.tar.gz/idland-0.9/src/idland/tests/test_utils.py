import unittest
from idland.tests.base import OpenIDTestCase

class IDLandUtil(OpenIDTestCase):
    def setUp(self):
        super(IDLandUtil, self).setUp()

    def tearDown(self):
        super(IDLandUtil, self).tearDown()

    def test_get_path(self):
        from idland.utils import get_path
        url = 'http://example.com/some/path'
        path = get_path(url)
        self.failUnlessEqual(path, '/some/path')

    def test_get_uname(self):
        from idland.utils import get_uname
        url = 'http://testserver/roland'
        uname = get_uname(url)
        self.failUnlessEqual(uname, 'roland')

    def test_get_domain(self):
        from idland.utils import get_domain
        class request(object):
            def build_absolute_uri(self):
                return 'http://testserver/roland?some=get_data'
        host = get_domain(request())
        self.failUnlessEqual(host['domain'], 'http://testserver')

    def test_get_url(self):
        from idland.utils import get_url
        test_url = 'http://testserver/app/server?post=data'
        url = get_url(test_url)
        self.failUnlessEqual(url, 'http://testserver/app/server')

    def test_strip_http(self):
        from idland.utils import strip_http
        test_url = 'http://testserver/app/server?post=data'
        stripped = strip_http(test_url)
        self.failUnlessEqual(stripped, 'testserver/app/server')

    def test_new_expiry_date(self):
        from idland.utils import new_expiry_date
        expiry = new_expiry_date()
        import datetime
        from idland.settings import EXPIRY_DAYS
        new_date = datetime.timedelta(days=EXPIRY_DAYS) + \
                    datetime.date.today()
        self.failUnlessEqual(expiry, new_date)

def suite():
    s = unittest.TestSuite()
    ms = unittest.makeSuite
    s.addTest(ms(IDLandUtil))
    return s
