from django.contrib import admin
from django.views.generic.simple import direct_to_template
from django.conf.urls.defaults import *
from django.contrib.auth.views import password_reset_done, password_reset_complete
from django.conf import settings
from idland.admin import site

from idland.forms import SetExtendedPasswordForm
from idland.views.utils import direct_to_flatpage
import os.path

handler500 # Pyflakes

urlpatterns = patterns(
    'idland.views',
    url(r'^$', 'plone.multi_site_search',name="root"),
    (r'^app/admin/(.*)', site.root),
    url(r'^(?P<username>[\w\-\.\%@]*)$', 'provider.identity', name="identity"),
    url(r'^(?P<username>[\w\-\.\%@]*)/xrds$', 'provider.yadis_document',
        name="yadis"),
    url(r'^app/contact/$', 'user.contact', name="contact"),

    url(r'^app/search/(?P<query>.+)$', 'plone.multi_site_search',
        name="search"),

    # server specific stuff
    url(r'^app/server/$', 'provider.openid_provider', name="provider"),
    url(r'^app/login/$', 'auth.login',
            {'template_name': 'idland/login.html'}, "login"),
    url(r'^app/logout/$', 'auth.userlogout', name="logout"),


    # Change password
    url(r'^app/change_password/$', 'auth.password_change',
            {'template_name': 'idland/password_change.html',
            'post_change_redirect': '/app/password_change_succes'},
            "change_pw"),
    url(r'^app/expired_password/$', 'auth.password_change',
            {'template_name': 'idland/password_expired.html',
            'post_change_redirect': '/app/password_change_succes'},
            "expired_pw"),

    # Reset password by mail
    url(r'^app/password_reset/$', 'auth.password_reset',
        {'template_name': 'idland/password_reset.html',
         'email_template_name': 'idland/password_reset_email.html',
         'post_reset_redirect': '/app/password_reset_done'}, "reset_pw"),
    (r'^app/password_reset_done/$', password_reset_done,
            {'template_name': 'idland/password_reset_done.html'}),
    url(r'^app/password_reset_confirm/(?P<uidb36>[0-9A-Za-z]+)/(?P<token>.+)$',
            'auth.password_reset_confirm',
            {'template_name': 'idland/password_reset_confirm.html',
            'set_password_form': SetExtendedPasswordForm},
            "reset_confirm"),
    (r'^app/password_reset_complete/$', password_reset_complete,
            {'template_name': 'idland/password_reset_complete.html'}),

    # flatpages
    url(r'^app/login-help/$', direct_to_flatpage, name="login-help"),
    url(r'^app/faq/$', direct_to_flatpage, name = "faq"),

    # templates
    url(r'^app/password_change_succes/$', direct_to_template,
            {'template':'idland/password_change_succes.html'}),
    url(r'app/thanks/$', direct_to_template,
            {'template':'idland/thanks.html'}, 'thanks' ),

    # json
    (r'app/userlist/(?P<appname>.+)$', 'plone.userlist'),
)

urlpatterns += patterns(
    '',
    (r'^media/(?P<path>.*)$', 'django.views.static.serve',
     {'document_root': settings.MEDIA_ROOT}),
    )

urlpatterns += patterns(
    '',
    (r'^admin_media/(?P<path>.*)$', 'django.views.static.serve',
     {'document_root': os.path.join(os.path.dirname(admin.__file__), 'media')}),
    )
