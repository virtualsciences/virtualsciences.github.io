import urllib

from django.contrib.auth.views import redirect_to_login
from django.core.urlresolvers import reverse
from django.http import HttpResponseBadRequest, HttpResponse
from django.shortcuts import render_to_response
from django.template import RequestContext
from django.views.generic.simple import direct_to_template
from idland import models
from idland.utils import get_domain, get_uname, strip_http, get_user
from openid.extensions.ax import FetchRequest, FetchResponse
from openid.extensions.sreg import SRegRequest, SRegResponse
from openid.server.server import Server, ProtocolError
from openid.store.filestore import FileOpenIDStore


from idland.settingsimporter import settings_import
from django.conf import settings
User = settings_import(settings.USER)

class OpenIDProvider(object):

    def __call__(self, request):
        query = dict(request.POST.items() or request.GET.items())

        datapath = settings.OPENID_DATABASE

        domain = get_domain(request)['domain']
        path = reverse(self)
        url = domain + path

        oserver = Server(FileOpenIDStore(datapath),url)

        try:
            oquery =  oserver.decodeRequest(query)
        except ProtocolError, reason:
            return direct_to_template(request,
                'idland/endpoint.html', {'error': str(reason)})

        if oquery == None:
            return HttpResponseBadRequest()

        if oquery.mode in ('checkid_immediate', 'checkid_setup'):
            # We don't do checkid_setup.
            oquery.mode = 'checkid_immediate'
            app_allowed = False
            user = request.user
            if not user.is_authenticated():
                return redirect_to_login(request.get_full_path())

            elif user.is_active and \
                    user.identity == get_uname(oquery.identity):
                consumer_domain = strip_http(oquery.trust_root)
                app_allowed, app = self.application_authorization(user,
                                                               consumer_domain)
                # Logging
                models.UserLogEntry.objects.create(user = user,
                                                   application = app,
                                                   tried_app = consumer_domain,
                                                   logged_in = app_allowed)

                # Check if app is not None, because we want to check that
                # the application is an application of the organisation.
                if not app_allowed and app is not None:
                    return self.no_access(app, request)

            oresponse = oquery.answer(app_allowed)
            self.simple_registration(oquery, oresponse, user)

        else:
            oresponse = oserver.handleRequest(oquery)

        web_response = oserver.encodeResponse(oresponse)
        return self.openid_answer(web_response)

    def no_access(self, app, request):
        """Return an error app if the user can't login."""

        return render_to_response('idland/noaccess.html', { "app": app},
            context_instance=RequestContext(request))

    def simple_registration(self, oquery, oresponse, user):
        """Simple registration and Attribute Exchange support."""

        sreg_req = SRegRequest.fromOpenIDRequest(oquery)
        sreg_fields = sreg_req.allRequestedFields()
        user_p = user.get_profile()

        if sreg_fields:
            # Standard sreg fields
            user_data = { 'fullname': user.get_full_name(),
                          'email': user.email,
                          'country': getattr(user_p, 'country', '')
                          }

            not_used_fields = [i for i in user_data.keys()
                               if i not in sreg_fields]
            map(user_data.pop, not_used_fields)
            sreg_resp = SRegResponse.extractResponse(sreg_req, user_data)
            sreg_resp.toMessage(oresponse.fields)

        # Attribute exchange fields.
        freq = FetchRequest()
        fobj = freq.fromOpenIDRequest(oquery)

        if fobj:
            fresp = FetchResponse(fobj)
            for URI, field in settings.SREG_URIS:
                at = fobj.requested_attributes.get(URI, '')
                if at:
                    fresp.addValue(URI, getattr(user_p, field, ''))
            fresp.toMessage(oresponse.fields)

    def application_authorization(self, user, consumer_domain):
        """Check if user is authorized for given domain.

        Returns app_allowed which is boolean and app
        which is an database instance of the application
        """
        app_allowed = False
        app = None


        # Give acces if the app is not in the Application list.
        try:
            app = models.Application.objects.get(domain=consumer_domain)
        except models.Application.DoesNotExist:
            app_allowed=True
            return app_allowed, app

        # The app is in the Application list; check if the user has
        # access.
        try:
            app = user.get_profile().applications.get(domain=consumer_domain)
            app_allowed = True
        except models.Application.DoesNotExist:
            pass

        return app_allowed, app

    def openid_answer(self, web_response):
        """parse an openid webrespone to Django HttpResponse"""
        response = HttpResponse(web_response.body)
        response.status_code = web_response.code
        for key, value in web_response.headers.items():
            response[key] = value

        return response

openid_provider = OpenIDProvider()

def identity(request, username):
    identifier = urllib.unquote(username)
    openid_user = get_user(identifier)

    return render_to_response('idland/identity.html',
                              { "openid_user": openid_user},
                              context_instance=RequestContext(request))


def yadis_document(request, username):
    identifier = urllib.unquote(username)
    openid_user = get_user(identifier)

    return render_to_response('idland/xrds.xml',
                              {"openid_user" : openid_user },
                              mimetype='application/xml+rds',
                              context_instance=RequestContext(request))
