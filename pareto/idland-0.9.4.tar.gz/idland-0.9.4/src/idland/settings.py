import os
#from django.core.urlresolvers import reverse

PROJECT_DIR = os.path.dirname(__file__)

ADMINS = (
    # ('Your Name', 'your_email@domain.com'),
    ('Jeroen Vloothuis', 'jeroen.vloothuis@pareto.nl'),
    ('Jarno de Wit', 'jarno.de.wit@pareto.nl'),
    ('Roland van Laar', 'roland.van.laar@pareto.nl'),
)

MANAGERS = ADMINS

DATABASE_ENGINE = 'sqlite3'    # 'postgresql_psycopg2', 'postgresql', 'mysql', 'sqlite3' or 'oracle'.
DATABASE_NAME = os.path.join(os.path.dirname(PROJECT_DIR), 'var', 'idland.db')
DATABASE_USER = ''             # Not used with sqlite3.
DATABASE_PASSWORD = ''         # Not used with sqlite3.
DATABASE_HOST = ''             # Set to empty string for localhost. Not used with sqlite3.
DATABASE_PORT = ''             # Set to empty string for default. Not used with sqlite3.
OPENID_DATABASE= os.path.join(PROJECT_DIR, 'openid-store')
IDLAND_LOGFILE = os.path.join(os.path.dirname(PROJECT_DIR), 'var', 'idland.log')

TIME_ZONE = 'Europa/Amsterdam'

LANGUAGE_CODE = 'en-us'

# Absolute path to the directory that holds media.
# Example: "/home/media/media.lawrence.com/"
MEDIA_ROOT = os.path.join(os.path.dirname(__file__), 'media')

# URL that handles the media served from MEDIA_ROOT. Make sure to use a
# trailing slash if there is a path component (optional in other cases).
# Examples: "http://media.lawrence.com", "http://example.com/media/"
MEDIA_URL = '/media/'

# URL prefix for admin media -- CSS, JavaScript and images. Make sure to use a
# trailing slash.
# Examples: "http://foo.com/media/", "/media/".
ADMIN_MEDIA_PREFIX = '/admin_media/'

# Don't share this with anybody.
SECRET_KEY = 'g@c)@7&$e8umo4jobqfd#4yszz0ewu*i2l3k4#po43gy5+npi9'

MIDDLEWARE_CLASSES = (
    'django.middleware.common.CommonMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.transaction.TransactionMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.middleware.doc.XViewMiddleware',
    'django.contrib.flatpages.middleware.FlatpageFallbackMiddleware',
    'idland.middleware.UserExpiry',
)

ROOT_URLCONF = 'idland.urls'


INSTALLED_APPS = (
    'djcp',
    'sorl.thumbnail',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.admin',
    'django.contrib.webdesign',
    'django.contrib.sites',
    'django.contrib.flatpages',
    'django_extensions',
    'idland',
)

AUTHENTICATION_BACKENDS = ('idland.backends.IDLandBackend',)

TEMPLATE_LOADERS = (
    'django.template.loaders.filesystem.load_template_source',
    'django.template.loaders.app_directories.load_template_source',
)

TEMPLATE_CONTEXT_PROCESSORS = (
    'django.core.context_processors.auth',
    'django.core.context_processors.media',
    'idland.utils.get_domain',
)

TEMPLATE_DIRS = (
    os.path.join(os.path.dirname(__file__), "templates"),
)

SITE_ID = 1

AUTH_PROFILE_MODULE = 'idland.UserProfile'

LOGIN_URL = '/app/login/'
LOGIN_REDIRECT_URL = '/'

# User model specification
USER = 'django.contrib.auth.models:User'
USER_MANAGER = 'django.contrib.auth.models:UserManager'
USER_CREATION_FORM = 'idland.forms:UserCreationForm'
USER_CHANGE_FORM = 'idland.forms:UserChangeForm'

# specify email/username
USER_ID='email'

# Time to expiry passwords in days

EXPIRY_DAYS = 90

# specific email test settings
#EMAIL_HOST = 'spamfilter.proxsys.net'
#EMAIL_HOST = 'localhost'
DEFAULT_FROM_EMAIL = 'pareto@pareto.nl'
CONTACT_EMAIL = 'roland.van.laar@pareto.nl'

# password settings

# minimal password length
PASSWORD_LENGTH = 6
# maximum number a user can enter a wrong password
MAX_WRONG_PASSWORD = 3
# minimally 1 [0-9] character
DIGIT = True
# minimal 1 [a-zA-Z] character
ALPHA = True

#Secret for multi site search in plone sites.
MULTI_SITE_SEARCH_SECRET = 'ChangeThis'

APPLICATION_TYPES = (
    ('any', 'Any'),
    ('plone', 'Plone'),
    )
