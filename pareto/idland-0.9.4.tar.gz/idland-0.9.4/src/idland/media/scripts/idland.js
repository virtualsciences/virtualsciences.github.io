/**
 * myZeelandia
 *
g * version:   1.1
 * author:    Jarno de Wit, Roland van Laar
 * email:     Jarno.de.Wit@pareto.nl, Roland.van.Laar@pareto.nl
 * website:   ...
 * Some code based on http://www.learningjquery.com/2007/03/accordion-madness
 */


/* Open close elements */
$(document).ready(function() {
  $('div.content div.showhide> div').hide();
  $('div.content div.showhide> h3').click(function() {
	var $nextDiv = $(this).next();
	var $visibleSiblings = $nextDiv.siblings('div:visible');
	if ($visibleSiblings.length ) {
	  $visibleSiblings.slideUp('fast', function() {
		$nextDiv.slideToggle('fast');
	  });
	} else {
	   $nextDiv.slideToggle('fast');
	}
  });
});


// Hookup the actions for specific applications
$(document).ready(function() {
    // Plone applications have a true single-signon handler
    $('.application .plone').click(function() {
        // Post login parameters to Plone using an on-the-fly
        // generated form
        var domain = $(this).attr('href');
        var form = document.createElement("form");
	// unescape the '@' in the idetity
        var esc_id = identity.replace('%40', '@');
        form.setAttribute("method", "post");
        form.setAttribute("action", domain + "/login_form");

        function createHiddenField(name, value) {
            var hiddenField = document.createElement("input");
            hiddenField.setAttribute("type", "hidden");
            hiddenField.setAttribute("name", name);
            hiddenField.setAttribute("value", value);
            form.appendChild(hiddenField);
        }

        createHiddenField("form.submitted", "1");
        createHiddenField("came_from", domain);
        createHiddenField("__ac_identity_url", esc_id);

        document.body.appendChild(form);
        form.submit();
        return false;
    });
 });
