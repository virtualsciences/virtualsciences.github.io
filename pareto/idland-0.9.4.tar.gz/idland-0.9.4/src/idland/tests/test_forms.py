import unittest
from idland.tests.base import OpenIDTestCase

class UserCreationFormTest(OpenIDTestCase):
    """Test the User Creation Form."""

    def test_clean(self):
        from idland.forms import UserCreationForm
        data = { 'username':'bogus', 'email':'example@example.com',
                 'password1':'example', 'password2':'example'}
        form = UserCreationForm(data)
        self.assertTrue(form.is_valid())

    def test_create_user_two_times(self):
        from idland.forms import UserCreationForm
        email = 'example@example.com'
        data = { 'username':'bogus', 'email':email, 'password1':'example',
                 'password2':'example'}
        form = UserCreationForm(data)
        self.assertTrue(form.is_valid())
        user = form.save()
        self.assertEquals(user.email, email)
        form2 = UserCreationForm(data)
        self.failIf(form2.is_valid())

    def test_user_with_wrong_password(self):
        from idland.forms import UserCreationForm
        data = {'username': 'bogus', 'email':'example@example.com',
                'password1':'one', 'password2':'two'}
        form = UserCreationForm(data)
        self.failIf(form.is_valid())

def suite():
    s = unittest.TestSuite()
    ms = unittest.makeSuite
    s.addTest(ms(UserCreationFormTest))
    return s
