import py
here = py.magic.autopath().dirpath()
py.std.sys.path.append(str(here.dirpath()))

try:
    from templess.templess import *
    from templess.convert import *
    from templess.util import *
    from templess.parse import *
except ImportError:
    from templess import *
    from convert import *
    from util import *
    from parse import *

def test_start_node():
    node = elnode('foo', {'foo': 'bar'}, None)
    s = xmlgenerator(node)
    assert list(s._start_node(node, node.attrs, True)) == [
            '<foo foo="bar"', ' />']
    assert list(s._start_node(node, node.attrs, False)) == [
            '<foo foo="bar"', '>']

def test_handle_cond():
    node = templessnode('foo', {}, None, {})
    s = convertor(node)
    assert s._handle_cond(node, {})

    node = templessnode('foo', {}, None, {'cond': 'foo'})
    s = convertor(node)
    assert not s._handle_cond(node, {'foo': False})
    
    node = templessnode('foo', {}, None, {'cond': 'foo'})
    s = convertor(node)
    assert s._handle_cond(node, {'foo': True})

    node = templessnode('foo', {}, None, {'not': 'foo'})
    s = convertor(node)
    assert not s._handle_cond(node, {'foo': True})

    node = templessnode('foo', {}, None, {'not': 'foo'})
    s = convertor(node)
    assert s._handle_cond(node, {'foo': False})
    
    node = templessnode('foo', {}, None, {'cond': 'foo'})
    s = convertor(node)
    assert not s._handle_cond(node, {'foo': []})

def test_handle_cond_not_existing():
    node = templessnode('foo', {}, None, {'cond': 'foo'})
    s = convertor(node)
    assert not s._handle_cond(node, {})

    node = templessnode('foo', {}, None, {'not': 'foo'})
    s = convertor(node)
    assert s._handle_cond(node, {})

def test_get_content():
    node = templessnode('foo', {}, None, {})
    s = convertor(node)
    assert not s._get_content(node)
    
    node = templessnode('foo', {}, None, {'content': 'foo'})
    s = convertor(node)
    assert s._get_content(node) == 'foo'

def test_get_replace():
    node = templessnode('foo', {}, None, {})
    s = convertor(node)
    assert not s._get_replace(node)
    
    node = templessnode('foo', {}, None, {'replace': 'foo'})
    s = convertor(node)
    assert s._get_replace(node) == 'foo'

def test_basic_rendering():
    node = templessnode('foo', {}, None, {'content': 'bar'})
    s = xmlserializer(node)
    s.convert({'bar': 'baz'})
    ret = s.unicode()
    assert ret == u'<foo>baz</foo>'

def test_list_rendering():
    node = templessnode('foo', {}, None, {'content': 'bar'})
    s = xmlserializer(node)
    nodes = s.convert({'bar': ['1', '2']})
    ret1 = s._unicode(nodes[0])
    assert ret1 == '<foo>1</foo>'
    ret2 = s._unicode(nodes[1])
    assert ret2 == '<foo>2</foo>'

def test_entitizing():
    node = templessnode('foo', {}, None, {'content': 'bar'})
    s = xmlserializer(node)
    s.convert({'bar': 'x < 1'})
    ret = s.unicode()
    assert ret == '<foo>x &lt; 1</foo>'

def test_xmlstring():
    node = templessnode('foo', {}, None, {'content': 'bar'})
    s = xmlserializer(node)
    s.convert({'bar': xmlstring('<bar />')})
    ret = s.unicode()
    assert ret == '<foo><bar /></foo>'

def test_generator():
    def somegenerator():
        for x in [1, 2, 3]:
            yield x
    node = templessnode('foo', {}, None, {'content': 'bar'})
    s = xmlserializer(node)
    nodes = s.convert({'bar': somegenerator()})
    for i, n in enumerate(nodes):
        assert s._unicode(n) == '<foo>%s</foo>' % (i + 1,)

def test_list_of_dicts():
    node = templessnode('foo', {}, None, {'content': 'fooc'})
    # add some ignorable whitespace and some children
    textnode('   ', node)
    templessnode('bar', {}, node, {'content': 'barc'})
    templessnode('baz', {}, node, {'content': 'bazc'})
    s = xmlserializer(node)
    nodes = s.convert(
        {'fooc': [
            {'barc': 'r1', 'bazc': 'z1'},
            {'barc': 'r2', 'bazc': 'z2'},
        ]}
    )
    print repr(nodes)
    assert s._unicode(nodes[0]) == u'<foo>   <bar>r1</bar><baz>z1</baz></foo>'
    assert s._unicode(nodes[1]) == u'<foo>   <bar>r2</bar><baz>z2</baz></foo>'

def test_dict():
    node = templessnode('foo', {}, None, {'content': 'fooc'})
    templessnode('bar', {}, node, {'content': 'barc'})
    templessnode('baz', {}, node, {'content': 'bazc'})
    s = xmlserializer(node)
    # shouldn't this return a single node instead?
    nodes = s.convert({'fooc': {'barc': 'r1', 'bazc': 'z1'}})
    print repr(nodes)
    assert s._unicode(nodes[0]) == u'<foo><bar>r1</bar><baz>z1</baz></foo>'

def test_basic_attrs():
    node = templessnode('foo', {}, None, {'attr': 'value bar'})
    s = xmlserializer(node)
    node = s.convert({'bar': 'baz'})
    assert s.unicode() == '<foo value="baz" />'

def test_attr_basic():
    node = templessnode('foo', {}, None, {'attr': 'bar baz'})
    s = xmlserializer(node)
    s.convert({'baz': 'qux'})
    assert s.unicode() == u'<foo bar="qux" />'

def test_attr_false():
    node = templessnode('foo', {}, None, {'attr': 'bar baz'})
    s = xmlserializer(node)
    s.convert({'baz': False})
    assert s.unicode() == u'<foo />'

def test_attr_remove_xmlns():
    py.test.skip('done by parser nowadays - write test there')
    node = templessnode('foo', {'xmlns:t': 'foo'}, None, 't')
    s = xmlserializer(node)
    s.convert({})
    assert s.unicode() == u'<foo />'

def test_attr_remove_xmlns_leave_other():
    node = templessnode('foo', {'xmlns:q': 'foo'}, None, {})
    s = xmlserializer(node)
    s.convert({})
    assert s.unicode() == u'<foo xmlns:q="foo" />'

def test_attr_false_empty_string():
    node = templessnode('foo', {}, None, {'attr': 'bar baz'})
    s = xmlserializer(node)
    s.convert({'baz': ''})
    assert s.unicode() == u'<foo bar="" />'

def test_attr_false_replacing():
    node = templessnode('foo', {'bar': 'baz'}, None, {'attr': 'bar baz'})
    s = xmlserializer(node)
    s.convert({'baz': False})
    assert s.unicode() == u'<foo />'

def test_list_with_attrs():
    # XXX not entirely sure about this behaviour yet...
    node = templessnode(
        'foo', {}, None, {'content': 'bar', 'attr': 'value baz'})
    s = xmlserializer(node)
    nodes = s.convert({'baz': 'top', 'bar': [{'baz': 1}, {'baz': 2}]})
    assert len(nodes) == 2
    assert s._unicode(nodes[0])  == u'<foo value="top" />'
    assert s._unicode(nodes[1])  == u'<foo value="top" />'

def test_cdata():
    node = cdatanode(' foo ', None)
    s = xmlserializer(node)
    assert s.unicode() == u'<![CDATA[ foo ]]>'

def test_find():
    '<foo><bar1><baz><bar2><bar4 /></bar2></baz></bar1><bar3 /></foo>'
    foo = elnode('foo', {}, None)
    bar1 = elnode('bar', {'id': "bar1"}, foo)
    baz = elnode('baz', {}, bar1)
    bar2 = elnode('bar', {'id': "bar2"}, baz)
    bar3 = elnode('bar', {'id': "bar3"}, foo)
    bar4 = elnode('bar', {'id': "bar4"}, bar2)

    ids = [el.attrs['id'] for el in list(foo.find('bar'))]
    assert ids == ['bar1', 'bar2', 'bar4', 'bar3']

class container(object):
    def __init__(self, **kwargs):
        self.__dict__.update(kwargs)

def test_objectcontext_regular():
    c = container(foo=1)
    assert str(c.foo) == '1'
    py.test.raises(TypeError, "c['foo']")

    oc = objectcontext(c)
    assert str(oc['foo']) == '1'
    py.test.raises(KeyError, "oc['bar']")

def test_objectcontext_dict():
    oc = objectcontext({'foo': 1})
    assert str(oc['foo']) == '1'

def test_objectcontext_nested():
    ci = container(bar=1)
    c = container(foo=ci)
    oc = objectcontext(c)
    assert str(oc['foo']['bar']) == '1'

def test_objectcontext_callable():
    c = container(foo=lambda: 1)
    oc = objectcontext(c)
    assert str(oc['foo']) == '1'

def test_objectcontext_nested_list():
    c = container(foo=[container(bar=1), container(bar=2)])
    oc = objectcontext(c)
    for i, item in enumerate(oc['foo']):
        assert isinstance(item, objectcontext)
        assert str(item['bar']) == str(i+1)

def test_objectcontext_nested_iterable():
    c = container(foo=(container(bar=x) for x in [1, 2]))
    oc = objectcontext(c)
    for i, item in enumerate(oc['foo']):
        assert isinstance(item, objectcontext)
        assert str(item['bar']) == str(i+1)

def test_generate():
    t = template('<foo xmlns:t="http://johnnydebris.net/xmlns/templess" '
                 't:content="foo" />')
    ret = ''
    i = 0
    for chunk in t.generate({'foo': 'bar'}):
        i += 1
        ret += chunk
    assert i > 1
    assert ret == ('<foo>bar</foo>')

def test_generate_list():
    t = template(
        '<foo xmlns:t="http://johnnydebris.net/xmlns/templess" '
        't:content="bar" />')
    ret = ''.join(list(t.generate({'bar': [1, 2]})))
    assert ret == '<foo>1</foo><foo>2</foo>'

def test_generate_singleton():
    t = template(
        '<foo xmlns:t="http://johnnydebris.net/xmlns/templess">'
        '<bar t:content="bar" /></foo>')
    ret = ''.join(list(t.generate({'bar': []})))
    assert ret == '<foo />'

def test_generate_cond():
    t = template(
        '<foo xmlns:t="http://johnnydebris.net/xmlns/templess">'
        '<bar t:cond="baz" /></foo>')
    ret = ''.join(list(t.generate({'baz': True})))
    assert ret == '<foo><bar /></foo>'
    ret = ''.join(list(t.generate({'baz': False})))
    assert ret == '<foo />'      

def test_generate_not():
    t = template(
        '<foo xmlns:t="http://johnnydebris.net/xmlns/templess">'
        '<bar t:not="baz" /></foo>')
    ret = ''.join(list(t.generate({'baz': True})))
    assert ret == '<foo />'      
    ret = ''.join(list(t.generate({'baz': False})))
    assert ret == '<foo><bar /></foo>'

def test_generate_content_list_of_dicts():
    t = template(
        '<foo xmlns:t="http://johnnydebris.net/xmlns/templess">'
        '<bar t:content="spam"><baz t:content="eggs" /></bar></foo>')
    ret = ''.join(list(t.generate(
        {'spam': [{'eggs': 'foo'}, {'eggs': 'bar'}]})))
    assert ret == (
        '<foo><bar><baz>foo</baz></bar><bar><baz>bar</baz></bar></foo>')

def test_generate_replace_list_of_dicts():
    t = template(
        '<foo xmlns:t="http://johnnydebris.net/xmlns/templess">'
        '<bar t:replace="spam"><baz t:content="eggs" /></bar></foo>')
    ret = ''.join(list(t.generate(
        {'spam': [{'eggs': 'foo'}, {'eggs': 'bar'}]})))
    assert ret == (
        '<foo><baz>foo</baz><baz>bar</baz></foo>')

def test_generate_list_of_dicts_replace_inner():
    t = template(
        '<foo xmlns:t="http://johnnydebris.net/xmlns/templess">'
        '<bar t:content="spam"><baz t:replace="eggs" /></bar></foo>')
    ret = ''.join(list(t.generate(
        {'spam': [{'eggs': 'foo'}, {'eggs': 'bar'}]})))
    assert ret == (
        '<foo><bar>foo</bar><bar>bar</bar></foo>')

def test_generate_content_dict():
    t = template('<foo xmlns:t="http://johnnydebris.net/xmlns/templess">'
                 '<bar t:content="spam"><baz t:content="eggs" /></bar></foo>')
    ret = ''.join(list(t.generate({'spam': {'eggs': 'eggs'}})))
    assert ret == '<foo><bar><baz>eggs</baz></bar></foo>'

def test_generate_replace_dict():
    t = template('<foo xmlns:t="http://johnnydebris.net/xmlns/templess">'
                 '<bar t:replace="spam"><baz t:replace="eggs" /></bar></foo>')
    ret = ''.join(list(t.generate({'spam': {'eggs': 'eggs'}})))
    assert ret == '<foo>eggs</foo>'

def test_generate_html_non_singletons():
    t = template(
        '<html xmlns:t="http://johnnydebris.net/xmlns/templess">'
        '<body><textarea t:content="foo" /></body></html>')
    html = ''.join(list(t.generate({'foo': None}, True)))
    assert html == '<html><body><textarea></textarea></body></html>'

def test_generate_html_singleton():
    t = template(
        '<html xmlns:t="http://johnnydebris.net/xmlns/templess">'
        '<body><hr t:content="foo" /></body></html>')
    html = ''.join(list(t.generate({'foo': 'bar'}, True)))
    assert html == '<html><body><hr>bar</hr></body></html>'
    html = ''.join(list(t.generate({'foo': None}, True)))
    assert html == '<html><body><hr /></body></html>'

def test_generate_html_singleton_non_templess_el():
    t = template('<html><body><hr /></body></html>')
    s = xmlgenerator(t.tree)
    s.convert({})
    html = ''.join(list(s.generate(True)))
    assert html == '<html><body><hr /></body></html>'
    t = template('<html><body><hr>bar</hr></body></html>')
    html = ''.join(list(t.generate({}, True)))
    assert html == '<html><body><hr>bar</hr></body></html>'

def test_elnode_repr():
    node = elnode('bar', {}, None)
    s = xmlserializer(node)
    xml = s.unicode()
    assert xml == '<bar />'

def test_templessnode_repr():
    node = templessnode('bar', {}, None, {})
    s = xmlserializer(node)
    s.convert({})
    xml = s.unicode()
    assert xml == '<bar />'

def test_unicode_noxmlns():
    t = template('<foo />')
    s = xmlserializer(t)
    s.convert({})
    xml = s.unicode()
    assert xml == '<foo />'

def test_html_output():
    t = template('<html><body><textarea></textarea></body></html>')
    s = xmlserializer(t)
    s.convert({})
    xml = s.unicode()
    assert xml == u'<html><body><textarea /></body></html>'
    html = t.unicode({}, html=True)
    assert html == u'<html><body><textarea></textarea></body></html>'
    html = ''.join(list(t.generate({}, html=True)))
    assert html == u'<html><body><textarea></textarea></body></html>'

def test_str_subclass_is_str():
    class mystr(str):
        pass
    node = templessnode('foo', {}, None, {'content': 'bar'})
    s = xmlserializer(node)
    s.convert({'bar': mystr('baz')})
    assert s.unicode() == u'<foo>baz</foo>'

def test_force_str():
    node = templessnode('foo', {}, None, {'content': 'bar:str'})
    s = xmlserializer(node)
    s.convert({'bar': ['baz']})
    assert s.unicode() == u'<foo>%s</foo>' % (['baz'],)

def test_force_iter():
    node = templessnode('foo', {}, None, {});
    templessnode('bar', {}, node, {'content': 'bar:iter'})
    s = xmlserializer(node)
    s.convert({'bar': 'baz'})
    assert s.unicode() == u'<foo><bar>b</bar><bar>a</bar><bar>z</bar></foo>'

def test_force_ctx():
    class myctx(object):
        def __getitem__(self, name):
            if name == 'spam':
                return 'eggs'
            raise KeyError(name)
    node = templessnode('foo', {}, None, {'content': 'bar:ctx'});
    templessnode('bar', {}, node, {'content': 'spam'})
    s = xmlserializer(node)
    nodes = s.convert({'bar': myctx()})
    assert s._unicode(nodes[0]) == u'<foo><bar>eggs</bar></foo>'
