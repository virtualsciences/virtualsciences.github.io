import templess
import nanosax

XMLNS = 'http://johnnydebris.net/xmlns/templess'

# nanosax handler
class treebuilderhandler(nanosax.nshandler):
    """ nanosax handler to convert XML to a node tree
    """
    def __init__(self, charset):
        self.charset = charset

    def startdoc(self):
        self.current = None
        self.root = None
        self.templess_prefix = None
        self.prefix_stack = []

    def enddoc(self):
        pass

    def startel(self, name, attrs):
        if self.prefix_stack:
            prefixes = list(self.prefix_stack[-1])
        else:
            prefixes = []
        cleanattrs = {}
        for key, value in attrs.iteritems():
            if key.startswith('xmlns') and value == XMLNS:
                pname = ''
                if ':' in key:
                    pname = key.split(':')[1]
                if pname not in prefixes:
                    prefixes.append(pname)
            else:
                cleanattrs[key] = value
        self.prefix_stack.append(tuple(prefixes))

        directives = {}
        attrs = {}
        for key, value in cleanattrs.iteritems():
            if ((':' in key and key.split(':')[0] in prefixes) or
                    (':' not in key and '' in prefixes)):
                # templess directive
                directives[key.split(':')[-1]] = value
            else:
                attrs[key] = value

        self.current = templess.templessnode(
            name, attrs, self.current, directives, self.charset)
        if self.root is None:
            self.root = self.current

    def endel(self, name):
        self.prefix_stack.pop()
        self.current = self.current.parent

    def text(self, text):
        templess.textnode(text, self.current, self.charset)

    def comment(self, text):
        templess.commentnode(text, self.current, self.charset)

    def cdata(self, text):
        templess.cdatanode(text, self.current, self.charset)

def parse_from_xml(data, charset):
    """ convert XML to a templess node tree
    """
    handler = treebuilderhandler(charset)
    parser = nanosax.nsparser(handler)
    parser.parse(data)
    return handler.root
