from Products.Five import BrowserView
from pareto.googlecse.cse import search, xml2loh

class CseView(BrowserView):

    def search(self, url_f_lenght = 0):
        enc_params = self.request.get('enc_params')
        q = self.request.get('q')
        if not q and not enc_params:
            return None
        xml = search(q, enc_params)
        return xml2loh(xml, url_f_lenght)

    def name(self):
        return 'Search results'
