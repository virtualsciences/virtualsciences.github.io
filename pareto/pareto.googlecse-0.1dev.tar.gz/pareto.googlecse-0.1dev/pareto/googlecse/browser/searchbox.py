from plone.app.layout.viewlets import ViewletBase
from Products.Five.browser.pagetemplatefile import ViewPageTemplateFile


class SearchBoxViewlet(ViewletBase): 
    render = ViewPageTemplateFile('searchbox.pt') 
