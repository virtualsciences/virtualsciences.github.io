from zope.formlib import form
from zope.i18nmessageid import MessageFactory
from plone.app.controlpanel.form import ControlPanelForm
from pareto.googlecse.interfaces import IGoogleCSEConfiguration

_ = MessageFactory('pareto.googlecse')

class GoogleCSEConfigurationForm(ControlPanelForm):
    form_fields = form.Fields(IGoogleCSEConfiguration)

    label = _(u"Google CSE Configuration")
    description = _("Enter the Google CSE Code you got from Google when you created your search engine")
    form_name = 'google-cse-config'
