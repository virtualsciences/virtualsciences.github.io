from zope.interface import Interface
from zope import schema
from zope.i18nmessageid import MessageFactory

_ = MessageFactory('pareto.googlecse')

class IGoogleCSEConfiguration(Interface):
    """This interface defines the configlet."""

    google_cse_code = schema.TextLine(title=_(u"Enter the google CSE code"),
                                  required=True) 

