from interfaces import IGoogleCSEConfiguration
from config import GoogleCSEConfiguration

def setupVarious(context):

    # This step is called for every profile that is installed
    # the check for this .txt file ensures that only in the right context
    # the code is executed.

    if context.readDataFile('pareto.googlecse_various.txt') is None:
        return

    site = context.getSite()
    setup_site(site)

def setup_site(portal):
    sm = portal.getSiteManager()
    name = 'googlecse-config'

    # XXX There is a problem here. Because of the way
    # the quickinstaller works, local utils are always removed
    # so you lose you settings on every quickinstall.

    if not sm.queryUtility(IGoogleCSEConfiguration, name=name):
        sm.registerUtility(GoogleCSEConfiguration(), IGoogleCSEConfiguration,
                       name)
