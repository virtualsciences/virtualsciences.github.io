from zope.interface import implements
from zope.schema.fieldproperty import FieldProperty
from interfaces import IGoogleCSEConfiguration
from OFS.SimpleItem import SimpleItem
from zope.component import getUtility


def form_adapter(context):
    return getUtility(IGoogleCSEConfiguration, name='googlecse-config', context=context)


class GoogleCSEConfiguration(SimpleItem):
    implements(IGoogleCSEConfiguration)
    
    google_cse_code = FieldProperty(IGoogleCSEConfiguration['google_cse_code'])

