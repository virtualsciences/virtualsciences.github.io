import urllib
import elementtree.ElementTree as ET
from zope.component import getSiteManager
from interfaces import IGoogleCSEConfiguration

def search(q, enc_params=None, url=None):
    '''Searches Google CSE'''

    sm = getSiteManager()
    gcse_util = sm.queryUtility(IGoogleCSEConfiguration, name='googlecse-config')
    google_cse_code = gcse_util.google_cse_code

    if enc_params is None:
        params = dict(
            start=0,
            num=10,
            q=q,
            client='google-csbe',
            output='xml_no_dtd',
            cx=google_cse_code)
        enc_params = '/cse?%s' % urllib.urlencode(params)

# cx='004868723732947806371:mc-rqeyw5ey')
    if url is None:
        url = 'http://www.google.com'

    f = urllib.urlopen('%s%s' % (url, enc_params))
    return f.read()

def xml2loh(xml, url_f_length):
    '''Converts Google CSE into a list of Hashes'''

    result = {}
    tree = ET.fromstring(xml)

    q = tree.find('Q').text
    res = tree.find('RES')
    if res is None:
        return None
    start = res.get('SN')
    end = res.get('EN')
    count = res.find('M').text

    result['q'] = q
    result['start'] = start
    result['end'] = end
    result['count'] = count

    nb = res.find('NB')
    if nb:
        prev_url = nb.find('PU')
        next_url = nb.find('NU')
        if prev_url is not None:
            result['prev_url'] = prev_url.text
        if next_url is not None:
            result['next_url'] = next_url.text

    results_info = []
    results = tree.find('RES')
    for r in results.findall('R'):
        mimetype = r.get('MIME')
        has = r.find('HAS')
        c = has.find('C')
        # XXX attribute sometimes does not exist !
        size = ''
        if c is not None:
            size = c.get('SZ')
        info = dict(title=r.find('T').text,
                    summary=remove_break(r.find('S').text),
                    url=r.find('U').text,
                    size=size)
        if url_f_length:
            info['url_f'] = add_break(r.find('U').text, url_f_length)
        results_info.append(info)

    result['results'] = results_info 
    return result

def add_break(text, url_f_length):
    text_f = []
        
    while len(text)>url_f_length:
        index = url_f_length + 1
        try:
            index = text.rindex('/', 0, url_f_length) + 1
        except ValueError:
            pass
        text_f.append(text[:index])
        text = text[index:]    
    text_f.append(text)
    
    return '<br />'.join(text_f)

def remove_break(text):
    return text.replace('<br>', '').replace('<br />', '')
    
    
