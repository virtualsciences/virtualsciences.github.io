Running funkload tests
----------------------

To run the funkload tests you must execute them from within the directory where they live (IOW inside the directory this README is located). I.e like so::

  ../../../bin/fl-run-test test_Viewboard.py
