Overview

  Ploneboard is an easy to use web board. It uses the proven Plone user
  interface, and is made for easy integration into Plone sites. The target
  audience is businesses and developers wanting a discussion board in their
  Plone site.

  Visit "Ploneboard":http://plone.org/products/ploneboard in the Products
  area on plone.org for more.

  Ploneboard is sponsored by "the Consumer Council of
  Norway":http://www.forbrukerradet.no, "Marshall Mayer, 
  LiveModern":http://livemodern.com and various generous contributors
  
  See CREDITS.txt for credits.
  
  See INSTALL.txt for requirements and installation instructions.
