pareto.deadfiles
================

Find and fix dead links and files that are not linked to within a Plone site.


Questions, remarks, etc.
------------------------

For questions, remarks, etc. send a mail to guido.wesdorp at pareto dot nl.
