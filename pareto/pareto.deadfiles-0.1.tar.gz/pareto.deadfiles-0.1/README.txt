pareto.deadfiles
================

Find all files to which there are no links anywhere in the Plone HTML.


Questions, remarks, etc.
------------------------

For questions, remarks, etc. send a mail to guido.wesdorp at pareto dot nl.
