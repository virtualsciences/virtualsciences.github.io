from zope.i18nmessageid import MessageFactory
TTMF = MessageFactory('pareto.portlet.twittertimeline')


def initialize(context):
    """Initializer called when used as a Zope 2 product."""
