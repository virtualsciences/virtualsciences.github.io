Introduction
============
The pareto.portlet.twittertimeline portlet uses the Twitter Timeline widget, 
created with the online generator, and it's Customization options.

You need to create a Twitter Timeline Widget on your twitter profile to use for
the portlet creation.

