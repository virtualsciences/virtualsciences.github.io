Introduction
============

This package provides solr search functionality.

The module pareto.solr.solr is almost a straight copy of
the solr.py module provided by SOLR itself, with some slight enhancements.

In the module pareto.solr.solr there is a SolrConnection class that
can be used to initiate a connection with the SOLR searchengine.

In the module search.py there is a function 'solr_search'.
It needs the following parameters:

- connection: a SolrConnection object.
- stored_indices: a LoL with info about the indices that are store
  stored means that SOLR return the values when a search is done.
  The LoL is a list of index_type, index_id pairs. E.g.:
  (('str', 'id'), ('str', 'title_nl'), ...)
- params: this is a dictionary with the SOLR search parameters:
  e.g. {'q': 'text_nl': 'Chemistry'}

The function returns a tuple with the following info:

- num_found: the number of found records or document
- docs: a LoH with the values of the stored_indices, if available!
  e.g. [{'id': '1', 'title_nl': 'PhD Economy', ... }, {...}, ...]
- tree: the lxml tree representing the xml that SOLR returned,
  this can be used for further processing (e.g. extract faceting information).

A typical way to use this module::

    from pareto.solr import solr
    from pareto.solr import search

    # Create a connection
    connection = solr.SolrConnection()
    stored_indices = (('str', 'id'), ('str', 'title_en')) 
    params = dict(q='Chemistry')
    num_found, docs, tree = \
        search.solr_search(connection, stored_indices, params)
    print num_found
    print docs
    



