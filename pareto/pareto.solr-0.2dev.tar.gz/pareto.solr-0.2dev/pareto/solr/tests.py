import unittest
import mock
from pareto.solr import search

class SolrTestCase(unittest.TestCase):

    def setUp(self):
        self.connection = mock.Mock(methods=['search'])

    def test_search_ids(self):
        self.connection.search.return_value = '''
        <response>
            <result name="response" numFound="3">
                <doc>
                    <str name="id">1</str>
                </doc>
                <doc>
                    <str name="id">5</str>
                </doc>
                <doc>
                    <str name="id">7</str>
                </doc>
            </result>
        </response>
        '''
        stored_indices = (('str', 'id'),)
        num_found, docs, tree = \
            search.solr_search(self.connection, stored_indices, {})
        self.assertEquals(num_found, '3')
        self.assertEqual(docs,  [{'id': '1'}, {'id': '5'}, {'id': '7'}])

    def test_search_titles(self):
        self.connection.search.return_value = '''
        <response>
            <result name="response" numFound="3">
                <doc>
                    <str name="id">1</str>
                    <str name="title_nl">Research Analyst</str>
                </doc>
                <doc>
                    <str name="id">5</str>
                    <str name="title_nl">PhD English literature</str>
                </doc>
                <doc>
                    <str name="id">7</str>
                    <str name="title_nl">Full Professor Chemistry</str>
                </doc>
            </result>
        </response>
        '''
        stored_indices = (('str', 'id'),('str', 'title_nl'))
        num_found, docs, tree = \
            search.solr_search(self.connection, stored_indices, {})
        docs = [doc['title_nl'] for doc in docs]
        docs.sort()
        self.assertEqual(docs[0], 'Full Professor Chemistry')


    def test_missing_indices(self):
        self.connection.search.return_value = '''
        <response>
            <result name="response" numFound="3">
                <doc>
                    <str name="id">1</str>
                    <str name="title_nl">Research Analyst</str>
                </doc>
                <doc>
                    <str name="id">5</str>
                    <str name="title_nl">PhD English literature</str>
                </doc>
                <doc>
                    <str name="id">7</str>
                    <str name="title_nl">Full Professor Chemistry</str>
                </doc>
            </result>
        </response>
        '''
        stored_indices = (
            ('str', 'id'),
            ('str', 'title_nl'), 
            ('str', 'title_en')
        )
        # Should not barf
        num_found, docs, tree = \
            search.solr_search(self.connection, stored_indices, {})

def suite():
    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(SolrTestCase))
    return suite

