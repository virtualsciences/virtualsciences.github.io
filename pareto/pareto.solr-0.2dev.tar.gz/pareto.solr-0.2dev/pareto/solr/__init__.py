from solr import SolrConnection, SolrException

SolrConnection # pyflakes
SolrException # pyflakes
