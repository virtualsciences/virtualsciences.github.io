from Products.CMFPlone.utils import ToolInit
from Products.Compass.compasstool import CompassTool
from Products.CMFCore import utils, DirectoryView

from Products.Compass.config import *


def initialize(context):
    # initialize tree management tool
    utils.ToolInit(TOOL_NAME,
                   tools=[CompassTool],
                   icon='compass.gif').initialize( context )
