from Products.CMFCore.CMFCorePermissions import AddPortalContent
from Products.Archetypes.public import DisplayList

ADD_CONTENT_PERMISSION = AddPortalContent
PROJECTNAME = "PloneLocalFolderNG"
SKINS_DIR = 'skins'

GLOBALS = globals()


