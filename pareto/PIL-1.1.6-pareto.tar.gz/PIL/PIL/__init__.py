#
# The Python Imaging Library.
# $Id: __init__.py,v 1.1.1.1 2007/09/26 00:00:35 chrism Exp $
#
# package placeholder
#
# Copyright (c) 1999 by Secret Labs AB.
#
# See the README file for information on usage and redistribution.
#

# ;-)
