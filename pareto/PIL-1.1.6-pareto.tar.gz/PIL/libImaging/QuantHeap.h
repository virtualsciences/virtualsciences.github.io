/*
 * The Python Imaging Library
 * $Id: QuantHeap.h,v 1.1.1.1 2007/09/26 00:00:34 chrism Exp $
 *
 * image quantizer
 *
 * Written by Toby J Sargeant <tjs@longford.cs.monash.edu.au>.
 *
 * See the README file for information on usage and redistribution.
 */

#ifndef __HEAP_H__
#define __HEAP_H__

#include "QuantTypes.h"

void ImagingQuantHeapFree(Heap);
int ImagingQuantHeapRemove(Heap,void **);
int ImagingQuantHeapAdd(Heap,void *);
int ImagingQuantHeapTop(Heap,void **);
Heap *ImagingQuantHeapNew(HeapCmpFunc);

#endif
