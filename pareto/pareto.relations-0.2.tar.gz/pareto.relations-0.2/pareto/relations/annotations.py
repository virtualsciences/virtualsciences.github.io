from zope.interface import implements
from zope.component import adapts
from pareto.relations import interfaces as pareto_interfaces
from zope.app.annotation.interfaces import IAnnotations
from persistent.mapping import PersistentMapping
from persistent.list import PersistentList
from Products.ATContentTypes.interface.interfaces import IATContentType

ANNOTATIONS_KEY = 'pareto.relationship.relation_annotations'

class OrderAnnotationsAdapter(object):
    implements(pareto_interfaces.IOrderedRelationship)
    adapts(IATContentType)
    def __init__(self, src):
        self.annotations = IAnnotations(src).setdefault(ANNOTATIONS_KEY,
                                                        PersistentMapping())
        order = self.annotations.setdefault('order', PersistentMapping())
        self.relation_type = None

    def add_item(self, item):
        if self.relation_type is None:
            raise KeyError
        order_for_relation = self.annotations['order'].setdefault(self.relation_type, PersistentList())
        # we do not want to duplicate ids.
        if item in order_for_relation:
            return
        order_for_relation.append(item)

    def remove_item(self, item):
        if self.relation_type is None:
            raise KeyError
        order_for_relation = self.annotations['order'].setdefault(self.relation_type, PersistentList())
        try:
            order_for_relation.remove(item)
        except ValueError:
            pass

    def remove_item_for_all_categories(self, item):
        order = self.annotations['order']
        for category in order:
            try:
                order[category].remove(item)
            except ValueError:
                pass

    def _get_order(self):
        if self.relation_type is None:
            raise KeyError
        order_for_relation = self.annotations['order'].setdefault(self.relation_type, PersistentList())
        return order_for_relation
    order = property(_get_order)

