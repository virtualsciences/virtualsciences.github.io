from plone.app.relations.interfaces import IRelationshipSource
from zope.interface import alsoProvides
from zope.app.annotation.interfaces import IAttributeAnnotatable
from plone.relations.interfaces import IComplexRelationship
from pareto.relations import interfaces as pareto_interfaces
from plone.app.relations import interfaces
from zope.component import getUtility
from zope.app.intid.interfaces import IIntIds

def removeFromOrderOnTargetDelete(rel, event):
    '''Removes the order from the source '''
    intids_util = getUtility(IIntIds)
    target_intid = intids_util.getId(event.target)
    sources = tuple(rel.sources)
    if sources:
        ob = sources[0].aq_base
        orderer = pareto_interfaces.IOrderedRelationship(ob)
        orderer.relation_type = IComplexRelationship(rel).relation 
        orderer.remove_item(target_intid)
