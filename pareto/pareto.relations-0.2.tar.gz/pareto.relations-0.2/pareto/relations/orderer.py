from pareto.relations.interfaces import IOrderable, IOrderedRelationship
from zope.component import adapts
from zope.interface import implements

class RelationsOrderer(object):
    '''Adapter to have an ordered relationship.'''
    implements(IOrderable)
    adapts(IOrderedRelationship)

    def __init__(self, rel):
        self.rel = rel

    def moveObjUp(self, object_intid):
        ''' Object is moved up. '''
        self._moveObj(object_intid, -1, 1)
     
    def setOrder(self, ordering):
        ''' Objects are reorganized '''
        order = self.rel.order
        zipped = zip(ordering, order)
        zipped.sort()
        order[:] = [intid for o, intid in zipped]

    def moveObjDown(self, object_intid):
        ''' Object is moved down. '''
        self._moveObj(object_intid, 0, 2)
   
    def _moveObj(self, object_intid, left, right):
        ''' Object is moved down. '''
        order = self.rel.order
        try:
            idx = order.index(object_intid)  
        except ValueError:
            return
        order[idx+left:idx+right] = reversed(order[idx+left:idx+right])
