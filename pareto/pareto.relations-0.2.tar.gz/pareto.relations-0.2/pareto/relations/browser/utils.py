from Products.CMFCore.utils import getToolByName
from Products.Five import BrowserView
from zope.app.intid.interfaces import IIntIds
from zope.component import getUtility

class RegisterIntidsView(BrowserView):
        
    def __call__(self):
        portal_catalog = getToolByName(self.context, 'portal_catalog')
        intids_util = getUtility(IIntIds)
        brains = portal_catalog()
        res = ['The following objects have been registered:']
        res.append('-' * len(res[0]))
        for b in brains:
            try:
                object = b.getObject()
                intids_util.getId(object)
            except KeyError:
                intids_util.register(object)
                res.append(b.getURL())
        return '\n'.join(res)

