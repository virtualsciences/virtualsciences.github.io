from zope import interface
from zc.relationship.interfaces import IRelationship
from zope.app.annotation.interfaces import IAnnotatable

class IOrderedRelationship(IRelationship):
    '''We add the Order aspect to a relationship.
    '''

    order = interface.Attribute("The list of intids representing the order.")

    def add_item(self, item):
        '''Add an item to the order on the relationship'''

    def remove_item(self, item):
        '''Removed an item from the order on the relationship'''
    
    def remove_item_for_all_categories(self, item):
        '''Removed an item from all categories in the order on the relationship'''

class IAnnotationsOrder(IAnnotatable):

    """Implies that the relationship order should be stored in an annotation"""

class IOrderable(interface.Interface):

    def moveObjUp(object_intid):
        ''' Object is moved up. '''
    
    def moveObjDown(object_intid):
        ''' Object is moved down. '''

    def setOrder(object_intids, ordering):
        ''' Reset the ordering for all objects at one.
            Usefull for a base-bones UI'''

class IRelationsView(interface.Interface):
    '''Viewclass to support the use of pareto.relations.'''

    def addRelation(intid, category):
        '''Add indicated intid. to relationships'''

    def moveRelationUp(intid, category):
        '''Moves the indicated intidect one position up.'''

    def moveRelationDown(intid, category):
        '''Moves the indicated intidect one position down.'''

    def setOrder(ordering, category):
        '''Set the ordering for the intidects from a list of integers. Useful for UI.'''

    def deleteRelation(intid, category):
        '''Deletes the indicated relation.'''

    def getRelations(intid, category):
        '''Deletes the indicated relation.'''
