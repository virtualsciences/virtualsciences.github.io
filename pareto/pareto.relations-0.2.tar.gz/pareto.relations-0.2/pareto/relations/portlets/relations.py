"""Define a portlet used to show relations. This follows the patterns from
plone.app.portlets.portlets. Note that we also need a portlet.xml in the
GenericSetup extension profile to tell Plone about our new portlet.
"""

import random

from zope import schema
from zope.component import queryMultiAdapter
from zope.formlib import form
from zope.interface import implements

from plone.app.portlets.portlets import base
from plone.memoize.instance import memoize
from plone.portlets.interfaces import IPortletDataProvider

from Acquisition import aq_inner
from Products.Five.browser.pagetemplatefile import ViewPageTemplateFile

from Products.CMFCore.utils import getToolByName

# Maybe add translations later
#from optilux.cinemacontent import CinemaMessageFactory as _

# This interface defines the configurable options (if any) for the portlet.
# It will be used to generate add and edit forms.

class IRelationsPortlet(IPortletDataProvider):
    pass
    
#    relations_node = schema.TextLine(title= u'Name of arboreal node',
#                       description=u'Name of the arboreal node that holds relations categories',
#                       required=True,
#                       default=u'relations')
                       

# The assignment is a persistent object used to store the configuration of
# a particular instantiation of the portlet.

class Assignment(base.Assignment):
    implements(IRelationsPortlet)

    def __init__(self, relations_node=u'relations'):
        self.relations_node = relations_node

    @property
    def title(self):
        return u"Relations"

# The renderer is like a view (in fact, like a content provider/viewlet). The
# item self.data will typically be the assignment (although it is possible
# that the assignment chooses to return a different object - see 
# base.Assignment).

class Renderer(base.Renderer):

    # render() will be called to render the portlet
    
    render = ViewPageTemplateFile('relations.pt')
       
    # The 'available' property is used to determine if the portlet should
    # be shown.
        
    @property
    def available(self):
        context = aq_inner(self.context)
        relations_view = queryMultiAdapter((context, self.request), name=u'relations')
        return relations_view and relations_view.hasRelations() or False

    # To make the view template as simple as possible, we return dicts with
    # only the necessary information.

    def relations(self):
        return self._data()
        
        
#   maybe memoize is not a good idea, relations are context specific
    def _data(self):
        context = aq_inner(self.context)
        relations_view = queryMultiAdapter((context, self.request), name=u'relations')
        if not relations_view:
            return []
        return relations_view.getRelations()
        

class AddForm(base.NullAddForm):

    def create(self):
        return Assignment()
    
