The pareto.relations package
============================

We are using the plone.app.relations package to implement a relations engine.
Every source can have one or more relation. However, there should always be
only one target.

The order of the annotation is stored on the source of the relation using
AnnotationStorage. There is an adapter that can adapt the source object for this.

The 'relation' attribute that is stored on the relation is used to categorize
the relations.

    >>> from pareto.relations.tests import test_zope3_doctest
    >>> test_zope3_doctest.setUp(app)

    >>> from plone.app.relations import interfaces
    >>> from zope.interface.verify import verifyObject
    >>> from zope.interface import directlyProvides, alsoProvides
    >>> from zope.app.annotation.interfaces import IAttributeAnnotatable
    >>> from pareto.relations import interfaces as pareto_interfaces
    >>> ob1 = app['ob1']
    >>> ob2 = app['ob2']
    >>> ob4 = app['ob4']
    >>> source = interfaces.IRelationshipSource(ob1)
    >>> verifyObject(interfaces.IRelationshipSource, source)
    True    
    >>> alsoProvides(ob1, IAttributeAnnotatable)

Very important to assign the correct interfaces to the relationship.
Doing that, the right adapters are found.

    >>> relation_type = u'relation 1'
    >>> rel = source.createRelationship((ob2,), relation=relation_type, 
    ...     interfaces=(IAttributeAnnotatable,))
    >>> from zope.component import getUtility
    >>> rel = source.createRelationship((ob4,), relation=relation_type, 
    ...     interfaces=(IAttributeAnnotatable,))
    >>> from zope.app.intid.interfaces import IIntIds
    >>> intids = []
    >>> intids_util = getUtility(IIntIds)
    >>> for i in range(30):
    ...     intids.append(intids_util.getId(app['ob%d' % i]))
    >>> orderer = pareto_interfaces.IOrderedRelationship(ob1)
    >>> orderer.relation_type = relation_type
    >>> ids_2_4 = (intids[2], intids[4])
    >>> orderer.add_item(intids[2])
    >>> orderer.add_item(intids[4])

The order is now ob2, ob4, or:

- ob2
- ob4

First adapt the orderer to an orderable.

    >>> orderable = pareto_interfaces.IOrderable(orderer)

Moving ob2 up should change nothing.

    >>> orderable.moveObjUp(intids[2])
    >>> ids_2_4 == tuple(orderer.order)
    True

Moving ob2 down should change the order:

    >>> orderable.moveObjDown(intids[2])
    >>> ids_2_4 == tuple(reversed(orderer.order))
    True


Using a non-existent intid, should result in a noop.

    >>> orderable.moveObjDown(intids[3])
    >>> ids_2_4 == tuple(reversed(orderer.order))
    True

Adding a relations from a particular source to the same target
should not be possible.


And it should be possible to set the orderer for all
intids at once. We are now reversing the order.

    >>> orderable.setOrder([8, 4])
    >>> ids_2_4 == tuple(orderer.order)
    True

    >>> len(tuple(source.getTargets(relation=u'relation 1')))
    2

When we delete the relationship from the source, the number of targets
should become 0.

    >>> source.deleteRelationship(ob2, relation=u'relation 1')

    >>> source.deleteRelationship(relation=u'relation 1', multiple=True)
    >>> len(tuple(source.getTargets(relation=u'relation 1')))
    0

When deleting a relationship, there is no event fired. So we are responsible
to take care of the removal of the related items from the order.

    >>> len(orderer.order)
    2

So that is not correct anymore. Let's fix the order.

    >>> orderer.remove_item(intids[2])
    >>> orderer.remove_item(intids[4])

    >>> len(orderer.order)
    0

Adding a relation of another type should not matter:

    >>> relation_type = u'relation 2'
    >>> rel = source.createRelationship((app['ob7']), relation=relation_type, 
    ...     interfaces=(IAttributeAnnotatable,))
    >>> rel = source.createRelationship((app['ob8']), relation=relation_type, 
    ...     interfaces=(IAttributeAnnotatable,))

    >>> len(tuple(source.getTargets(relation=u'relation 1')))
    0

We add some ordering.
    >>> orderer = pareto_interfaces.IOrderedRelationship(ob1)
    >>> orderer.relation_type = relation_type
    >>> orderer.add_item(intids[7])
    >>> orderer.add_item(intids[8])

    >>> verifyObject(interfaces.IDefaultDeletion, rel)
    True

    >>> same_orderer = pareto_interfaces.IOrderedRelationship(ob1)
    >>> same_orderer.relation_type = relation_type
    >>> same_orderer.order == orderer.order
    True

Lets try to remove a target:
    >>> app.manage_delObjects(['ob8'])
    >>> list(interfaces.IRelationshipSource(app['ob1']).getTargets())
    [<Demo ob7>]
    >>> target = interfaces.IRelationshipTarget(app['ob7'])
    >>> list(target.getSources())
    [<Demo ob1>]
    >>> orderer.order == [intids[7]]
    True

Now add a relations of another type to our source.

    >>> rel = source.createRelationship((app['ob9']), relation=u'relation 3', 
    ...     interfaces=(IAttributeAnnotatable,))

Our original orderer should still have one relation.
    >>> len(orderer.order)
    1

It would be nice if an event is fired on relation creation or deletion. 
On the event, the ordering should be added or removed
automatically. However, at this moment there is no event for create or delete relationship
in the underlying plone.app.relations package.

