from setuptools import setup, find_packages

version = '0.1'

setup(name='xmlcontent',
      version=version,
      description="Transparent XML publishing for Zope/Plone",
      long_description="""\
xmlcontent contains a mechanism to publish XML content from the file
system with the full feature set of Zope 3.

It does this by creating a proxy object for each XML file. Based on a
declaration in the XML file a marker interface is set as well. This
makes it possible to create views and adapters for this proxy object,
thereby being able to display and even index it.
""",
      classifiers=[
          "Framework :: Plone",
          "License :: OSI Approved :: LGPL",
          "Programming Language :: Python",
      ],
      keywords='plone xml',
      author='Jeroen Vloothuis',
      author_email='jeroen.vloothuis@xs4all.nl',
      url='http://svn.plone.org/svn/collective/xmlcontent',
      license='GPL',
      packages=find_packages(exclude=['ez_setup']),
      include_package_data=True,
      zip_safe=False,
      install_requires=[
        'setuptools',
      ],
      )
