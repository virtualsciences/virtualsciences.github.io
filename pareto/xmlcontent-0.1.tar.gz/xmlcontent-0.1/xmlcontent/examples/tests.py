from Products.CMFPlone.tests import PloneTestCase
import os
import xmlcontent
from Products.Five import zcml

class TestFullExample(PloneTestCase.PloneTestCase):

    def afterSetUp(self):
        zcml.load_config("configure.zcml", xmlcontent.examples)
        self.addProduct('xmlcontent')
        self.setRoles(['Manager'])
        self.folder.invokeFactory('FilesystemGateway', id='someid')
        self.content = self.folder.someid
        path = os.path.split(xmlcontent.examples.__file__)[0]
        self.content.setFileSystemDir(path)

    def testView(self):
        view = self.content.unrestrictedTraverse('applepie/view.html')
        self.failUnless('<h1>Apple pie</h1>' in view())

    def testDelegation(self):
        self.failUnlessEqual(self.content.unrestrictedTraverse('applepie').Title(),
                             'Apple pie')

    def testCatalog(self):
        pass

def test_suite():
    from unittest import TestSuite, makeSuite
    suite = TestSuite()
    suite.addTest(makeSuite(TestFullExample))
    return suite
