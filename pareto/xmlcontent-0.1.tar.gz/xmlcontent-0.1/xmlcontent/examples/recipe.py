from Products.Five import BrowserView
from zope import interface

class RecipeView(BrowserView):
    def name(self):
        return self.context.getroot().attrib['name']

    def ingredients(self):
        ingredients = []
        for node in self.context.getroot():
            ingredients.append(dict(
                name=node.attrib['name'],
                amount=node.attrib['amount']))
        return ingredients

class RecipeDelegator(object):
#     interface.implements(IAttributeDelegator) 

    def __init__(self, context):
        self.context = context

    def Title(self):
        return self.context.getroot().attrib['name']
