from zope import interface

class IRecipe(interface.Interface):
    pass
