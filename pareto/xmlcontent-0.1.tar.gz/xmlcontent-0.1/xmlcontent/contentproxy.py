from zope import interface
from zope.configuration.name import resolve
from interfaces import IXMLContentProxy

import Acquisition
from AccessControl import ClassSecurityInfo, Owned

class ContentProxy(Acquisition.Implicit,
           Owned.Owned,
                  ):
    interface.implements(IXMLContentProxy)

    security = ClassSecurityInfo()
    security.declareObjectPublic()

    def __init__(self, gateway, document):
        self.gateway = gateway
        self.document = document

        interfacepath = document.get('{http://namespaces.plone.org/xmlcontent}interface')
        if interfacepath is not None:
            contentinterface = resolve(interfacepath)
            interface.directlyProvides(self, contentinterface)

    def getroot(self):
        return self.document
