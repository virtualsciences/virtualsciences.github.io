from zope import interface

class IXMLContentProxy(interface.Interface):
    '''A proxy for xml based data which exports a minimal interface'''

    def getroot():
        '''Return the document root
        
        This is an elementtree root object (tree.getroot()).'''

class IStaticContentProxy(interface.Interface):
    '''A proxy for static filesystem content like images etc.'''

class IContentGateway(interface.Interface):
    '''A piece of content which can act a filesystem content gateway'''

    filesystemdir = interface.Attribute(
        u'The path to the filesystem directory from which content must be published')

    path = interface.Attribute(
        u'The path where this object comes from, this normally is the ZODB path')

class IATContentGateway(interface.Interface):
    '''An Archetypes based implementation of a filesystem gateway'''

    def getFileSystemDir(self):
        '''Return a string which points to a directory on the filesystem'''

class IFilesystemProxy(interface.Interface):
    '''A proxy which can transfor files from disk into objects'''

    def load(name):
        '''Load a name from disk'''

class ICatalogIndexer(interface.Interface):
    '''The indexer takes all content from a proxy and updates the catalog'''

    def index_all():
        '''Index all content in the repository'''

    def unindex_all():
        '''Unindex all content in the repository'''
