from Acquisition import aq_parent
from Products.CMFPlone.tests import PloneTestCase
from Testing import ZopeTestCase
from Testing.ZopeTestCase import user_name
import os
import xmlcontent
from Products.Five.traversable import FakeRequest
from Products.Five import zcml
from xmlcontent.browser.catalog import CatalogIndexingView, CatalogUnindexingView
ZopeTestCase.installProduct('xmlcontent')
class TestCatalogView(PloneTestCase.PloneTestCase):

    def afterSetUp(self):
        self.addProduct('xmlcontent')
        self.folder.invokeFactory('ATFilesystemGateway', id='someid')
        self.content = self.folder.someid
        path = os.path.join(os.path.split(xmlcontent.__file__)[0], 'examples')
        self.content.setFileSystemDir(path)
        self.catalog = self.portal.portal_catalog

    def testCatalogging(self):
        view = CatalogIndexingView(self.content, None)
        view()
        results = self.catalog(Title='apple pie')
        self.failUnlessEqual(len(results), 1)
        brain = results[0]
        self.failUnlessEqual(brain.Title, 'Apple pie')
        self.failUnless(brain.getPath().endswith('/applepie'))

    def testUncataloging(self):
        indexview = CatalogIndexingView(self.content, None)
        unindexview = CatalogUnindexingView(self.content, None)
        original = len(self.catalog())
        indexview()
        self.failIfEqual(original, len(self.catalog()))
        unindexview()
        self.failUnlessEqual(original, len(self.catalog()))

def test_suite():
    from unittest import TestSuite, makeSuite
    suite = TestSuite()
    suite.addTest(makeSuite(TestCatalogView))
    return suite
