from Products.CMFCore.permissions import ManageProperties, setDefaultRoles
from AccessControl import ModuleSecurityInfo
PKG_NAME = "xmlcontent"

GLOBALS = globals()

security = ModuleSecurityInfo('xmlcontent.permissions')

security.declarePublic('AddFilesystemGateway')
AddFilesystemGateway = 'Add Filesystem Gateway'
setDefaultRoles( AddFilesystemGateway, ('Manager', 'Owner') )
