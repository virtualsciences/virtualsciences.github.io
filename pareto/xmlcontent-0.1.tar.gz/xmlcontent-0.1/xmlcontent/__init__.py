from Products.CMFCore import utils
from Products.Archetypes.public import process_types, listTypes
from config import GLOBALS, PKG_NAME
from config import AddFilesystemGateway

from Products.GenericSetup import EXTENSION
from Products.GenericSetup import profile_registry
import Products.CMFPlone.interfaces

def initialize(context):
    import content
    profile_registry.registerProfile( name='default',
        title='xmlcontent',
        description='',
        path='profiles/default',
        product='xmlcontent',
        profile_type=EXTENSION,
        for_=Products.CMFPlone.interfaces.IPloneSiteRoot)
    
    content_types, constructors, ftis = process_types(
        listTypes(PKG_NAME),
        PKG_NAME)
    
    utils.ContentInit(
        PKG_NAME + ' Content',
        content_types      = content_types,
        permission         = AddFilesystemGateway,
        extra_constructors = constructors,
        fti                = ftis,
        ).initialize(context)
