#import sys
#
#path ='/home/mperumal/plone_development/eggs/setuptools-0.6c9-py2.4.egg'
#cheetah='/home/mperumal/plone_development/eggs/Cheetah-2.2.1-py2.4-linux-i686.egg'
#
#sys.path.append(path)
#sys.path.append(cheetah)

from setuptools import setup, find_packages
import os

version = 1.0

classifiers=[
        "Programming Language :: Python",
        ("Topic :: Software Development :: "
         "Libraries :: Python Modules")]



setup(name='pbp.skel',
      version=version,
      description=("PasteScript templates for the Expert "
                   "Python programming Book."),
      classifiers=classifiers,
      keywords='paste templates',
      author='Manjula Perumal',
      author_email='manjula.perumal@pareto.nl',
      license='proprietary',
      packages=find_packages(exclude=['ez_setup']),
      namespace_packages=['pbp'],
      include_package_data=True,
      zip_safe=False,
      install_requires=[
          'setuptools',
          'PasteScript'],
          
      
      entry_points="""
      # -*- Entry Points: -*-
      [paste.paster_create_template]
      pbp_package = pbp.skels.package:Package
      """)
