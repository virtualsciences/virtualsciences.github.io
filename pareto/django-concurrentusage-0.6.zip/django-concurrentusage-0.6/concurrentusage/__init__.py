from django.core.cache import cache
from django.contrib.auth.signals import user_logged_out


def logout_callback(sender, **kwargs):
    
    request = kwargs.get('request')
    user = kwargs.get('user')
    user_id = request.user.id
    users_sessions = cache.get('usersessions', {})
    user_info = users_sessions.get(user_id, None)
    if user_info is not None:
        session_key = request.session.session_key
        try:
            del user_info['sessions'][session_key]
            cache.set('usersessions', users_sessions)
        except KeyError:
            pass

# print('signal registered')
user_logged_out.connect(logout_callback)
