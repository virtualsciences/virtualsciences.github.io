from setuptools import setup, find_packages

version = '0.6'

setup(name='django-concurrentusage',
      version=version,
      description="Middleware to monitor concurrent usage in Django",
      long_description="Middleware to monitor concurrent usage in Django",
      classifiers=[],
      keywords='',
      author='Jan Murre',
      author_email='jan.murre@pareto.nl',
      url='',
      license='',
      packages=find_packages(exclude=['ez_setup', 'examples', 'tests']),
      include_package_data=True,
      zip_safe=False,
      install_requires=[
          # -*- Extra requirements: -*-
      ],
      entry_points="""
      # -*- Entry points: -*-
      """,
      )
