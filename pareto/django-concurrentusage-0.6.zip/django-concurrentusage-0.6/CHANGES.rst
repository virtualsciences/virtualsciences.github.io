Changes for django_concurrentusage
==================================


0.6 (2012-12-17)
----------------

- Start this Changes file.
  [maurits]

- Bugfix concurrent usage.
  [freark.van.der.bos]


0.5 (2012-01-12)
----------------

- Added signal to decrease counter on logout.
  [murre]


0.4 (2011-12-13)
----------------

- Various.
  [various]
