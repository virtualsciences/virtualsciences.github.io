import time
from django.test.client import Client
from django.conf import settings
from django.core.cache import cache
from django.contrib.sessions.models import Session
from concurrentusage.middleware import ConcurrentUsageMiddleware


def request_helper(clients, amount, sleep_time=0):
    for i in range(amount):
        clients.append(Client())
    for i, client in enumerate(clients):
        client.login(username='user', password='user')
        res = client.get('/protected/')
        if sleep_time > 0 and i > amount - 2:
            time.sleep(sleep_time)
    return res


def test_max_sessions_allowed(client, user):
    ConcurrentUsageMiddleware._users_sessions = {}
    cache.set('usersessions', {})
    clients = [client]
    last_res = request_helper(clients,
        settings.CONCURRENT_USAGE_DEFAULT_LIMIT - 1)
    assert last_res.status_code == 200
    assert Session.objects.count() == settings.CONCURRENT_USAGE_DEFAULT_LIMIT


def test_last_session_not_allowed(client, user):
    ConcurrentUsageMiddleware._users_sessions = {}
    cache.set('usersessions', {})
    clients = [client]
    last_res = request_helper(clients, settings.CONCURRENT_USAGE_DEFAULT_LIMIT)
    # now the latest one has be be redirected
    assert last_res.status_code == 302
    assert Session.objects.count() == settings.CONCURRENT_USAGE_DEFAULT_LIMIT


def test_last_session_not_allowed_forbidden(client, user):
    ConcurrentUsageMiddleware._users_sessions = {}
    cache.set('usersessions', {})
    saved = settings.CONCURRENT_USAGE_MAX_REDIRECT
    settings.CONCURRENT_USAGE_MAX_REDIRECT = None
    clients = [client]
    last_res = request_helper(clients, settings.CONCURRENT_USAGE_DEFAULT_LIMIT)
    # now the latest one has be be forbidden, no redirect
    assert last_res.status_code == 403
    assert Session.objects.count() == settings.CONCURRENT_USAGE_DEFAULT_LIMIT
    settings.CONCURRENT_USAGE_MAX_REDIRECT = saved


def test_last_session_allowed_with_low_idle_age(client, user):
    ConcurrentUsageMiddleware._users_sessions = {}
    cache.set('usersessions', {})
    settings.CONCURRENT_USAGE_ACTIVE_SESSION_SECS = 1
    clients = [client]
    last_res = request_helper(clients, settings.CONCURRENT_USAGE_DEFAULT_LIMIT,
            sleep_time=2)
    # now the latest one has be be allowed
    assert last_res.status_code == 200


def test_max_sessions_allowed_for_user(client, user):

    from test.models import ConcurrentUsageProfile

    ConcurrentUsageProfile.objects.create(
        user=user, limit=3)

    ConcurrentUsageMiddleware._users_sessions = {}
    cache.set('usersessions', {})
    settings.CONCURRENT_USAGE_LIMIT_ATTRIBUTE =\
            'concurrent_usage_profile.limit'
    clients = [client]
    last_res = request_helper(clients, 3)
    assert last_res.status_code == 302
    assert Session.objects.count() == 3


def test_max_sessions_allowed_limit_is_none(client, user):

    from test.models import ConcurrentUsageProfileNullable

    ConcurrentUsageProfileNullable.objects.create(
        user=user)

    ConcurrentUsageMiddleware._users_sessions = {}
    cache.set('usersessions', {})
    settings.CONCURRENT_USAGE_LIMIT_ATTRIBUTE =\
            'concurrent_usage_profile_nullable.limit'
    clients = [client]
    last_res = request_helper(clients,
        settings.CONCURRENT_USAGE_DEFAULT_LIMIT + 1)
    assert last_res.status_code == 302
    assert Session.objects.count() == 2


def test_max_sessions_allowed_no_limit(client, user):

    from test.models import ConcurrentUsageProfileMissingLimit

    ConcurrentUsageProfileMissingLimit.objects.create(
        user=user)

    ConcurrentUsageMiddleware._users_sessions = {}
    cache.set('usersessions', {})
    settings.CONCURRENT_USAGE_LIMIT_ATTRIBUTE =\
            'concurrent_usage_profile_missing_limit.limit'
    clients = [client]
    saved = settings.CONCURRENT_USAGE_LIMIT_ATTRIBUTE
    delattr(settings, 'CONCURRENT_USAGE_DEFAULT_LIMIT')
    last_res = request_helper(clients, 2)
    assert last_res.status_code == 302
    assert Session.objects.count() == 2
    settings.CONCURRENT_USAGE_LIMIT_ATTRIBUTE = saved


def xtest_logout_signal(client, user, request):
    from django.contrib.auth.signals import user_logged_out
    user_logged_out.send(sender=user.__class__, request=request, user=user)

