from django_pytest.conftest import (pytest_funcarg__client,
                                    pytest_funcarg__django_client,
                                    pytest_funcarg__user)

from django.conf import settings
from concurrentusage.middleware import ConcurrentUsageMiddleware

pytest_funcarg__client # pyflakes
pytest_funcarg__django_client # pyflakes
pytest_funcarg__user # pyflakes


def pytest_funcarg__api(request):
    '''Create a user with no special permissions.'''
    settings.REPO_API = 'mobiel.api.TestAPI'
    settings.NUMBER_OF_RESULTS = 10
    client = request.getfuncargvalue('client')
    client.login(username='user', password='user')
    ConcurrentUsageMiddleware._users_sessions = {}


def pytest_funcarg__request(request):
    ''' Makes request available '''
    return request
