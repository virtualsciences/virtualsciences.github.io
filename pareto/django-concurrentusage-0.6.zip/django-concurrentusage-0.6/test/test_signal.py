from django.core.cache import cache
from django.contrib.sessions.models import Session
from concurrentusage.middleware import ConcurrentUsageMiddleware
from django_webtest import WebTest

class SignalTestCase(WebTest):

    def testSignal(self):
        ConcurrentUsageMiddleware._users_sessions = {}
        cache.set('usersessions', {})
        page = self.app.get('/protected/', user='user')
