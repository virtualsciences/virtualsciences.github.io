from django.db import models
from django.contrib.auth.models import User


class ConcurrentUsageProfile(models.Model):
    user = models.OneToOneField(User, related_name='concurrent_usage_profile')
    limit = models.IntegerField(default=2)

    def __unicode__(self):
        return u'%s, concurrent login limit: %d' % (
            self.user.username, self.limit)


class ConcurrentUsageProfileNullable(models.Model):
    user = models.OneToOneField(User,
            related_name='concurrent_usage_profile_nullable')
    limit = models.IntegerField(null=True)

    def __unicode__(self):
        return u'%s, concurrent login limit: %s' % (
            self.user.username, self.limit)


class ConcurrentUsageProfileMissingLimit(models.Model):
    user = models.OneToOneField(User,
            related_name='concurrent_usage_profile_missing_limit')

    def __unicode__(self):
        return u'%s, concurrent login' % self.user.username
