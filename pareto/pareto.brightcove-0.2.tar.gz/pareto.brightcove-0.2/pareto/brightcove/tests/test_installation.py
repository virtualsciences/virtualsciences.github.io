from pareto.brightcove.tests.base import TestCase

class TestInstallation(TestCase):

    def testIsInstallable(self):
        qi = self.portal.portal_quickinstaller
        self.failUnless(qi, 'pareto.brightcove')

    def testProperties(self):
        props_tool = self.portal.portal_properties
        self.failUnless(props_tool.hasObject('brightcove'))

    def testJavascript(self):
        js_tool = self.portal.portal_javascripts
        script, content_type = js_tool['++resource++brightcove.js']
        # check if there is a problem with loading the resource
        self.failIf('ERROR' in script) 


def test_suite():
    from unittest import TestSuite, makeSuite
    suite = TestSuite()
    suite.addTest(makeSuite(TestInstallation))
    return suite
