def initialize(context):
    "Fake being a Zope 2 product"
