from Testing import ZopeTestCase as ztc
from Products.Five import zcml
from Products.Five import fiveconfigure
from Products.PloneTestCase import PloneTestCase as ptc
from Products.PloneTestCase.layer import onsetup

import xmlcontent

@onsetup
def setup_product():
    """Set up additional products and ZCML required to test this product.

    The @onsetup decorator causes the execution of this body to be deferred
    until the setup of the Plone site testing layer.
    """

    fiveconfigure.debug_mode = True
    zcml.load_config('configure.zcml', xmlcontent)
    fiveconfigure.debug_mode = False
    ztc.installPackage('xmlcontent')

setup_product()
ptc.setupPloneSite(extension_profiles=("xmlcontent:default",), id='xmlcontent')

class XMLContentTestCase(ptc.PloneTestCase):

    def getPortal(self):
        return self.app.xmlcontent
