from zope import interface
from xmlcontent.interfaces import IStaticContentProxy
import Acquisition
from AccessControl import ClassSecurityInfo, Owned

class StaticContentProxy(Acquisition.Implicit, Owned.Owned):
    interface.implements(IStaticContentProxy)

    security = ClassSecurityInfo()
    security.declareObjectPublic()

    def __init__(self, gateway, filename):
        self.gateway = gateway
        self.filename = filename
