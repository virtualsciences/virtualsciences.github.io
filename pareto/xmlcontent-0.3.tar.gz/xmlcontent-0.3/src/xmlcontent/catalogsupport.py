from zope import interface
from Products.ZCatalog.interfaces import IZCatalog
from xmlcontent.interfaces import IContentGateway, IFilesystemProxy, ICatalogIndexer

class CatalogIndexer(object):
    interface.implements(ICatalogIndexer)

    def __init__(self, catalog, contentgateway):
        self.catalog = catalog
        self.contentgateway = contentgateway

    @property
    def gateway(self):
        return IContentGateway(self.contentgateway)
    
    @property
    def proxy(self):
        return IFilesystemProxy(self.gateway)

    def do_catalog_action(self, action, ids):
        catalog = IZCatalog(self.catalog)
        gateway = IContentGateway(self.contentgateway)
        proxy = IFilesystemProxy(gateway)

        for name in ids:
            path = gateway.path+'/'+name
            catalogaction = getattr(catalog, action+'_object')
            if action=='catalog':
                obj = proxy.load(name)
                catalogaction(obj, uid=path)
            else:
                catalogaction(path)

    def reindex(self, ids):
        self.unindex(ids)
        self.index(ids)

    def unindex(self, ids):
        self.do_catalog_action('uncatalog', ids)

    def index(self, ids):
        self.do_catalog_action('catalog', ids)

    def index_all(self):
        self.index(self.proxy.contentnames())

    def unindex_all(self):
        self.unindex(self.proxy.contentnames())

