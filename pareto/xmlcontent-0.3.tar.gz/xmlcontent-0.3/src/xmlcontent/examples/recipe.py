from plone.app.content.interfaces import IIndexableObjectWrapper
from Products.Five import BrowserView
from zope import interface

class RecipeView(BrowserView):
    def name(self):
        return self.context.getroot().attrib['name']

    def ingredients(self):
        ingredients = []
        for node in self.context.getroot():
            ingredients.append(dict(
                name=node.attrib['name'],
                amount=node.attrib['amount']))
        return ingredients

class RecipeObjectWrapper(object):
    interface.implements(IIndexableObjectWrapper)

    def __init__(self, context, portal):
        self.context = context
        self.portal = portal

    def allowedRolesAndUsers(self):
        return 'Anonymous'

    @property
    def id(self):
        return 'applepie'

    def Title(self):
        return self.context.getroot().attrib['name']

    def update(self, vars, **kwargs):
        pass
