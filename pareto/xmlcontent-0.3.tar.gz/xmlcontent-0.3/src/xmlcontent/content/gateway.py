from AccessControl import ClassSecurityInfo

from Products.Archetypes.public import Schema
from Products.Archetypes.public import StringField

from Products.ATContentTypes.content.base import registerATCT
from Products.ATContentTypes.content.base import ATCTContent
from Products.ATContentTypes.content.schemata import ATContentTypeSchema
from Products.ATContentTypes.content.schemata import finalizeATCTSchema
from Products.ATContentTypes.lib.historyaware import HistoryAwareMixin

from zope import interface

from xmlcontent.config import PKG_NAME
from xmlcontent.interfaces import IATContentGateway, IContentGateway, \
    IFilesystemProxy
from xmlcontent.gatewaytraversal import GatewayTraversal

class ContentGateway(object):
    interface.implements(IContentGateway)

    def __init__(self, context):
        self.context = context
    
    @property
    def filesystemdir(self):
        return self.context.getFileSystemDir()

    @property
    def path(self):
        return '/'.join(self.context.getPhysicalPath())

schema = ATContentTypeSchema.copy() + Schema((
    StringField('fileSystemDir',
                required=True,)))

finalizeATCTSchema(schema)

class ATFilesystemGateway(ATCTContent, HistoryAwareMixin):
    """A filesystem gateway."""

    interface.implements(IATContentGateway)

    schema = schema

    content_icon   = 'folder_icon.gif'
    meta_type      = 'ATFilesystemGateway'
    portal_type    = 'ATFilesystemGateway'
    archetype_name = 'FilesystemGateway'
    default_view   = 'base_view'
    immediate_view = 'base_view'
    suppl_views    = ()
    typeDescription= 'A File System Gateway.'
    typeDescMsgId  = 'description_edit_filesystem_gateway'

    security       = ClassSecurityInfo()

    def objectItems(self):
        '''Return (id, object) tuples of all contained XML objects'''
        proxy = IFilesystemProxy(IContentGateway(self))
        results = []
        for id in proxy.contentnames():
            results.append((id, proxy.load(id).__of__(self)))
        return results
    
    def __bobo_traverse__(self, request, name):
        """ Calls the GatewayTraversal adapter because the 
        OFS.Traversable does not do adapter lookup """
        try:
            return GatewayTraversal(self, request).load(name)
        except IOError:
            return ATCTContent.__bobo_traverse__(self, request, name)
                

registerATCT(ATFilesystemGateway, PKG_NAME)
