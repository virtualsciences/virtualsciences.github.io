from mimetypes import guess_type

from Products.Five import BrowserView


class StaticProxyView(BrowserView):
    def __call__(self):
        type, encoding = guess_type(self.context.filename)
        self.request.response.setHeader('Content-type', type)
        return open(self.context.filename, 'rb').read()
