pareto.jsonexport - export Zope/Plone objects to JSON
=====================================================

This product allows exporting Zope/Plone content as JSON. It's goal is not to
perform a full data export, only to expose data that is publically visible and
interesting to expose (no special metadata, no portlets, workflow state,
etc.). The goal of this is to expose a specific set of data as JSON for
displaying Plone content from another application, not to generate a full
export for e.g. migration.

Questions, remarks, etc.
------------------------

Send mail to guido dot wesdorp at pareto dot nl
