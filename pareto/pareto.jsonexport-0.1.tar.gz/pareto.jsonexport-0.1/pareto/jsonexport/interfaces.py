from zope.interface import Interface

class ISerializer(Interface):
    pass
