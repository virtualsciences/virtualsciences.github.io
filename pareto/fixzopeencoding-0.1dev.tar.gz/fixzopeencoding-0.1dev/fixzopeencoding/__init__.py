from monkey import wrap
import zope.publisher.http

# This fixes https://bugs.launchpad.net/zope2/+bug/143873 

@wrap(zope.publisher.http.HTTPCharsets.getPreferredCharsets,
      '1af5f3cdb9a124f5dc8a52ff6226907859207db9')
def zope2_request_fix(func, self):
    if not bool(self.request.get('HTTP_ACCEPT_CHARSET')):
        self.request = {'HTTP_ACCEPT_CHARSET': 'utf-8'}

    return func(self)

def initialize(self):
    zope.publisher.http.HTTPCharsets.getPreferredCharsets = zope2_request_fix
