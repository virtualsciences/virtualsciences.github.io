from setuptools import setup, find_packages

version = '0.1.2'

setup(name='multisafepay',
      version=version,
      description="Multisafepay integration",
      long_description="""\
""",
      classifiers=[], # Get strings from http://pypi.python.org/pypi?%3Aaction=list_classifiers
      keywords='',
      author='Jan Murre',
      author_email='jan.murre@pareto.nl',
      url='http://www.pareto.nl',
      license='Apache',
      packages=find_packages(exclude=['ez_setup', 'examples', 'tests']),
      include_package_data=True,
      zip_safe=False,
      install_requires=[
          # -*- Extra requirements: -*-
      ],
      entry_points= {
            'console_scripts': [
                "msp_serve=multisafepay.testhttpserver:main"
            ]
      },
      )
