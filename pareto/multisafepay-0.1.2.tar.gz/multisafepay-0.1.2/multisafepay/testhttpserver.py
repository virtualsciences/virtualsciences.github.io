from wsgiref.util import setup_testing_defaults
from wsgiref.simple_server import make_server
from multiprocessing import Process


ok_response = \
"""<?xml version="1.0" encoding="UTF-8" ?>
<redirecttransaction result="ok">
<transaction>
<id>4084044</id>
<payment_url>https://user.multisafepay.com/pay/</payment_url>
</transaction>
</redirecttransaction>
"""

error_response =\
"""<?xml version="1.0" encoding="UTF-8"?>
<redirecttransaction result="error">
<error>
<code>1013</code>
<description>MD5 mismatch</description>
</error>
<transaction>
<id>4084044</id>
</transaction>
</redirecttransaction>
"""

status_ok_response = \
"""<?xml version="1.0" encoding="UTF-8"?>
<status result="ok">
    <ewallet>
        <id>80675</id>
        <status>completed</status>
        <created>20100415132654</created>
        <modified/>
    </ewallet>
    <customer>
        <currency>EUR</currency>
        <amount>1000</amount>
        <exchange_rate>1</exchange_rate>
        <firstname>Jan</firstname>
        <lastname>Modaal</lastname>
        <city>Amsterdam</city>
        <state/>
        <country>NL</country>
        <countryname>Netherlands</countryname>
    </customer>
    <transaction>
        <id>4084044</id>
        <currency>EUR</currency>
        <amount>1000</amount>
        <description>Test transaction</description>
        <var1/>
        <var2/>
        <var3/>
        <items/>
    </transaction>
</status>"""


class TestServer(object):

    def run(self):

        def run_server():

            def msp_app(environ, start_response):
                setup_testing_defaults(environ)
                path = environ.get('PATH_INFO', '').lstrip('/')
                start_response('200 OK', [('Content-Type', 'application/xml')])
                if path == 'ok':
                    return [ok_response]
                elif path == 'error':
                    return [error_response]
                elif path == 'status_ok':
                    return [status_ok_response]
                elif path == 'status_error':
                    return [error_response]
                else:
                    return []

            httpd = make_server('', 8000, msp_app)
            print "Serving on port 8000..."
            httpd.serve_forever()

        self.process = Process(target=run_server)
        self.process.start()

    def stop(self):
        self.process.terminate()


def main():
    server = TestServer()
    server.run()
