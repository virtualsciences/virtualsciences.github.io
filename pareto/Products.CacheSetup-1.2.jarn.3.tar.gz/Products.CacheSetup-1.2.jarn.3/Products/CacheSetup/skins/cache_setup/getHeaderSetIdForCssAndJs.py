## Script (Python) "getPolicyIdForCssAndJs"
##bind container=container
##bind context=context
##bind namespace=
##bind script=script
##bind subpath=traverse_subpath
##parameters=
##title=get caching policy for RR-generated CSS, JS, KSS files

# Backwards compatibility
context.getHeaderSetIdForResource()
