def create_matrix(data, columns, padding=None, vertical=False):
    if not vertical:
        matrix = []
        for i, item in enumerate(data):
            if i % columns == 0:
                matrix.append([])
            matrix[-1].append(item)
        
        for i in range(columns - len(matrix[-1])):
            matrix[-1].append(padding)
            
    else:
        matrix = [[] for i in range(columns)]
        
        cell_data = list(data)
        
        remainder = columns - (len(cell_data) % columns)
        if remainder == columns:
            remainder = 0
        
        cell_data.extend([padding for i in range(remainder)])
        for i, item in enumerate(cell_data):
            matrix[i % columns].append(item)
        
    return matrix
