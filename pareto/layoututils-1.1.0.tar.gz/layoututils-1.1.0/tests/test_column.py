import doctest

def run_tests():
    result=doctest.testfile('columns.txt', package='layoututils')
    assert result[0] == 0

if __name__ == "__main__":
    run_tests()
