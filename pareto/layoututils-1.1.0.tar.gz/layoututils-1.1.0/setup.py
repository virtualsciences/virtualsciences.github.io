from setuptools import setup, find_packages

version = '1.1.0'

setup(
    name="layoututils",
    version=version,
    description="""Utility functions for creating (HTML) layouts.""",
    classifiers=[
      "Programming Language :: Python",
      "Topic :: Software Development :: Libraries :: Python Modules",
      ],
    author="Jeroen Vloothuis",
    # packages=['layoututils'],
    packages=find_packages(exclude=['ez_setup']),
    include_package_data=True,
    zip_safe=False,
    install_requires=[
        'setuptools',
        # -*- Extra requirements: -*-
    ],
    entry_points="""
    # -*- Entry points: -*-
    """,
)

