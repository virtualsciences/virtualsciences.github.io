/*

Bright Cove Player
==================

This script creates players in a document which contains links to a
movie hosted on Bright Cove. Each of these links will be replaced by a
player.

*/

function brightcove_links(){
  var links = document.getElementsByTagName('a');
  var filt = function(l){
    if(!l.href || !l.href.match("http://link.brightcove.com/.*"))
      return false;
    return true;
  };
  var brights = filter(filt, links);
  return brights;
}

function brightCoveInit(){
  var links = document.getElementsByTagName('a');

  for(var i=0; i<links.length; i++){
    var node = links.item(i);

    // If the node doesn't have an href, skip it.
	  if (!node.href) continue;

	  // If the url is not pointing to Bright Cove skip it
	  if (!node.href.match("http://link.brightcove.com/")) continue;

    var matched = node.href.match("bcpid(\\w+)/?");
    if( matched && matched[1])
      var playerId = matched[1];
    else continue;

    var id = 'BrightCovePlayer' + i;

    var para = document.createElement('p');
	  var obj = document.createElement('object');
    obj.setAttribute('width', '550');
    obj.setAttribute('height', '360');
    obj.setAttribute('id', id);
    obj.setAttribute('codebase', 'http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0');
    obj.setAttribute('classid', 'clsid:D27CDB6E-AE6D-11cg-96B8-444553540000');

    var params = [
      ['allowScriptAccess', 'always'],
      ['allowFullScreen', 'true'],
      ['movie', 'http://admin.brightcove.com/viewer/federated_f8.swf?flashId=flashObj0&servicesURL=http%3A%2F%2Fservices.brightcove.com%2Fservices&viewerSecureGatewayURL=https%3A%2F%2Fservices.brightcove.com%2Fservices%2Famfgateway&cdnURL=http%3A%2F%2Fadmin.brightcove.com&autoStart=false&preloadBackColor=%23FFFFFF&width=550&height=360&playerId=' + playerId + '&externalAds=false&sendReports=false&buildNumber=229&ranNum=810522'],
      ['wmode', 'window'],
      ['quality', 'high'],
      ['bgcolor', '#FFFFFF'],
      ['base', 'http://admin.brightcove.com/viewer/'],
      ['SeamlessTabbing', 'false']
    ];

    var param = null;
    for(var j=0; j<params.length; j++){
      param = document.createElement('param');
      param.setAttribute('name', params[j][0]);
      param.setAttribute('value', params[j][1]);
	    obj.appendChild(param);
    }

    var options = [
      ['width', '550'],
      ['height', '360'],
      ['pluginspage', 'http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash'],
      ['swliveconnect', 'true'],
      ['type', 'application/x-shockwave-flash'],
      ['seamlesstabbing', 'false'],
      ['wmode', 'window'],
      ['name', id],
      ['allowscriptaccess', 'always'],
      ['bgcolor', '#FFFFFF'],
      ['quality', 'high'],
      ['base', 'http://admin.brightcove.com/viewer/'],
      ['src', 'http://admin.brightcove.com/viewer/federated_f8.swf?flashId=flashObj0&servicesURL=http%3A%2F%2Fservices.brightcove.com%2Fservices&viewerSecureGatewayURL=https%3A%2F%2Fservices.brightcove.com%2Fservices%2Famfgateway&cdnURL=http%3A%2F%2Fadmin.brightcove.com&autoStart=false&preloadBackColor=%23FFFFFF&width=550&height=360&playerId=' + playerId + '&externalAds=false&sendReports=false&buildNumber=229&ranNum=810522']
    ];

	  var embed = document.createElement('embed');
    for(var j=0; j<options.length; j++){
	    embed.setAttribute(options[j][0], options[j][1]);
    }
	  para.appendChild(embed);

    var parent = node.parentNode;
	  parent.replaceChild(para, node);
  }
}

registerPloneFunction(brightCoveInit);
