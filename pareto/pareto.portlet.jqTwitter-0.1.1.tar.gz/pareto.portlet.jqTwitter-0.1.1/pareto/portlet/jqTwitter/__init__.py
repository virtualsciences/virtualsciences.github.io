from zope.i18nmessageid import MessageFactory
jqTwitterPortletMessageFactory = MessageFactory('pareto.portlet.jqTwitter')


def initialize(context):
    """Initializer called when used as a Zope 2 product."""
