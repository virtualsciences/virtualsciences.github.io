from pprint import pprint
import os, sys
if __name__ == '__main__':
    execfile(os.path.join(sys.path[0], 'framework.py'))
 
from Testing import ZopeTestCase
from Products.CMFPlone.tests import PloneTestCase

ZopeTestCase.installProduct('Compass')

from Products.CMFCore.utils import getToolByName

class TestCompass(PloneTestCase.PloneTestCase):
    def afterSetUp(self):
        self.workflow = self.portal.portal_workflow
        self.portal.portal_quickinstaller.installProducts(['Compass'])

        self.portal.acl_users._doAddUser('member', 'secret', ['Member'], [])
        self.portal.acl_users._doAddUser('reviewer', 'secret', ['Reviewer'], [])
        self.portal.acl_users._doAddUser('manager', 'secret', ['Manager'], [])

        self.setRoles(['Manager','Reviewer'])
        try:
            self.portal.manage_delObjects(ids=['Members', 'news', 'events'])
        except AttributeError:
            pass

        self.folder = self.portal
        
    def getCompass(self):
        return self.portal.portal_compass
    compass = property(getCompass)
    
    def testCompassInstall(self):
        compass = getattr(self.portal, 'portal_compass')

    def testDefaultFolder(self):
        results = self.compass.getMenuItems(self.folder)
        self.failUnlessEqual(results, [])

    def testSingleDocument(self):
        self.folder.invokeFactory('Document', id='doc')
        doc = self.folder.doc

        self.setRoles(['Manager','Reviewer'])
        
        self.workflow.doActionFor(doc, 'publish')

        results = self.compass.getMenuItems(self.folder)
        self.failUnlessEqual(len(results), 1)
        
    def createPublishedFolders(self, tree, context):
        for folder, children in tree:
            context.invokeFactory('Folder', folder)
            f = getattr(context, folder)
            f.setTitle(folder)
            self.workflow.doActionFor(f, 'publish')
            self.createPublishedFolders(children, f)
            
    def testNestedFolders(self):
        folderMap = [
            ('1', [
                ('1.1', []),
                ('1.2', [
                    ('1.2.1', [])
                ]),],),
            ('2', [])]
        self.setRoles(['Manager','Reviewer'])
        self.createPublishedFolders(folderMap, self.folder)
        results = self.compass.getMenuItems(self.folder)

        # Make sure there are only two top level entries
        self.failUnlessEqual(len(results), 2)
        # Make sure the first is the number 1
        self.failUnlessEqual(results[0]['title'], '1')
        # Make sure the second depth level is ok
        self.failUnlessEqual(results[0]['children'][0]['title'], '1.1')
        # Make sure the final depth level is ok
        self.failUnlessEqual(results[0]['children'][1]['children'][0]['title'],
                         '1.2.1')

    def testSubMenu(self):
        folderMap = [
            ('1', [
                ('1.1', []),
                ('1.2', [
                    ('1.2.1', [])
                ]),],),
            ('2', [])]
        self.setRoles(['Manager','Reviewer'])
        self.createPublishedFolders(folderMap, self.folder)

        folderDepth = len(
            self.portal.portal_url.getRelativeContentPath(
                self.folder))

        # Make sure we don't get a sub menu
        results = self.compass.getMenuItems(self.folder,
                                            start_depth=1+folderDepth)
        self.failUnlessEqual(len(results), 0)

        # Make sure we get a submenu when we do it ok
        results = self.compass.getMenuItems(getattr(self.folder, '1'),
                                            start_depth=1+folderDepth)
        self.failUnlessEqual(len(results), 2)
        self.failUnlessEqual(len(results[1]['children']), 1)


        # Make sure depth limiting works
        results = self.compass.getMenuItems(getattr(self.folder, '1'),
                                            start_depth=1+folderDepth,
                                            max_depth=1)
        self.failUnlessEqual(len(results), 2)

    def testMenuLimiting(self):
        folderMap = [
            ('1', [
                ('1.1', []),
                ('1.2', [
                    ('1.2.1', [])
                ]),],),
            ('2', [])]
        self.setRoles(['Manager','Reviewer'])
        self.createPublishedFolders(folderMap, self.folder)

        folderDepth = len(
            self.portal.portal_url.getRelativeContentPath(
                self.folder))

        results = self.compass.getMenuItems(self.folder,
                                            max_depth=1+folderDepth)
        self.failUnlessEqual(len(results), 2)
        self.failUnlessEqual(len(results[0]['children']), 0)

    def test_respect_exclude_from_navigation(self):
        folderMap = [
            ('1', [
                ('1.1', []),
                ('1.2', [
                    ('1.2.1', [])
                ]),],),
            ('2', [])]
        self.setRoles(['Manager','Reviewer'])
        self.createPublishedFolders(folderMap, self.folder)

        results = self.compass.getMenuItems(self.folder)
        self.failUnlessEqual(len(results), 2)

        # Now hide the first folder
        first = getattr(self.folder, '1')
        first.setExcludeFromNav(True)
        first.reindexObject()

        results = self.compass.getMenuItems(self.folder)
        self.failUnlessEqual(len(results), 1)

    def testOnlyOneSelected(self):
        # structure is
        # folder
        #   |
        #   sounds
        #   soundslike
        #       |
        #       sub

        self.setRoles(['Manager',])

        self.folder.invokeFactory('Folder', id='sounds')
        sounds = getattr(self.folder, 'sounds')
        self.folder.invokeFactory('Folder', id='soundslike')
        soundslike = getattr(self.folder, 'soundslike')
        soundslike.invokeFactory('Folder', id='sub')
        sub = getattr(soundslike, 'sub')
        
        # only one brain in the result should have a 'selected'
        results = self.compass.getMenuItems(sub)
        self.failIf(results[0]['selected'])
        self.failUnless(results[1]['children'][0]['selected'])

        # if the context is on 'soundslike', sub should not be
        # signalled as selected
        results = self.compass.getMenuItems(soundslike)
        self.failIf(results[1]['children'][0]['selected'])


    def testDefaultPageIgnored(self):
        # When a folder has a default page
        # It should not show up in the tree
        # and the enclosing folder should become 'active'

        self.setRoles(['Manager',])
        self.folder.invokeFactory('Folder', id='has_default')
        has_default = getattr(self.folder, 'has_default')
        has_default.invokeFactory('Document', id='default_doc')
        default_doc = getattr(has_default, 'default_doc')
        results = self.compass.getMenuItems(default_doc)
        self.assertEqual(len(results[0]['children']), 1)
        self.failIf(results[0]['active'])
        self.failUnless(results[0]['children'][0]['active'])

        # Now make a default Page, resulting in no children ...
        has_default.setDefaultPage('default_doc')
        results = self.compass.getMenuItems(default_doc)
        self.assertEqual(len(results[0]['children']), 0)
        # ... and an the 'active' being the enclosing folder
        self.failUnless(results[0]['active'])
 
        
    def test_do_not_hide_selected_document(self):
        # This test makes sure the selected document is not hidden
        docid = 'document'
        folderid = 'folder'

        self.setRoles(['Manager',])

        self.folder.invokeFactory('Folder', id=folderid)
        folder = getattr(self.folder, folderid)
        folder.setTitle('Test folder')
        self.workflow.doActionFor(folder, 'publish')
        
        folder.invokeFactory('Document', id=docid)
        doc = getattr(folder, docid)
        doc.setTitle('Test document')
        self.workflow.doActionFor(doc, 'publish')

        results = self.compass.getMenuItems(folder)
        self.failUnlessEqual(len(results[0]['children']), 1)

        results = self.compass.getMenuItems(doc)

        self.failUnlessEqual(len(results[0]['children']), 1)

    def test_content_as_default_view_for_folder(self):
        # This test makes sure when a piece of content is set as a
        # default view for a folder it is hidden from the navigation
        docid = 'document'
        folderid = 'folder'

        self.setRoles(['Manager',])

        self.folder.invokeFactory('Folder', id=folderid)
        folder = getattr(self.folder, folderid)
        folder.setTitle('Test folder')
        self.workflow.doActionFor(folder, 'publish')
        
        folder.invokeFactory('Document', id=docid)
        doc = getattr(folder, docid)
        doc.setTitle('Test document')
        self.workflow.doActionFor(doc, 'publish')

        results = self.compass.getMenuItems(folder)
        self.failUnlessEqual(len(results[0]['children']), 1)

        # now set the document as the default view
        folder.setDefaultPage(docid)
        results = self.compass.getMenuItems(folder)
        self.failUnlessEqual(len(results[0]['children']), 0)

    def test_menu_items_from_context(self):
        folderMap = [
            ('1', [
                ('1.1', []),
                ('1.2', [
                    ('1.2.1', [])
                ]),],),
            ('2', [])]
        self.setRoles(['Manager','Reviewer'])
        self.createPublishedFolders(folderMap, self.folder)

        menufolder = getattr(self.folder, '1')
        subfolder = getattr(menufolder, '1.1')
        results = self.compass.getMenuItemsFromContext(menufolder, subfolder)
        self.failUnlessEqual(len(results), 2)

        # Now hide the folder, this should have no effect
        menufolder.setExcludeFromNav(True)
        menufolder.reindexObject()

        results = self.compass.getMenuItemsFromContext(menufolder, subfolder)
        self.failUnlessEqual(len(results), 2)


    def test_no_duplicates(self):
        # make sure there are now duplicate records
        self.folder.invokeFactory('Folder', id='section')
        section = getattr(self.folder, 'section')
        section.setTitle('Test')
        
        section.invokeFactory('Document', id='index_html')
        getattr(section, 'index_html').setTitle('Test')

def test_suite():
    from unittest import TestSuite, makeSuite
    suite = TestSuite()
    suite.addTest(makeSuite(TestCompass))
    return suite

if __name__ == '__main__':
    framework()
