from Products.CMFCore.utils import getToolByName
from Products.CMFPlone import utils
from AccessControl import ClassSecurityInfo
from config import ManageProperties
from Globals import InitializeClass
from OFS.SimpleItem import SimpleItem
from Products.CMFCore.utils import UniqueObject
from Products.CMFPlone.interfaces.NonStructuralFolder import INonStructuralFolder

import operator


class CompassTool(UniqueObject, SimpleItem):
    id = 'portal_compass'
    meta_type = 'Compass'

    __implements__ = (INonStructuralFolder,)

    security = ClassSecurityInfo()

    security.declarePublic('getMenuItemsFromContext')
    def getMenuItemsFromContext(self, folder, context, **kwargs):
        """Return all items rooted in the folder"""
        portalURL = getToolByName(self, 'portal_url')
        folder_path = '/'.join(folder.getPhysicalPath())
        query = self.createQuery()
        query['path']  = {'query': folder_path}

        if kwargs:
            query.update(kwargs)

        results = []
        for item in self.runQuery(query, context):
            if item[0]!=folder_path:
                results.append(item)

        folderRelativePath = portalURL.getRelativeContentPath(folder)
        return self.createResultsTree(results, len(folderRelativePath))

    security.declarePublic('getMenuItems')
    def getMenuItems(self, context, max_depth=-1, start_depth=0,
                     **kwargs):
        """Return the menu items according to the params."""
        portalURL = getToolByName(self, 'portal_url')
        query = self.createQuery()
        query['path']  = {'query': '/'.join(portalURL.getPortalObject().getPhysicalPath())}

        if kwargs:
            query.update(kwargs)

        if start_depth!=0:
            contextRelativePath = portalURL.getRelativeContentPath(context)
            contextDepth = len(contextRelativePath)
            if contextDepth<start_depth:
                return [] # No need to make a menu, we are not deep enough
            query['path']['query'] = query['path']['query']+'/'+'/'.join(
                contextRelativePath[:start_depth])


        if max_depth!=-1:
            query['path']['depth']=max_depth

        results = self.runQuery(query, context)
        return self.createResultsTree(results, start_depth)

    security.declarePrivate('createQuery')
    def createQuery(self):
        ploneUtils = getToolByName(self, 'plone_utils')
        navtreeProperties = getToolByName(self, 'portal_properties').navtree_properties
        siteProperties = getToolByName(self, 'portal_properties').site_properties

        return {
            'portal_type': ploneUtils.typesToList(),
            'sort_on': 'getObjPositionInParent',
            'is_default_page': False,
        }


    security.declarePrivate('runQuery')
    def runQuery(self, query, context):
        catalog = getToolByName(self, 'portal_catalog')
        portal = getToolByName(self, 'portal_url').getPortalObject()
        portal_depth = len(portal.getPhysicalPath())
        brains = catalog(**query)
        
        siteProperties = getToolByName(self, 'portal_properties').site_properties
        def url(brain):
            if brain.portal_type in siteProperties.getProperty('typesUseViewActionInListings'):
                return brain.getURL()+'/view'
            return brain.getURL()
        

        results = []

        physical_path_tuple = context.getPhysicalPath()
        if utils.isDefaultPage(context, context.REQUEST):
            physical_path_tuple = physical_path_tuple[:-1]    
        physical_path = '/'.join(physical_path_tuple)
            
        for brain in brains:
            # Skip paths that are below the threshold
            results.append((brain.getPath(), dict(
                id=brain.id,
                depth=len(brain.getPath().split('/')) - portal_depth,
                title=brain.Title,
                url=url(brain),
                icon=brain.getIcon,
                description=brain.Description,
                selected=self.isBrainInPath(brain, context),
                active=physical_path==brain.getPath(),
                exclude_from_nav=brain.exclude_from_nav,
                children=[],
                brain=brain,
            )))
        return results

    security.declarePrivate('createResultsTree')
    def createResultsTree(self, results, start_depth):
        """Build a result tree"""
        
        portal_path_length = len(getToolByName(self, 'portal_url').getPortalPath())
        
        # Create a dict to make lookups fast
        data = dict(results)
        # Create the result tree
        finalTree = []
        for path, item in results:
            # Check if item should be excluded
            if item['exclude_from_nav']:
                continue
            
            parentPath = '/'.join(path.split('/')[:-1])
            parent = data.get(parentPath)
            
            if parent is not None:
                parent['children'].append(item)
            if len(path[portal_path_length:].split('/'))-start_depth==2:
                finalTree.append(item)
        return finalTree

    def isBrainInPath(self, brain, context):
        portalURL = getToolByName(self, 'portal_url')
        # return brain.getPath() in '/'.join(context.getPhysicalPath())
        # Comparison of path of brain and path of context
        # cannot be only string-based, all path elements need to
        # be compared one-by-one
        # we put the path elements side by side in a list of tuples
        # and if one comparison fails, the result is false
        brain_path = brain.getPath().split('/')
        context_path = context.getPhysicalPath()
        if len(brain_path) > len(context_path):
            return False
        path_parts = zip(brain_path, context_path)
        path_parts = [l == r for l, r in path_parts]
        return reduce(operator.and_, path_parts)
        

    def isContextInBrainPath(self, brain, context):
        return '/'.join(context.getPhysicalPath()) in brain.getPath()


    def getFilterPath(self, context, start_depth):
        portalDepth = len(portalURL.getPortalObject().getPhysicalPath())
        return '/'.join(context.getPhysicalPath()[:portalDepth+start_depth])
        
        
    security.declarePublic('isHomePage')
    def isHomePage(self, context):
        """ Returns if the context is the homepage, even if it is in fact document (which is set as a default view) """
        if context.meta_type=='Plone Site':
            return True

        plone_utils = getToolByName(self, 'plone_utils')
        portal = getToolByName(self, 'portal_url').getPortalObject()
        
        parentDefaultPage = plone_utils.getDefaultPage(portal)
        if parentDefaultPage is None or '/' in parentDefaultPage:
            return False
        else:
            return (parentDefaultPage == context.getId())
        return False

InitializeClass(CompassTool)
