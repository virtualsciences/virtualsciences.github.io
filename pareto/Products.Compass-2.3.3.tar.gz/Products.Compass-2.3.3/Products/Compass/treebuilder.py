"""
With the treebuilder you can construct trees from list with
tuples in them. These trees are represented as nested lists with
the dicts as items. The creation of the tree is based on the items
path (first element of the tuple).

"""

def create_results_tree(tree_data):
    """Build a result tree"""
    # Create a dict to make lookups fast
    data = dict(tree_data)
    # Create the result tree
    finalTree = []
    # Create a dict to avoid double entries (objects with id index_html)
    items_in_tree = {}
    
    for path, item in tree_data:
        # filter double entries
        if path in items_in_tree:
            continue
        items_in_tree[path] = True
        
        # Check if item should be excluded
        if item['exclude_from_nav']:
            continue
        
        parentPath = '/'.join(path.split('/')[:-1])
        parent = data.get(parentPath)
        
        if parent is None:
            finalTree.append(item)
            continue
        parent['children'].append(item)
    return finalTree
    
