========================
        Compass
========================
Compass is a tool which assists in create navigation elements. These can be
either website menu's or sitemaps. Compass makes is easy to create sub-menu's.
It is installed as a portal tool. Any Python script or Page Template can query
compass.
