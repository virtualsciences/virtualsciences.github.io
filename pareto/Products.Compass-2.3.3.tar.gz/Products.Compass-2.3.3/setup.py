from setuptools import setup, find_packages

version = '2.3.3'

setup(name='Products.Compass',
      version=version,
      description="Menu generation utility.",
      classifiers=[
        "Programming Language :: Python",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Framework :: Zope2",
        "Framework :: Plone",
        ],
      keywords='Compass',
      author='Jeroen Vloothuis',
      author_email='jeroen.vloothuis@pareto.nl',
      license='GPL',
      packages=find_packages(exclude=['ez_setup']),
      namespace_packages=['Products'],
      include_package_data=True,
      zip_safe=False,
      install_requires=[
          'setuptools',
      ],
      )
