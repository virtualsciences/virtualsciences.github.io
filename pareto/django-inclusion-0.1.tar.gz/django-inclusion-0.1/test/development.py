
from test.settings import *
DEBUG=True
TEMPLATE_DEBUG=DEBUG
