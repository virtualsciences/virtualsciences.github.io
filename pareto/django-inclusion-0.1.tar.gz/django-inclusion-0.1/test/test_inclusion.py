from inclusion import models


def pytest_funcarg__inclusion(request):

    def setup():
        fr_id = models.Fragment.objects.create(
            name='openx', content='aa {{p1}} bb')
        models.Parameter.objects.create(fragment=fr_id, name='p1', value='foo')
    return request.cached_setup(setup, scope="function")


def test_with_valid_tag(client, inclusion):
    response = client.get('/tagtester/')
    assert 'aa foo bb' in response.content


def test_without_valid_tag(client):
    client.get('/tagtester/')


def test_without_valid_param(client, inclusion):
    param = models.Parameter.objects.get(name='p1')
    param.name = 'p2'
    param.save()
    client.get('/tagtester/')
