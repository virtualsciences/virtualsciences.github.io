from lxml import etree

def solr_search(connection, stored_indices, params):
    ''' Utility function '''
    ret = connection.search(**params)
    tree = etree.fromstring(ret)
    result_node = tree.xpath('/response/result[@name="response"]')[0]
    num_found = result_node.get('numFound')
    docs = []
    for doc in result_node.findall('doc'):
        idx_info = {}
        for type_, index in stored_indices:
            nodes = doc.xpath('%s[@name="%s"]' % (type_, index))
            if nodes:
                idx_info[index] = nodes[0].text
        docs.append(idx_info)
    return (num_found, docs)
