(see Products/LDAPUserFolder/README.txt)
