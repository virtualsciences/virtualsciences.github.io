from zope.i18nmessageid import MessageFactory
BannerPortletMessageFactory = MessageFactory('pareto.bannerportlet')

def initialize(context):
    """Initializer called when used as a Zope 2 product."""
