from zope.interface import Interface, Attribute

class ICronTickView(Interface):
    """Marker interface to display google search results"""

class ICronTool(Interface):
    """Marker interface for the CronTool"""
