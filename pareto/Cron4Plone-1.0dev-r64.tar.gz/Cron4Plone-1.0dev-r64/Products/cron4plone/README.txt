TODO!!
------

Cron 4 Plone
------------

This tool can do scheduled tasks in plone

Warning
-------

this is an early alpha release, and is considered work in progress, just
like this documentation..


Installation
------------

step 1: configure the tocker in the buildout (or zope.conf)

[instance]
....

zope-conf-additional = 
  <clock-server>
      method /<your-plone-site>/@@cron-tick
      period 60
  </clock-server>

step 2: configure the scheduled tasks

in the ZMI, go to the CronTool.
This form can be used to enter the cron-like data. This should be in python syntax. Each line should contain a tuple, with 2 elements. The first element is a cron tuple, and the second a python statement that should be executed. The cron tuple should have 4 elements: minute, hour, day_of_month and month. Each element can also be a tuple as is shown in the example. a special '*' can be used as a wildcard. e.g:

[{'id': 'task_number_one', 'schedule':((0,15,30,45),'*','*','*'),'expression': 'python: portal.do_something_every_15_minutes()'},
{'id': 'task_number_two','schedule':('*','*','*','*'),'expression': 'python: portal.do_something_every_minute()'}]
