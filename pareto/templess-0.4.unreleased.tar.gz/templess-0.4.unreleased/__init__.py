""" minimal XML-based XML templating system """
