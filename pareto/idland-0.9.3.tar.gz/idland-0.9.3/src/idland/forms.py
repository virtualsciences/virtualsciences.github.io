from django.utils.translation import ugettext_lazy as _
from django import forms
from django.contrib.auth import authenticate
from django.contrib.auth.models import check_password
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.forms import PasswordResetForm as BasePasswordResetForm
from django.contrib.auth.forms import (UserCreationForm as UCreationF,
                                       UserChangeForm as UChangeF)
from idland.models import UserProfile, OldPassword
from idland.utils import new_expiry_date, get_user
import re
import urllib
import datetime
import hashlib


from idland.settingsimporter import settings_import
from django.conf import settings
User = settings_import(settings.USER)

class UserCreationForm(UCreationF):
    if settings.USER_ID == 'email':
        username = forms.RegexField(label=_("Username"), max_length=30, regex=r'^\w+$', required = False,
        help_text = _("Required. 30 characters or fewer. Alphanumeric characters only (letters, digits and underscores)."),
        error_message = _("This value must contain only letters, numbers and underscores."))


    email = forms.EmailField(label=_("E-mail"), max_length=75)

    class Meta:
        model = User
        fields = ("email", "username")


    def clean_username(self):
        # If we specified to use email address, make a hash of
        # the address to get a unique username. And check if there are no
        # form errors for the email address.
        if settings.USER_ID == 'email' and not self.errors:
            email = self.clean_email()
            hsh = hashlib.sha1(email)
            hsh.update(datetime.datetime.now().isoformat())
            username = hsh.digest().encode('base64')
        else:
            username = self.cleaned_data["username"]
        try:
            User.objects.get(username=username)
        except User.DoesNotExist:
            return username
        raise forms.ValidationError(_("A user with that username already exists."))


    def clean_email(self):
        """Make sure that an email address is unique."""
        email = self.cleaned_data["email"]
        try:
            User.objects.get(email=email)
        except User.DoesNotExist:
            return email
        raise forms.ValidationError(_("A user with that email already exists."))


class UserChangeForm(UChangeF):
    username = forms.RegexField(label=_("Username"), max_length=30,
                                regex=r'^\w+$', required=False,
                                help_text = _("Required. 30 characters or fewer. Alphanumeric characters only (letters, digits and underscores)."),
                                error_message = _("This value must contain only letters, numbers and underscores."))

    class Meta:
        model = User

class ContactForm(forms.Form):
    name = forms.CharField(max_length=100)
    subject = forms.CharField(max_length=100)
    phone_number = forms.CharField(required=False)
    email_address = forms.EmailField()
    message = forms.CharField(widget=forms.Textarea)

class UserUploadForm(forms.Form):
    csv_file  = forms.FileField()

class SetExtendedPasswordForm(forms.Form):
    """ A form that les a user change the password without entering the old
    password and does some strength checks.
    """
    new_password1 = forms.CharField(label="New password", widget=forms.PasswordInput)
    new_password2 = forms.CharField(label="New password confirmation", widget=forms.PasswordInput)

    def __init__(self, user, *args, **kwargs):
        self.user = user
        super(SetExtendedPasswordForm, self).__init__(*args, **kwargs)

    def clean_new_password2(self):
        password1 = self.cleaned_data.get('new_password1')
        password2 = self.cleaned_data.get('new_password2')
        error = "Your new password does not match the minimum requirements."
        if password1 and password2:
            if password1 != password2:
                raise forms.ValidationError("This password does not match your new password as defined above.")
        if len(password1) < settings.PASSWORD_LENGTH:
                raise forms.ValidationError(error)

        alpha = re.compile('[a-zA-Z]')
        digit = re.compile('[0-9]')

        if settings.ALPHA and not alpha.search(password1):
                raise forms.ValidationError(error)
        if settings.DIGIT and not digit.search(password1):
                raise forms.ValidationError(error)

        self.user.set_password(password2)
        for i in self.user.get_profile().old_passwords.all():
            if check_password(password2, i.password):
                raise forms.ValidationError("You have used this password before. Choose a new one.")

        return password2

    def save(self, commit=True):
        self.user.set_password(self.cleaned_data['new_password1'])
        self.pw = OldPassword.objects.create(password=self.user.password)
        self.profile = UserProfile.objects.get(user=self.user)
        self.profile.password_expiry = new_expiry_date()
        if commit:
            self.user.save()
            self.pw.save()
            self.profile.old_passwords.add(self.pw)
            self.profile.save()
        return self.user

# Form copied from django/contrib/auth/forms.py because I can't set the
# form and parent of the form

class PasswordChangeForm(SetExtendedPasswordForm):
    """
    A form that lets a user change his/her password by entering
    their old password.
    """
    old_password = forms.CharField(label="Old password", widget=forms.PasswordInput)

    def clean_old_password(self):
        """
        Validates that the old_password field is correct.
        """
        old_password = self.cleaned_data["old_password"]
        if not self.user.check_password(old_password):
            raise forms.ValidationError("Your old password was entered incorrectly. Please enter it again.")
        return old_password
PasswordChangeForm.base_fields.keyOrder = ['old_password', 'new_password1', 'new_password2']


class PasswordResetForm(BasePasswordResetForm):

    def clean_email(self):
        """
        Validates that a user exists with the given e-mail address.
        """
        email = self.cleaned_data["email"]
        self.users_cache = User.objects.filter(email__iexact=email)
        if len(self.users_cache) == 0:
            raise forms.ValidationError(_("That e-mail address doesn't have an associated user account. Are you sure you've registered?"))

#Copied from django.contrib.auth.forms and added password expiry for
#entering wrong password three times.
class IDLandAuthenticationForm(AuthenticationForm):
    username = forms.CharField(label=_("Username"), max_length=120)

    def clean(self):
        username = self.cleaned_data.get('username')
        # the username can be urlquoted, %40 for '@'; unquote before further
        # parsing.
        username = urllib.unquote(username)
        password = self.cleaned_data.get('password')

        if username and password:
            self.user_cache = authenticate(username=username, password=password)
            if self.user_cache is None:
                # the password is entered wrongly once.

                user = get_user(username)
                profile = None
                if user != None:
                    profile = user.get_profile()

                # raise wrong_password_entered with one, set the
                # password unuseable when it's entered wrongly thrice
                if profile:
                    if not profile.wrong_password_entered >= \
                            settings.MAX_WRONG_PASSWORD:
                        profile.wrong_password_entered += 1
                        profile.save()
                    if profile.wrong_password_entered >= \
                            settings.MAX_WRONG_PASSWORD:
                        user.set_unusable_password()
                        user.save()
                    raise forms.ValidationError("This username or password is incorrect. You have %d times left to login correctly." %( settings.MAX_WRONG_PASSWORD -profile.wrong_password_entered) )

                raise forms.ValidationError("Please enter a correct username and password. Note that both fields are case-sensitive.")

            elif not self.user_cache.is_active:
                raise forms.ValidationError("This account is inactive.")
            # user is logged in, reset password_counter
            else:
                user = get_user(username)
                profile = user.get_profile()

                # need to reset the counter with less then two wrong_passwords
                # are entered because with the third, a redirect should occur.
                if profile and profile.wrong_password_entered < \
                        settings.MAX_WRONG_PASSWORD:
                    profile.wrong_password_entered = 0
                    profile.save()
        # TODO: determine whether this should move to its own method.
        if self.request:
            if not self.request.session.test_cookie_worked():
                raise forms.ValidationError("Your Web browser doesn't appear to have cookies enabled. Cookies are required for logging in.")

        return self.cleaned_data
