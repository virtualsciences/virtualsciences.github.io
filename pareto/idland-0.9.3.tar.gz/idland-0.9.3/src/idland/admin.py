from idland.models import *

from django.contrib.auth.admin import UserAdmin
from django.contrib.admin.sites import AdminSite
from django.contrib import admin
from django.contrib.flatpages.admin import FlatpageForm
from django.contrib.flatpages.models import FlatPage
from django.contrib.sites.admin import SiteAdmin
from django.contrib.sites.models import Site

from idland.settingsimporter import settings_import
from django.conf import settings
User = settings_import(settings.USER)
UserCreationForm = settings_import(settings.USER_CREATION_FORM)
UserChangeForm = settings_import(settings.USER_CHANGE_FORM)

site = AdminSite()

class UserLogEntryAdmin(admin.ModelAdmin):
    list_display = ('user', 'application', 'tried_app', 'time', 'logged_in')
    search_fields = ('user__username', 'application')
    list_filter = ('application',)
    date_hierarchy = 'time'

class UserProfileInline(admin.StackedInline):
    model = UserProfile

class IDlandUserAdmin(UserAdmin):

    user_fields = ('username', 'email',)
    if settings.USER_ID == 'email':
        user_fields = ('email',)

    add_form = UserCreationForm
    form = UserChangeForm
    search_fields = user_fields + ('first_name', 'last_name')
    list_display = user_fields + ('first_name', 'last_name', 'is_staff')
    fieldsets = (
        (None, {
            'fields': user_fields
        }),
        ('Personal Info', {
            'fields': ('first_name', 'last_name')
        }),
         ('Permissions', {
            'fields': ('is_staff', 'is_active', 'is_superuser' )
        }),
        ('Important Dates', {
            'fields': ('last_login', 'date_joined')
        }),
    )
    filter_horizontal = ()
    ordering = ('email',)
    inlines = [
        UserProfileInline,
    ]

class IdlandFlatPageAdmin(admin.ModelAdmin):
    form = FlatpageForm
    fieldsets = (
        (None, {'fields': ('url', 'title', 'content', 'sites')}),
        (('Advanced options'), { 'fields': ('enable_comments', 'registration_required', 'template_name')}),
    )
    list_display = ('url', 'title')
    list_filter = ('sites', 'enable_comments', 'registration_required')
    search_fields = ('url', 'title')

site.register(FlatPage, IdlandFlatPageAdmin)
site.register(Site, SiteAdmin)
site.register(Application)
site.register(User, IDlandUserAdmin)
site.register(UserLogEntry, UserLogEntryAdmin)
