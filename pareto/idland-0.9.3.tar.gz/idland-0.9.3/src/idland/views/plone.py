import itertools
import logging
import threading
import urllib
import urllib2
from hashlib import md5
from time import time

from django.contrib.auth.decorators import login_required

from idland import models

from django.shortcuts import render_to_response
from django.template import RequestContext
from django.conf import settings

from idland.utils import get_domain
from simplejson import loads, dumps

from django.http import Http404, HttpResponse

log = logging.getLogger('idland')

def userlist(request, appname):
    """Generates a json userlist for an application."""
    user_list = []
    domain = get_domain(request)['domain']
    for app in itertools.ifilter(
            lambda a: appname.startswith(a.domain),
                    sorted(models.Application.objects.all(),
                            key=lambda a: len(a.domain), reverse=True)):
        for user_profile in app.userprofile_set.all():
            if user_profile.user.is_active:
               user_list.append(user_profile.user)

    #Remove duplicates
    user_list = list(set(user_list))

    # if user_list is empty, we assume the application does not exist
    if user_list == []:
        raise Http404('Application %s has no users.' % (appname) )

    json = dumps([ { 'openid': domain + '/' + user.username }
            for user in user_list])
    return HttpResponse(json, mimetype='application/json')




class MultiSiteSearch(object):

    """class based multi site search with threads.

    This class performs a search, given a user input:ed query
    on all sites the user has access to. A search is spawned into
    thread.
    """

    @login_required
    def __call__(self, request):
        """Searches all sites the user has access to."""
        # If we don't have a search query, show the normal page.
        try:
            request.REQUEST['search']
        except KeyError:
            return render_to_response('idland/index.html',
                    context_instance=RequestContext(request))

        query = request.REQUEST['search']
        user = request.user
        secret = md5(settings.MULTI_SITE_SEARCH_SECRET).hexdigest()
        openid_domain = get_domain(request)['domain']
        openid_url = openid_domain + '/' + user.identity
        timeout = 3.0
        # build the url
        data = {
            'query':query,
            'user': openid_url,
            'secret': secret}
        url_data = urllib.urlencode(data)
        # get a list of domains the user has acces to
        apps = user.get_profile().applications.all()
        search_results = []
        failed_domains = []
        threads = [ FetchSearchUrl(application.domain, url_data)
                for application in apps ]
        for thread in threads:
            thread.start()
        self.multi_join(threads, timeout=timeout)
        for thread in threads:
            if thread.isAlive() or thread.error:
                if thread.isAlive():
                    # is Alive doesn't raise an Error in FetchSearchUrl
                    # so we do it here.
                    log.error('Error searching: %s/?%s', thread.domain,
                            thread.url_data, exc_info=True)
                failed_domains.append(thread.domain)
            else:
                for result in thread.result:
                    search_results.append(result)

        return render_to_response('idland/index.html',
               {"search" : search_results,
                "query": query, "len_search" : len(search_results),
                "domain_errors": failed_domains },
                context_instance=RequestContext(request))


    def multi_join(self, threads, timeout):
        'Join multiple threads with shared timeout.'
        for thread in threads:
            start = time()
            thread.join(timeout)
            if timeout is not None:
                timeout -= time() - start

multi_site_search = MultiSiteSearch()

class FetchSearchUrl(threading.Thread):

    def __init__(self, domain, url_data):
        super(FetchSearchUrl, self).__init__()
        self.domain = domain
        self.url_data = url_data
        self.result = []
        self.error = False

    def run(self):
        url = 'http://' + self.domain + '/sitesearch'
        req = urllib2.Request(url, self.url_data)
        try:
            # XXX: We need a timeout for urlopen, but this is implemented in
            #       python 2.6
            response = urllib2.urlopen(req)
        except (urllib2.HTTPError, urllib2.URLError), e:
            log.error('Error searching: %s/?%s', self.domain, self.url_data,
                      exc_info=True)
            self.error = True
            return

        json = response.read()
        json_data = loads(json)
        for i in json_data:
            i['domain'] = 'http://' + self.domain
            self.result.append(i)
