from django.contrib.auth.views import redirect_to_login
from django.contrib.flatpages.models import FlatPage
from django.shortcuts import render_to_response
from django.template import RequestContext

def direct_to_flatpage(request):
    """Returns a flatpage, so that reverse can be used on them."""
    path = request.get_full_path()
    flatpage = FlatPage.objects.get(url__exact=path)
    if flatpage.registration_required and not request.user.is_authenticated():
        return redirect_to_login(path)
    return render_to_response(flatpage.template_name, {"flatpage": flatpage },
        context_instance=RequestContext(request))
