import unittest
from idland.tests.base import OpenIDTestCase

class OpenIDDiscovery(OpenIDTestCase):
    def setUp(self):
        super(OpenIDDiscovery,self).setUp()

    def tearDown(self):
        super(OpenIDDiscovery,self).tearDown()

    def test_identity(self):

        # get the django response from a valid and non existing user

        # Use a user that we defined earlier
        import urllib
        r_url = '/'+ urllib.quote(self.identity)
        r_inactive_url = '/'+ self.inactive_identity

        r_user = self.client.get(r_url)
        r_inactive_user = self.client.get(r_inactive_url)
        r_invalid_user = self.client.get('/jeroen123')

        metaheader = 'http-equiv="X-XRDS-Location"'
        yadis_url = self.server + '/' + urllib.quote(self.identity) + '/xrds'

        # Check the valid user
        self.failUnless(r_user.status_code, 200)
        self.failUnless(metaheader in r_user.content)
        self.failUnless(yadis_url in r_user.content)

        # Check the inactive user and invalid user
        self.failUnless(r_inactive_user.status_code, 200)
        self.failIf(metaheader in r_inactive_user.content)

        self.failUnless(r_invalid_user.status_code, 200)
        self.failIf(metaheader in r_invalid_user.content)

    def test_xrds(self):

        r_url = '/' + self.identity + '/xrds'
        server_url = self.server + '/app/server/'
        openid_type = 'http://specs.openid.net/auth/2.0/signon'
        import urllib
        localid = self.server + '/' + urllib.quote(self.identity)

        response = self.client.get(r_url)

        from openid.yadis.etxrd import parseXRDS, isXRDS, getPriority, \
            iterServices, expandService
        # Generatie xrdstree and parse it
        xrdstree = parseXRDS(response.content)
        element = iterServices(xrdstree)
        # Use the first element; this is the first/only service element
        priority = getPriority(element[0])
        expand = expandService(element[0])
        element_type = expand[0][0]
        element_server = expand[0][1]

        # Correct response check
        self.failUnlessEqual(response.status_code, 200)
        self.failUnlessEqual(response['Content-Type'], 'application/xml+rds')
        self.failUnless(localid in response.content)

        # Check if the xrds document is the correct yadis document
        self.failUnless(isXRDS(xrdstree))
        self.failUnlessEqual(priority, 0)
        self.failUnless(openid_type in element_type)
        self.failUnless(server_url in element_server)

    def test_yadis_non_existing_user(self):
        url ='/NonExistingUser/xrds'
        response = self.client.get(url)
        self.failIf('LocalID' in response.content)

class OpenIDAssociation(OpenIDTestCase):

    def create_fetcher(self):
        from openid.fetchers import HTTPFetcher
        class DjangoTestFetcher(HTTPFetcher):
            """A special test fetcher for django.

            The Django test framework inserts get and post directly into
            the framework, and doesn't give qualified urls to fetch since
            the webserver is not running during unittests.
            """

            def fetch(self, url, body=None, headers=None):
                from django.test.client import Client
                c = Client()


                # Client() wants the urlpath not the domainname
                from urlparse import urlsplit
                n_url = urlsplit(url)[2]

                if headers is None:
                    headers = {}

                if body is None:
                    response = c.get(n_url, **headers)
                else:
                    # parse urlencoded body to dict
                    from cgi import parse_qs as querystring_to_dict
                    post_data = querystring_to_dict(body)
                    response = c.post(n_url, post_data, **headers)

                from openid.fetchers import HTTPResponse
                resp = HTTPResponse()
                resp.headers = dict(response.items())
                resp.status = response.status_code
                resp.body = response.content
                # return the final url, which is, for us, the same as the
                # url we began with because we don't redirect in Django
                resp.final_url = url
                return resp
        return DjangoTestFetcher()

    def setUp(self):
        super(OpenIDAssociation, self).setUp()

        # Initialize an openid store in memory and use DjangoTestFetched
        # as default for tests.

        from idland.settingsimporter import settings_import
        from django.conf import settings
        User = settings_import(settings.USER)

        self.user2 = User.objects.create_user('jarno',
            'jarno@example.com', self.password)
        from django.conf import settings
        if settings.USER_ID == 'email':
            import urllib
            self.user2.identity = urllib.quote(self.user2.identity)

        from openid.store import memstore
        self.store = memstore.MemoryStore()
        from openid.fetchers import setDefaultFetcher
        setDefaultFetcher(self.create_fetcher())

        # set up applications
        from idland.models import Application

        self.app_domain = Application.objects.create(name = 'test domain',
                contact_name = 'example name',
                contact_email = 'example@example.com',
                domain = 'my.zeelandia.com')
        self.app_path = Application.objects.create(name = 'test domain+path',
                contact_name = 'example name2',
                contact_email = 'example2@example.com',
                domain = 'my.zeelandia.com/path/path')
        self.app_unused = Application.objects.create(name = 'test unused',
                contact_name = 'example unused',
                contact_email = 'example3@example.com',
                domain = 'unused.zeelandia.com/')
        self.user_p.applications.add(self.app_domain)
        self.user_p.applications.add(self.app_path)

    def tearDown(self):
        super(OpenIDAssociation, self).tearDown()


    def initiate_consumer(self, store, identity_url):
        session = {}
        from openid.cryptutil import randomString
        session['id'] = randomString(16,'0123456789abcdef')
        from openid.consumer.consumer import Consumer
        oidconsumer = Consumer(session, store)
        return Consumer.begin(oidconsumer, identity_url)

    def split_test_url(self, url):
        """Return path and post data for django test client."""
        from urlparse import urlsplit
        split = urlsplit(url)
        path = split[2]
        from cgi import parse_qs as querystring_to_dict
        data = querystring_to_dict(split[3])
        return path, data

    def instance_path_data(self, store, identity_url, realm, checkid = True):
        """Make a consumer instance via checkid_immediate or checkid_setup.

        Return the resulting url. checkid_immediate is assumed,
        checkid_setup can be done by setting checkid to False.
        """

        return_to = realm
        instance = self.initiate_consumer(store, identity_url)
        url = instance.redirectURL(realm, return_to, immediate = checkid)
        return self.split_test_url(url)

    def get_url_from_domain(self, app):
        """Give the domain name from a given application"""
        return 'http://' + app.domain

    def test_association(self):
        consumer_instance = self.initiate_consumer(self.store,
                self.identity_url)

        from openid.consumer.consumer import AuthRequest
        self.failUnlessEqual(type(consumer_instance), AuthRequest,
            'Failed AuthRequest.')
        from openid.association import Association
        self.failUnlessEqual(type(consumer_instance.assoc), Association,
            'Failed association.')

    def test_application_authorization(self):
        # test app_domain
        domain = 'http://' + self.app_domain.domain
        from idland.views.provider import OpenIDProvider
        func = OpenIDProvider().application_authorization
        allowed, app = func(self.user, domain)
        self.failUnless(allowed)
        # test app_path
        domain = 'http://' + self.app_path.domain
        allowed, app = func(self.user, domain)
        self.failUnless(allowed)
        # test app_unused
        domain = 'http://' + self.app_unused.domain
        allowed, app = func(self.user, domain)
        self.assertTrue(allowed)

    def test_openid_answer(self):
        class test_response(object):
            headers = {'content-type':'text/html'}
            code = 200
            body = 'Hoi dit is de body van het verhaal'
        from idland.views.provider import OpenIDProvider
        resp = OpenIDProvider().openid_answer(test_response())

        from django.http import HttpResponse
        self.failUnlessEqual(type(resp), HttpResponse)
        self.failUnlessEqual(resp.content, test_response.body)
        self.failUnlessEqual(resp.status_code, test_response.code)
        self.failUnlessEqual(resp['content-type'], 'text/html')


    def test_login_needed_checkid(self):
        realm = self.get_url_from_domain(self.app_domain)

        path, data = self.instance_path_data(self.store, self.identity_url,
                realm)
        response = self.client.get(path, data)

        self.failUnlessEqual(response.status_code, 302)

        response_dict = self.response_items_to_dict(response)
        #Check that user needs to be logged in
        self.failUnless('/app/login' in response_dict['Location'])

    def test_checkid_immediate_not_authorized(self):
        # client needs to be logged in
        self.client.login(username = self.identity, password = self.password)

        # Set up request immediate
        realm = self.get_url_from_domain(self.app_unused)
        path, data = self.instance_path_data(self.store, self.identity_url,
                realm)
        response = self.client.get(path, data)

        self.failUnlessEqual(response.status_code, 200)
        self.failUnless(self.app_unused.name in response.content)

    def test_checkid_immediate_authorized(self):
        # client needs to be logged in
        self.client.login(username = self.identity, password = self.password)
        # Set up request immediate
        realm = self.get_url_from_domain(self.app_domain)
        path, data = self.instance_path_data(self.store, self.identity_url,
                                             realm)
        response = self.client.get(path, data)

        self.failUnlessEqual(response.status_code, 302)

        response_dict = self.response_items_to_dict(response)
        self.failUnless(realm in response_dict['Location'])
        self.failUnless('openid.mode=id_res' in response_dict['Location'])

    def test_checkid_immediate_unknown_domain(self):
        # client needs to be logged in
        self.client.login(username = self.identity, password = self.password)

        # Set up request immediate
        realm = 'http://some.thing.example.com'
        path, data = self.instance_path_data(self.store, self.identity_url,
                realm)
        response = self.client.get(path, data)

        self.failUnlessEqual(response.status_code, 302)

        response_dict = self.response_items_to_dict(response)
        self.failUnless(realm in response_dict['Location'])
        self.assertIn('openid.mode=id_res', response_dict['Location'])

    def test_checkid_setup(self):
        # client needs to be logged in
        self.client.login(username = self.identity, password = self.password)

        # Set up request immediate
        realm = self.get_url_from_domain(self.app_domain)
        path, data = self.instance_path_data(self.store, self.identity_url,
                realm, checkid = False)
        response = self.client.get(path, data)

        self.failUnlessEqual(response.status_code, 302)

        response_dict = self.response_items_to_dict(response)
        self.failUnless(realm in response_dict['Location'])
        self.failUnless('openid.mode=id_res' in response_dict['Location'])

    def test_logging_allowed_domain(self):
        # client needs to be logged in
        self.client.login(username = self.identity, password = self.password)

        # Set up request immediate
        realm = self.get_url_from_domain(self.app_domain)
        path, data = self.instance_path_data(self.store, self.identity_url,
                realm, checkid = False)
        response = self.client.get(path, data)
        from idland.models import UserLogEntry
        entry = UserLogEntry.objects.get(pk=1)
        self.failUnlessEqual(entry.tried_app, self.app_domain.domain)
        self.failUnlessEqual(entry.user, self.user)
        self.failUnless(entry.logged_in)

    def test_logging_not_allowed_domain(self):
        # client needs to be logged in
        self.client.login(username = self.identity, password = self.password)

        # Set up request immediate
        realm = self.get_url_from_domain(self.app_unused)
        path, data = self.instance_path_data(self.store, self.identity_url,
                realm, checkid = False)
        response = self.client.get(path, data)
        from idland.models import UserLogEntry
        entry = UserLogEntry.objects.get(pk=1)
        self.failUnlessEqual(entry.tried_app, self.app_unused.domain)
        self.failUnlessEqual(entry.user, self.user)
        self.failIf(entry.logged_in)

    def test_login_unknown_domain(self):
        # client needs to be logged in
        self.client.login(username = self.identity, password = self.password)

        # Set up request immediate
        realm = 'http://unknown.example.com'
        path, data = self.instance_path_data(self.store, self.identity_url,
                realm, checkid = False)
        response = self.client.get(path, data)
        from idland.models import UserLogEntry
        entry = UserLogEntry.objects.get(pk=1)
        self.failUnlessEqual(entry.tried_app, 'unknown.example.com')
        self.failUnlessEqual(entry.user, self.user)
        self.assertTrue(entry.logged_in)

    def test_openid_request_when_other_user_is_logged_in(self):
        """Request an openidlogin when another user is logged in.

        This test checks if idland handles the scenario correctly when
        user a is logged in, but user b want to login via his openid on a
        consumer.
        """
        self.client.login(username=self.user2.identity, password=self.password)

        realm = self.get_url_from_domain(self.app_domain)
        path, data = self.instance_path_data(self.store, self.identity_url,
                realm, checkid = False)
        self.failUnless(self.client.get(path, data))

    def test_wrong_openid_url(self):
        get_data = {'openidwrong': 'iets', 'openid2':'some data'}
        response = self.client.get('/app/server/', get_data)
        self.failUnlessEqual(response.status_code, 200)
        self.failUnless('has encountered an error' in response.content)

    def test_sreg_ax_country_email_fullname(self):
        """Test for Simple Registration and attribute exchange."""
        from idland.signals import attribute_exchange_signal as aes
        URI = 'http://nice.schema.example.com'
        def attribute_exchange(sender, request_object, response_object,
                               http_request, openid_query, openid_response,
                               user, **kwargs):
            if URI in \
                    request_object.requested_attributes.keys():
                response_object.addValue(URI, 'Some thing')

        aes.connect(attribute_exchange)

        self.user_p.country = 'Netherlands'
        self.user.first_name = 'Roland'
        self.user.last_name= 'van Laar'

        self.user.save()
        self.user_p.save()

        self.client.login(username = self.identity, password=self.password)

        realm = self.get_url_from_domain(self.app_domain)
        instance = self.initiate_consumer(self.store, self.identity_url)

        from openid.extensions.sreg import SRegRequest
        from openid.extensions.ax import FetchRequest, AttrInfo

        instance.addExtension(SRegRequest(
                required=['email', 'fullname', 'country']))
        fr = FetchRequest()
        at = AttrInfo(URI,
                      alias='ext0')
        fr.add(at)
        instance.addExtension(fr)

        url = instance.redirectURL(realm, realm, immediate = True)
        path, data = self.split_test_url(url)
        response = self.client.get(path, data)
        response_dict = self.response_items_to_dict(response)
        self.assertIn('Roland+van+Laar', response_dict['Location'])
        self.failUnless(self.user_p.country in response_dict['Location'])
        self.failUnless('roland.van.laar%40pareto.nl'
                        in response_dict['Location'])
        self.assertIn('ext0', response_dict['Location'])
        self.assertIn('Some+thing', response_dict['Location'])

    def test_sreg_country(self):
        """Test for Simple Registration."""

        self.user_p.country = 'Netherlands'

        self.user.save()
        self.user_p.save()


        self.client.login(username = self.identity, password=self.password)

        realm = self.get_url_from_domain(self.app_domain)
        instance = self.initiate_consumer(self.store, self.identity_url)

        from openid.extensions.sreg import SRegRequest

        instance.addExtension(SRegRequest(required=['country']))
        url = instance.redirectURL(realm, realm, immediate = True)
        path, data = self.split_test_url(url)
        response = self.client.get(path, data)
        response_dict = self.response_items_to_dict(response)
        self.assertIn('Netherlands', response_dict['Location'])
        self.failIf('roland.van.laar%40pareto.nl'
                    in response_dict['Location'])

    def test_sreg_not_available_uri(self):
        """Test to ensure that requests for uris that aren't used are handled
           correctly."""

        self.client.login(username = self.uname, password=self.password)

        realm = self.get_url_from_domain(self.app_domain)
        instance = self.initiate_consumer(self.store, self.identity_url)

        from openid.extensions.sreg import SRegRequest
        from openid.extensions.ax import FetchRequest, AttrInfo

        instance.addExtension(SRegRequest(
                required=['email', 'fullname', 'country']))
        fr = FetchRequest()
        at = AttrInfo('http://www.zeelandia.nl/schema/unused',
                      alias='not known')
        fr.add(at)
        instance.addExtension(fr)

        url = instance.redirectURL(realm, realm, immediate = True)
        path, data = self.split_test_url(url)
        response = self.client.get(path, data)
        self.failUnlessEqual(response.status_code, 302)


    def test_NoneType_bug_mode(self):
        """Check if a normal GET to /app/server/ doesn't
        throw an except but returns a 400."""
        response = self.client.get('/app/server/')
        self.failUnlessEqual(response.status_code, 400)


class TestIdentityURLS(OpenIDTestCase):

    def test_identity_page(self):
        # The identity page should be accessible using an email address
        from django.core.urlresolvers import reverse
        self.assertEqual(
            reverse('idland.views.provider.identity',
                    args=('rudi.krahl.junkzeelandia@t-online.de',)),
            '/rudi.krahl.junkzeelandia%40t-online.de')


def suite():
    s = unittest.TestSuite()
    ms = unittest.makeSuite
    s.addTest(ms(OpenIDDiscovery))
    s.addTest(ms(OpenIDAssociation))
    s.addTest(ms(TestIdentityURLS))
    return s
