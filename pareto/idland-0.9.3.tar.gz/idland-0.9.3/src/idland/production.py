
from idland.settings import *

DEBUG=False
TEMPLATE_DEBUG=DEBUG
EMAIL_HOST='localhost'
