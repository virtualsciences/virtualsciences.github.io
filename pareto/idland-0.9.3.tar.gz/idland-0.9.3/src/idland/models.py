from django import dispatch
from django.db import models
from idland.utils import new_expiry_date

from idland.settingsimporter import settings_import
from django.conf import settings
User = settings_import(settings.USER)


class Application(models.Model):
    name = models.CharField(max_length=100)
    contact_name = models.CharField(max_length=100)
    contact_email = models.EmailField()
    domain = models.CharField(max_length=100, unique=True,
            help_text=("The application url without http(s)"))
    image = models.ImageField(upload_to='app')
    apptype = models.CharField(max_length=64,
                               choices=settings.APPLICATION_TYPES)

    def __unicode__(self):
        return u'%s (%s)' % (self.name, self.domain)

class OldPassword(models.Model):
    password = models.CharField(max_length=128)

    def __unicode__(self):
        return u'%s' % self.password


class UserProfile(models.Model):
    user = models.ForeignKey(User, unique=True)
    password_expiry = models.DateField(default = new_expiry_date())
    applications = models.ManyToManyField(Application, blank=True, null=True)
    old_passwords = models.ManyToManyField(OldPassword, blank=True, null=True)
    wrong_password_entered = models.IntegerField(default=0)
    country = models.CharField(max_length=100, blank=True, null=True)

    def __unicode__(self):
        return u'%s' % self.user.username


class UserLogEntry(models.Model):
    user = models.ForeignKey(User)
    application = models.ForeignKey(Application, blank=True, null=True)
    tried_app = models.CharField(max_length=100, blank=True, null=True,
            help_text=("The website that requested authorization"))
    time = models.DateTimeField(auto_now_add=True)
    logged_in = models.BooleanField()

    def __unicode__(self):
        return u'%s, %s, %s' % (self.user, self.application, self.time)

def user_post_save(sender, instance, **kwargs):
    """Signal to make sure that every user has a userprofile.

    A user profile is required for the password expiry functionality."""

    profile, new = UserProfile.objects.get_or_create(user=instance)

def user_post_init(sender, instance, **kwargs):
    """Put an identity object on the User model.

    Makes it more generic to switch between 'email' or 'username' logins."""

    if instance.is_anonymous():
        identity = ''
    elif settings.USER_ID == 'email':
        identity = instance.email
    else:
        identity = instance.username

    instance.identity = identity


#signals.
models.signals.post_save.connect(user_post_save, User)
models.signals.post_init.connect(user_post_init, User)

