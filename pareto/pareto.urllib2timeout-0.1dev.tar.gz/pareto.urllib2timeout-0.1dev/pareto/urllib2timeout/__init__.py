import socket
import settings

socket.setdefaulttimeout(settings.TIMEOUT)
