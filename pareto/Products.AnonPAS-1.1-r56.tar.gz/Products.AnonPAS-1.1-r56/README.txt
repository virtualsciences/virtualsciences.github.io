Introduction
============

It gives anonymous users an automatic userid + roles
