PROJECTNAME = 'AnonPAS'

# Set to False in a production environment
DEBUG=False

PLUGIN_ID = 'anon_pas_plugin'

