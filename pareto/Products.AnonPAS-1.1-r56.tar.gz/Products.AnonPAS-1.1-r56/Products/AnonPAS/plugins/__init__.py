""" Being there """
