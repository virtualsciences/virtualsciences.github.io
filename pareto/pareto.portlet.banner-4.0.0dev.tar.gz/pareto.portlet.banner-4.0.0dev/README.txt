pareto.bannerportlet Package Readme
=========================

Overview
--------

A banner portlet
