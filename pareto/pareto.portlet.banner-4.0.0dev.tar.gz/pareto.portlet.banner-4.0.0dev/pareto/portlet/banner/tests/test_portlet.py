from zope.component import getUtility, getMultiAdapter

from plone.portlets.interfaces import IPortletType
import os

from plone.portlets.interfaces import IPortletManager
from plone.portlets.interfaces import IPortletAssignment
from plone.portlets.interfaces import IPortletDataProvider
from plone.portlets.interfaces import IPortletRenderer

from plone.app.portlets.storage import PortletAssignmentMapping

from pareto.portlet.banner import bannerportlet

from pareto.portlet.banner.tests.base import TestCase

class TestPortlet(TestCase):

    def afterSetUp(self):
        self.setRoles(('Manager',))

    def test_portlet_type_registered(self):
        portlet = getUtility(IPortletType, name='pareto.portlet.banner.BannerPortlet')
        self.assertEquals(portlet.addview, 'pareto.portlet.banner.BannerPortlet')

    def test_interfaces(self):
        # TODO: Pass any keywoard arguments to the Assignment constructor
        portlet = bannerportlet.Assignment()
        self.failUnless(IPortletAssignment.providedBy(portlet))
        self.failUnless(IPortletDataProvider.providedBy(portlet.data))

    def test_invoke_add_view(self):
        portlet = getUtility(IPortletType, name='pareto.portlet.banner.BannerPortlet')
        mapping = self.portal.restrictedTraverse('++contextportlets++plone.leftcolumn')
        for m in mapping.keys():
            del mapping[m]
        addview = mapping.restrictedTraverse('+/' + portlet.addview)

        # TODO: Pass a dictionary containing dummy form inputs from the add form
        addview.createAndAdd(data={})

        self.assertEquals(len(mapping), 1)
        self.failUnless(isinstance(mapping.values()[0], bannerportlet.Assignment))

    # NOTE: This test can be removed if the portlet has no edit form
    def test_invoke_edit_view(self):
        mapping = PortletAssignmentMapping()
        request = self.folder.REQUEST

        mapping['foo'] = bannerportlet.Assignment()
        editview = getMultiAdapter((mapping['foo'], request), name='edit')
        self.failUnless(isinstance(editview, bannerportlet.EditForm))

    def test_obtain_renderer(self):
        context = self.folder
        request = self.folder.REQUEST
        view = self.folder.restrictedTraverse('@@plone')
        manager = getUtility(IPortletManager, name='plone.rightcolumn', context=self.portal)
        
        # TODO: Pass any keywoard arguments to the Assignment constructor
        assignment = bannerportlet.Assignment()

        renderer = getMultiAdapter((context, request, view, manager, assignment), IPortletRenderer)
        self.failUnless(isinstance(renderer, bannerportlet.Renderer))
        
        
class TestRenderer(TestCase):
    
    def afterSetUp(self):
        self.setRoles(('Manager',))

    def renderer(self, context=None, request=None, view=None, manager=None, assignment=None):
        context = context or self.folder
        request = request or self.folder.REQUEST
        view = view or self.folder.restrictedTraverse('@@plone')
        manager = manager or getUtility(IPortletManager, name='plone.rightcolumn', context=self.portal)
        
        # TODO: Pass any default keywoard arguments to the Assignment constructor
        assignment = assignment or bannerportlet.Assignment()
        return getMultiAdapter((context, request, view, manager, assignment), IPortletRenderer)

    def test_flash_support(self):
        mapping = self.portal.restrictedTraverse('++contextportlets++plone.leftcolumn')
        
        flash = open(os.path.join(os.path.dirname(__file__), 'ball.swf'), 'rb').read()
        
        assignment = bannerportlet.Assignment(img=flash, width=200, height=200)
        mapping['foo'] = assignment
        
        assignment.context_path = '/'.join(self.folder.getPhysicalPath())
        
        r = self.renderer(context=self.portal, assignment=assignment)
        r = r.__of__(self.folder)
        r.update()
        output = r.render()

        # There is no object tag in the rendered result. This is because we use the swfobject Javascript library to create
        # the tags we need. We do this to avoid a problem with Internet Explorer 6/7 that do not play Flash movies directly
        # unless embeded in a special way using this Javascript.
        self.failUnless('<script type="text/javascript">swfobject.embedSWF(' in output)
        # Width and height are arguments to the function shown above. The 9.0.0 in the example below referes to the 
        # required Flash version.
        self.failUnless("'200', '200', '9.0.0'" in output)
        
class TestProfile(TestCase):

    def afterSetUp(self):
        self.setRoles(('Manager',))

    def test_javascript_registration(self):
        # The portlet requires that swfobject is installed in the portal_javascript tool
        self.assert_('++resource++pareto.portlet.banner.scripts/swfobject.js'
                     in self.portal.portal_javascripts.getResourcesDict())
        
def test_suite():
    from unittest import TestSuite, makeSuite
    suite = TestSuite()
    suite.addTests((makeSuite(TestPortlet),
                    makeSuite(TestRenderer),
                    makeSuite(TestProfile)))
    return suite
