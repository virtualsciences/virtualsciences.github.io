from zope.interface import implements, Interface

from Products.Five import BrowserView
from Products.CMFCore.utils import getToolByName

from pareto.governmentplayer import governmentplayerMessageFactory as _


class Igovernmentplayer_View(Interface):
    """
    governmentplayer_view view interface
    """

    def test():
        """ test method"""


class governmentplayer_View(BrowserView):
    """
    governmentplayer_view browser view
    """
    implements(Igovernmentplayer_View)

    def __init__(self, context, request):
        self.context = context
        self.request = request

    @property
    def portal_catalog(self):
        return getToolByName(self.context, 'portal_catalog')

    @property
    def portal(self):
        return getToolByName(self.context, 'portal_url').getPortalObject()

    def test(self):
        """
        test method
        """
        dummy = _(u'a dummy string')

        return {'dummy': dummy}
    
    
    def dynamicscript(self):
        
        template="""
        // <![CDATA[
        var movie = new GovVid("uniqueid", "400", "224");
        movie.addImage("%s"); // is used by flashplayer
        movie.addMovie("%s"); //mp4
        movie.addMovie("%s"); //wmv
        movie.addMovie("%s"); //3gp
        movie.addMovie("%s"); //flv path calculated from flash file location, or url
        movie.addCaption("flv","%s/@@governmentplayer.srt"); //caption for flv file
        movie.write("movie"); // writes movie to divID

         // uncomment or delete if you use content-disposition on apache server, or if you use external movie files (like pilot video)
         // this function can be placed in your init function if you use iis with asp (window.onload)
         // openBinary(); // function to open your alternative movies in content-disposition.asp
         
        // ]]>
        """
        
        flv = self.context.getFlvUrl()
        mp4 = self.context.getMp4Url()
        wmv = self.context.getWmvUrl()
        gp3 = self.context.get3gpUrl()
        img = self.context.getImage().absolute_url()
        srt = self.context.absolute_url()
        
        return template % (img, mp4, wmv, gp3, flv, srt)

        
class governmentplayer_Srt(BrowserView):
    """
    governmentplayer_srt browser view
    """    
    def __call__(self):       
        self.request.response.setHeader('Content-Type', 'text/plain')
        srtfile = self.context.getField("srtUrl").get(self.context).data
        self.context.getField("srtUrl").get(self.context).data
        return srtfile