"""Definition of the Government Player Clip content type
"""

from zope.interface import implements, directlyProvides

from Products.Archetypes import atapi
from Products.ATContentTypes.content import base
from Products.ATContentTypes.content import schemata
from Products.ATContentTypes.content.document import ATDocumentSchema
from Products.ATContentTypes.content.base import ATCTFileContent
from Products.ATContentTypes.configuration import zconf

from pareto.governmentplayer import governmentplayerMessageFactory as _
from pareto.governmentplayer.interfaces import IGovernmentPlayerClip
from pareto.governmentplayer.config import PROJECTNAME
from Products.validation import V_REQUIRED

GovernmentPlayerClipSchema = ATDocumentSchema.copy() + atapi.Schema((

    atapi.ImageField('image',
               required=True,
               languageIndependent=True,
               storage = atapi.AnnotationStorage(migrate=True),
               swallowResizeExceptions = zconf.swallowImageResizeExceptions.enable,
               pil_quality = zconf.pil_config.quality,
               pil_resize_algo = zconf.pil_config.resize_algo,
               max_size = zconf.ATImage.max_image_dimension,
               sizes= {'large'   : (768, 768),
                       'preview' : (400, 400),
                       'mini'    : (200, 200),
                       'thumb'   : (128, 128),
                       'tile'    :  (64, 64),
                       'icon'    :  (32, 32),
                       'listing' :  (16, 16),
                      },
               validators = (('isNonEmptyFile', V_REQUIRED),
                             ('checkImageMaxSize', V_REQUIRED)),
               widget = atapi.ImageWidget(
                        description = '',
                        label= _(u'label_image', default=u'Image'),
                        show_content_type = False,)),
                 
    atapi.StringField('flvUrl',
        required=True,
        searchable=True,
        default = "http://",
        # either mailto, absolute url or relative url
        validators = ('isURL',),
        widget = atapi.StringWidget(
            description = '',
            label = _(u'label_flashurl', default=u'Flash URL')
            )),           

#    atapi.StringField('srtUrl',
#        required=True,
#        searchable=True,
#        default = "http://",
        # either mailto, absolute url or relative url
#        validators = ('isURL',),
#        widget = atapi.StringWidget(
#            description = '',
#            label = _(u'label_srtUrl', default=u'Flash Caption URL')
#            )),           

    atapi.FileField('srtUrl',
              required=True,
              searchable=True,
              languageIndependent=True,
              storage = atapi.AnnotationStorage(migrate=True),
              validators = (('isNonEmptyFile', V_REQUIRED),
                             ('checkFileMaxSize', V_REQUIRED)),
              widget = atapi.FileWidget(
                        description = '',
                        label=_(u'label_srtUrl', default=u'Flash Caption File'),
                        show_content_type = False,)),

    atapi.StringField('mp4Url',
        required=True,
        searchable=True,
        default = "http://",
        # either mailto, absolute url or relative url
        validators = ('isURL',),
        widget = atapi.StringWidget(
            description = '',
            label = _(u'label_mp4url', default=u'Apple Quicktime URL')
            )),

    atapi.StringField('wmvUrl',
        required=True,
        searchable=True,
        default = "http://",
        # either mailto, absolute url or relative url
        validators = ('isURL',),
        widget = atapi.StringWidget(
            description = '',
            label = _(u'label_wmvurl', default=u'Windows Media Player URL')
            )),

    atapi.StringField('3gpUrl',
        required=True,
        searchable=True,
        default = "http://",
        # either mailto, absolute url or relative url
        validators = ('isURL',),
        widget = atapi.StringWidget(
            description = '',
            label = _(u'label_3gpurl', default=u'Mobiele video URL')
            )),
            
    atapi.StringField('duration',
        required=True,
        searchable=True,
        default = "",
        widget = atapi.StringWidget(
            description = '',
            label = _(u'label_duur', default=u'Duur')
            )),
    
    atapi.StringField('playersubject',
        required=True,
        searchable=True,
        default = "",
        widget = atapi.StringWidget(
            description = '',
            label = _(u'label_onderwerp', default=u'Onderwerp')
            )),
    
    atapi.StringField('source',
        required=True,
        searchable=True,
        default = "",
        widget = atapi.StringWidget(
            description = '',
            label = _(u'label_bron', default=u'Bron')
            )),

))

# Set storage on fields copied from ATContentTypeSchema, making sure
# they work well with the python bridge properties.

GovernmentPlayerClipSchema['title'].storage = atapi.AnnotationStorage()
GovernmentPlayerClipSchema['description'].storage = atapi.AnnotationStorage()

schemata.finalizeATCTSchema(GovernmentPlayerClipSchema, moveDiscussion=False)

class GovernmentPlayerClip(base.ATCTContent):
    """Government Player video or audio clip"""
    implements(IGovernmentPlayerClip)

    portal_type = "Government Player Clip"
    schema = GovernmentPlayerClipSchema

    title = atapi.ATFieldProperty('title')
    description = atapi.ATFieldProperty('description')
    
    
    def __bobo_traverse__(self, REQUEST, name):
        """Transparent access to image scales
        """
        if name.startswith('image'):
            field = self.getField('image')
            image = None
            if name == 'image':
                image = field.getScale(self)
            else:
                scalename = name[len('image_'):]
                if scalename in field.getAvailableSizes(self):
                    image = field.getScale(self, scale=scalename)
            if image is not None and not isinstance(image, basestring):
                # image might be None or '' for empty images
                return image

        return base.ATCTContent.__bobo_traverse__(self, REQUEST, name)    

atapi.registerType(GovernmentPlayerClip, PROJECTNAME)
