pareto.governmentplayer Package Readme
=========================

Overview
--------


