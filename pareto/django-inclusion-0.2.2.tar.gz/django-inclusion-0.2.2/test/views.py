from django.views.generic.simple import direct_to_template


def tagtester(request):
    return direct_to_template(request, 'tester.html')
