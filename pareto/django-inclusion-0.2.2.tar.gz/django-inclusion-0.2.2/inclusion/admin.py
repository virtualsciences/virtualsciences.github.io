from django.contrib import admin
from inclusion import models

class Admin(admin.ModelAdmin):
    pass

for cls in (models.Fragment, models.Parameter):
    admin.site.register(cls, Admin)

