from setuptools import setup, find_packages

version = '0.2.2'

setup(name='django-inclusion',
      version=version,
      description="Configurable inclusions using Django template tags.",
      long_description="Configurable inclusions using Django template tags.",
      classifiers=[
        "Programming Language :: Python",
        ],
      keywords='',
      author='Jan Murre',
      author_email='jan.murre@pareto.nl',
      url='http://svn.plone.org/svn/collective/',
      license='GPL',
      packages=find_packages(exclude=['ez_setup']),
      include_package_data=True,
      zip_safe=False,
      install_requires=[
          'setuptools',
          # -*- Extra requirements: -*-
      ],
      entry_points="""
      # -*- Entry points: -*-
      """,
      )
