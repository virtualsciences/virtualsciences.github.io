from Products.CMFPlone.tests import PloneTestCase
import os
import xmlcontent

from Testing import ZopeTestCase as ztc
from Products.Five import zcml
from Products.Five import fiveconfigure
from Products.PloneTestCase import PloneTestCase as ptc
from Products.PloneTestCase.layer import onsetup

@onsetup
def setup_product():
    """Set up additional products and ZCML required to test this product.

    The @onsetup decorator causes the execution of this body to be deferred
    until the setup of the Plone site testing layer.
    """

    fiveconfigure.debug_mode = True
    zcml.load_config('configure.zcml', xmlcontent)
    zcml.load_config("configure.zcml", xmlcontent.examples)
    fiveconfigure.debug_mode = False
    ztc.installPackage('xmlcontent')

setup_product()
ptc.setupPloneSite(extension_profiles=("xmlcontent:default",), id='examples')

class TestFullExample(PloneTestCase.PloneTestCase):

    def getPortal(self):
        return self.app.examples

    def afterSetUp(self):
        self.setRoles(['Manager'])
        self.portal.invokeFactory('ATFilesystemGateway', id='someid')
        self.content = self.portal.someid
        path = os.path.split(xmlcontent.examples.__file__)[0]
        self.content.setFileSystemDir(path)

    def testView(self):
        view = self.content.unrestrictedTraverse('applepie/view.html')
        self.failUnless('<h1>Apple pie</h1>' in view())

def test_suite():
    from unittest import TestSuite, makeSuite
    suite = TestSuite()
    suite.addTest(makeSuite(TestFullExample))
    return suite
