# Normal imports
from Acquisition import aq_parent
from Products.CMFPlone.tests import PloneTestCase
from Testing import ZopeTestCase
from Testing.ZopeTestCase import user_name
import os
import xmlcontent
from xmlcontent.interfaces import IContentGateway
from Products.Five.traversable import FakeRequest
from Products.Five import zcml
from zope.publisher.interfaces import IPublishTraverse
from zope.component import queryMultiAdapter

class TestATFileSystemGateway(PloneTestCase.PloneTestCase):

    def afterSetUp(self):
        self.addProduct('xmlcontent')
        self.setRoles(['Manager'])
        self.folder.invokeFactory('ATFilesystemGateway', id='someid')
        self.content = self.folder.someid

    def testGatewayAdapter(self):
        self.content.setFileSystemDir('test')
        adapted = IContentGateway(self.content)
        self.failUnlessEqual(adapted.filesystemdir,
                             self.content.getFileSystemDir())

    def testGatewayTraversal(self):
        path = os.path.join(os.path.split(xmlcontent.__file__)[0], 'examples')
        self.content.setFileSystemDir(path)
        recipe = queryMultiAdapter((self.content, FakeRequest()),
                                   IPublishTraverse).publishTraverse(
                                       None, 'applepie')
        self.failUnlessEqual(recipe.getroot().attrib['name'], 'Apple pie')

def test_suite():
    from unittest import TestSuite, makeSuite
    suite = TestSuite()
    suite.addTest(makeSuite(TestATFileSystemGateway))
    return suite
