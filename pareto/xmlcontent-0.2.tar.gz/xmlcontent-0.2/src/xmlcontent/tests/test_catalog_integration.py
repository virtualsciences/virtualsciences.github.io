import os
import xmlcontent
from xmlcontent.tests.base import XMLContentTestCase

class TestCatalog(XMLContentTestCase):

    def afterSetUp(self):
        self.setRoles(['Manager'])
        self.folder.invokeFactory('ATFilesystemGateway', id='someid')
        self.content = self.folder.someid
        path = os.path.join(os.path.split(xmlcontent.__file__)[0], 'examples')
        self.content.setFileSystemDir(path)
        self.catalog = self.portal.portal_catalog

    def test_rebuild_catalog(self):
        # The catalog has a rebuild option. This will also find and index our
        # XML based content.
        self.catalog.clearFindAndRebuild()
        results = self.catalog(Title='Apple pie')
        self.failUnlessEqual(len(results), 1)
        brain = results[0]
        self.failUnlessEqual(brain.Title, 'Apple pie')
        self.failUnless(brain.getPath().endswith('/applepie'))

def test_suite():
    from unittest import TestSuite, makeSuite
    suite = TestSuite()
    suite.addTest(makeSuite(TestCatalog))
    return suite
