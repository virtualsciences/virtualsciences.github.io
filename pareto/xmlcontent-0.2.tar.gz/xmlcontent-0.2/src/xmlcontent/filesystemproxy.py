from elementtree import ElementTree
from xmlcontent.contentproxy import ContentProxy
from xmlcontent.staticproxy import StaticContentProxy
from xmlcontent.interfaces import IContentGateway
import os

class FilesystemProxy(object):
    def __init__(self, context):
        self.context = context

    def _path(self):
        return IContentGateway(self.context).filesystemdir

    def load(self, name):
        path = self._path()
        if not path:
            raise IOError

        filename = os.path.join(path, name)

        if os.path.exists(filename):
            return StaticContentProxy(self.context, filename)

        return ContentProxy(self.context, ElementTree.parse(filename+'.xml').getroot(), name)

    def contentnames(self):
        return [name[:-4] for name in os.listdir(self._path())
                if name.endswith('.xml')]
