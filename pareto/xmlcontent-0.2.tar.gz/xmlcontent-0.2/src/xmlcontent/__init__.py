from Products.CMFCore import utils as cmf_utils
from Products.Archetypes.atapi import process_types, listTypes
from xmlcontent import config

def initialize(context):
    import content
    content # Pyflakes

    content_types, constructors, ftis = process_types(
        listTypes(config.PKG_NAME), config.PKG_NAME)

    for atype, constructor in zip(content_types, constructors):
        cmf_utils.ContentInit("%s: %s" % (config.PKG_NAME,
                                          atype.__name__),
            content_types = (atype,),
            permission = config.ADD_PERMISSIONS[atype.__name__],
            extra_constructors = (constructor,),
            ).initialize(context)
