import logging
from logging import Formatter
import time
from idland import settings

class IdlandFormat(Formatter):
    def formatTime(self, record, datefmt=None):
        ct = self.converter(record.created)
        if datefmt:
            s = time.strftime(datefmt, ct)
        else:
            t = time.strftime("%H:%M:%S %Y-%m-%d" , ct)
            s = "[%s]" % (t)
        return s

log = logging.getLogger('idland')
handler = logging.FileHandler(settings.IDLAND_LOGFILE)
f = IdlandFormat("%(asctime)s %(levelname)s  %(message)s")
handler.setFormatter(f)
handler.setLevel(logging.DEBUG)
log.addHandler(handler)
