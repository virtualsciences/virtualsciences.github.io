import unittest
from idland.tests.base import OpenIDTestCase

class IDLandUser(OpenIDTestCase):
    def setUp(self):
        super(IDLandUser, self).setUp()

    def tearDown(self):
        super(IDLandUser, self).tearDown()

    def error_is(self, form):
        """Return formerror from SetExtendedPasswordForm and ChangePasswordForm.
        """
        return form.errors.values()[0][0]

    def password_dict(self, pw):
        """Generate a new dict for SetExtendedPasswordForm."""
        return {'new_password1':pw, 'new_password2':pw}

    def old_password_dict(self, old_pw, new_pw):
        """Generate a new dict to change the password."""
        data = self.password_dict(new_pw)
        data['old_password']=old_pw
        return data

    def test_change_password_not_logged_in(self):
        """I test if the user needs to be logged in to change the password.
        """
        new_pw = 'sUp3rS3cre7!'
        old_pw = self.password
        post_data = self.old_password_dict(old_pw, new_pw)
        response = self.client.post('/app/change_password/', post_data)

        response_dict = self.response_items_to_dict(response)

        self.failUnlessEqual(response.status_code, 302)
        self.failUnless('/app/login/?next=/app/change_password/' in
                response_dict['Location'])

    def test_change_password_logged_in(self):
        """I check if the user can change the password."""

        self.client.login(username = self.identity, password = self.password)

        new_pw = 'sUp3rS3cre7!'
        old_pw = self.password
        post_data = self.old_password_dict(old_pw, new_pw)
        response = self.client.post('/app/change_password/', post_data)
        response_dict = self.response_items_to_dict(response)

        self.failUnlessEqual(response.status_code, 302)
        self.failUnless('/app/password_change_succes' in
                        response_dict['Location'])

        from django.contrib.auth import authenticate
        user=authenticate(username = self.identity, password = new_pw)
        self.failUnlessEqual(user.email,  self.user.email)

    def test_reset_password(self):
        """I test if the password can be reset.

        This happens via an email. I extract the reset url from theg
        email and post a new password. After that I check if the
        user can login with the new password.
        """
        post_data = {'email' : self.user.email }
        response = self.client.post('/app/password_reset/', post_data)

        response_items = self.response_items_to_dict(response)

        self.failUnlessEqual(response.status_code, 302)
        self.failUnless('testserver/app/password_reset_done' in
                response_items['Location'])
        from django.core import mail
        self.failUnlessEqual(len(mail.outbox), 1)

        import re
        url_re = re.compile(
                'http://openid.pareto.nl/app/password_reset_confirm/.+')
        message = mail.outbox[0].message().get_payload()
        #Remove =\n from message because emailencoding puts it in the reseturl.
        message = message.replace('=\n', '')
        reset_url = url_re.search(message).group()
        self.failUnless(reset_url)


        from idland.utils import get_path
        # get the path because Client() only deals with urlpaths.
        reset_url = get_path(reset_url)
        new_pw = 'sUperS3cR4T'
        reset_post_data = self.password_dict(new_pw)
        reset_response = self.client.post(reset_url, reset_post_data)

        response_items = self.response_items_to_dict(reset_response)

        self.failUnlessEqual(reset_response.status_code, 302)
        self.failUnless('testserver/app/password_reset_complete' in
                response_items['Location'])

        from django.contrib.auth import authenticate
        user = authenticate(username = self.identity, password = new_pw)
        self.failUnlessEqual(user.id,  self.user.id)

    def test_password_expired(self):
        import datetime
        old_date = datetime.date.today() - datetime.timedelta(days=1)
        self.user_p.password_expiry = old_date
        self.user_p.save()

        class request(object):
            user = self.user

        # lambda returns a HttpResponseRedirect when the password is expired.
        from idland.middleware import UserExpiry
        expiry = lambda a: UserExpiry().process_view(request(), a, (), {})
        # view needs redirect
        from idland.views.provider import identity
        response = expiry(identity)
        from django.http import HttpResponseRedirect
        self.failUnlessEqual(type(response), HttpResponseRedirect)

        # view is not to be redirected
        # when the password is changed
        from idland.views.auth import password_change
        response = expiry(password_change)
        self.failUnlessEqual(response, None)
        # when the password is reset via mail
        from django.contrib.auth.views import password_reset_confirm
        response = expiry(password_reset_confirm)
        self.failUnlessEqual(response, None)
        # and when a settings.MEDIA_URL is requested
        from django.views.static import serve
        response = expiry(serve)
        self.failUnlessEqual(response, None)

    def test_password_length(self):
        # test len < 8
        pw = '2Sm'
        data = self.password_dict(pw)
        from idland.forms import SetExtendedPasswordForm
        form = SetExtendedPasswordForm(self.user, data)
        self.failIf(form.is_valid())
        error = self.error_is(form)
        self.failUnless('minimum requirements' in error)

    def test_password_digit(self):
        # test no digit
        pw = 'AASDertdS'
        data = self.password_dict(pw)
        from idland.forms import SetExtendedPasswordForm
        form = SetExtendedPasswordForm(self.user, data)
        self.failIf(form.is_valid())
        error = self.error_is(form)
        self.failUnless('minimum requirements' in error)

    def test_password_letter(self):
        # test no letter
        pw = '286860995758'
        data = self.password_dict(pw)
        from idland.forms import SetExtendedPasswordForm
        form = SetExtendedPasswordForm(self.user, data)
        self.failIf(form.is_valid())
        error = self.error_is(form)
        self.failUnless('minimum requirements' in error)

    def test_password_is_correct(self):
        # test no lower letter
        pw = '12abBDF95fd'
        data = self.password_dict(pw)
        from idland.forms import SetExtendedPasswordForm
        form = SetExtendedPasswordForm(self.user, data)
        self.failUnless(form.is_valid())

    def test_password_change_form_invalid_password(self):
        # test wrong old password
        new_pw = '28686PaajdlROWJFM'
        old_pw = 'something invalid'
        data = self.old_password_dict(old_pw, new_pw)
        from idland.forms import PasswordChangeForm
        form = PasswordChangeForm(self.user, data)
        self.failIf(form.is_valid())
        error = self.error_is(form)
        self.failUnless('incorrectly' in error)

    def test_password_change_form_valid_password(self):
        # test no lower letter
        new_pw = '28686PaajdlROWJFM'
        old_pw = self.password
        data = self.old_password_dict(old_pw, new_pw)
        from idland.forms import PasswordChangeForm
        form = PasswordChangeForm(self.user, data)
        self.failUnless(form.is_valid())

    def test_password_reuse(self):
        new_pw = '28686PaajdlROWJFM'
        old_pw = self.password
        data = self.old_password_dict(old_pw, new_pw)
        from idland.forms import PasswordChangeForm
        form = PasswordChangeForm(self.user, data)
        self.failUnless(form.is_valid())
        # submit the form again with the same password and it should fail.
        form = PasswordChangeForm(self.user, data)
        self.failIf(form.is_valid())

    def test_password_reuse_extended_form(self):
        new_pw = '28686PaajdlROWJFM'
        data = self.password_dict(new_pw)
        from idland.forms import SetExtendedPasswordForm as SEPF
        form = SEPF(self.user, data)
        self.failUnless(form.is_valid())
        form.save()
        form = SEPF(self.user, data)
        self.failIf(form.is_valid())

    def test_password_non_reuse(self):
        new_pw =  pw = '28686PaajdlROWJFM'
        old_pw = self.password
        data = self.old_password_dict(old_pw, new_pw)
        from idland.forms import PasswordChangeForm
        form = PasswordChangeForm(self.user, data)
        self.failUnless(form.is_valid())
        new_pw = '1234MBldkdj'
        old_pw = pw
        # submit the form again with the same password and it should fail.
        form = PasswordChangeForm(self.user, data)
        self.failIf(form.is_valid())

    def test_non_matching_password(self):
        new_pw = 'i12oi09'
        new_pw2 = 'ikdhjfk9875'
        pw_dict = {'new_password1':new_pw, 'new_password2':new_pw2 }
        pw_dict['old_password'] = self.password
        from idland.forms import PasswordChangeForm
        form = PasswordChangeForm(self.user, pw_dict)
        self.failIf(form.is_valid())

class PasswordResetFormTest(OpenIDTestCase):
    """Test class for PasswordResetForm.

    Most of it gets tested with a password reset one edge case doesn't."""

    def test_clean_email(self):
        from idland.forms import PasswordResetForm as PRF
        data = {'email':'example@example.com'}
        form = PRF(data)
        self.failIf(form.is_valid())
        self.assertIn('registered', form.errors.as_text())

class MaxThreeLogins(OpenIDTestCase):
    """Test class for a maximum of three wrong log-ins."""

    def test_password_unusable(self):
        data = {
                'username' : self.identity,
                'password' : 'joep'
                }
        # get the max
        for i in xrange(3):
            response = self.client.post('/app/login/',data)
            self.assertEquals(response.status_code, 200)
        from idland.models import UserProfile
        prof = UserProfile.objects.get(pk=1)
        self.failUnlessEqual(prof.wrong_password_entered, 3)
        self.failIf(prof.user.has_usable_password())

    def test_password_reset_counter(self):
        data1 = {
                'username': self.identity,
                'password' : 'joep'
                }

        data2 = {
                'username': self.identity,
                'password' : self.password
                }

        response = self.client.post('/app/login/', data1)
        self.assertEquals(response.status_code, 200)
        from idland.models import UserProfile as UP
        profile = UP.objects.get(user=self.user)
        self.assertEquals(profile.wrong_password_entered, 1)
        response = self.client.post('/app/login/', data2)
        self.assertEquals(response.status_code, 302)
        profile = UP.objects.get(user=self.user)
        self.assertEquals(profile.wrong_password_entered, 0)

    def test_enter_wrong_username(self):
        data1 = { 'username':'Idontexist', 'password':self.password}
        response = self.client.post('/app/login/', data1)
        self.assertEquals(response.status_code, 200)
        self.assertIn('enter a correct username', response.content)

    def test_inactive_account(self):
        self.user.is_active = False
        self.user.save()
        data = {'username':self.uname, 'password': self.password}
        response = self.client.post('/app/login/', data)
        self.assertEquals(response.status_code, 200)
        self.assertIn('inactive', response.content)

    def test_password_reset_counter_via_reset_pw(self):
        """Log three times in with a wrong password,
            reset it via email and check if the wrong
            password counter was resetted."""
        data = {
                'username' : self.uname,
                'password' : 'joep'
                }
        # get the max
        for i in xrange(3):
            self.client.post('/app/login/',data)

        post_data = {'email' : self.user.email }
        response = self.client.post('/app/password_reset/', post_data)

        response_dict = self.response_items_to_dict(response)

        self.failUnlessEqual(response.status_code, 302)
        self.failUnless('testserver/app/password_reset_done' in
                response_dict['Location'])
        from django.core import mail
        self.failUnlessEqual(len(mail.outbox), 1)

        import re
        url_re = re.compile(
                'http://openid.pareto.nl/app/password_reset_confirm/.+')
        message = mail.outbox[0].message().get_payload()
        #Remove =\n from message because Django puts it in the reset url.
        #I don't know why django does that.
        message = message.replace('=\n', '')
        reset_url = url_re.search(message).group()
        self.failUnless(reset_url)

        from idland.utils import get_path
        # get the path because Client() only deals with urlpaths.
        reset_url = get_path(reset_url)
        new_pw = 'sUperS3cR4T'
        reset_post_data = self.password_dict(new_pw)
        reset_response = self.client.post(reset_url, reset_post_data)

        response_dict = self.response_items_to_dict(reset_response)

        self.failUnlessEqual(response.status_code, 302)
        self.failUnless('testserver/app/password_reset_complete' in \
                response_dict['Location'])

        from idland.models import UserProfile
        prof = UserProfile.objects.get(pk=1)
        self.failUnlessEqual(prof.wrong_password_entered, 0)

    def test_login_with_wrong_username(self):
        post_data = { 'username' : 'p', 'password':''}
        response = self.client.post('/app/login/', post_data)
        self.failUnlessEqual(response.status_code, 200)
        self.failUnless('Please Log in' in response.content)

    def password_dict(self, pw):
        """Generate a new dict for SetExtendedPasswordForm."""
        return {'new_password1':pw, 'new_password2':pw}

class LogOut(OpenIDTestCase):
    """Check if the logout view really log someone out."""
    def test_logout(self):
        response = self.client.get('/app/logout/')
        self.assertEquals(response.status_code, 302)
        # get the redirect location
        location = response.items()[2][1]
        response_2 = self.client.get(location)
        location_2 = response_2.items()[2][1]
        self.assertIn('/app/login/', location_2)



def suite():
    s = unittest.TestSuite()
    ms = unittest.makeSuite
    s.addTest(ms(IDLandUser))
    s.addTest(ms(PasswordResetFormTest))
    s.addTest(ms(MaxThreeLogins))
    s.addTest(ms(LogOut))
    return s
