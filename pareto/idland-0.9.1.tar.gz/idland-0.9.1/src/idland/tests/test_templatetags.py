import unittest

from idland.tests.base import OpenIDTestCase

class TemplateTag(OpenIDTestCase):
    def setUp(self):
        super(TemplateTag, self).setUp()

    def tearDown(self):
        super(TemplateTag, self).tearDown()

    def test_get_consumer_domain(self):
        class token(object):
            def split_contents(self):
                return [u'get_consumer_domain']

        from idland.templatetags.idlandtag import get_consumer_domain, \
                GetConsumerDomain
        result = get_consumer_domain('iets', token())
        self.failUnlessEqual(type(result), GetConsumerDomain)

    def test_get_consumer_domain_raise_ValueError(self):
        class token(object):
            def split_contents(self):
                raise ValueError

            class Contents(object):
                def split(self):
                    return ['iets']
            contents = Contents()

        from idland.templatetags.idlandtag import get_consumer_domain
        from django import template
        self.assertRaises(template.TemplateSyntaxError, get_consumer_domain,
                          'iets', token())

    def test_GetConsumerDomain(self):
        from idland.templatetags.idlandtag import GetConsumerDomain
        # test for two responses, one with a correct next url and another with
        # a shabby one.
        context1 = {}
        context2 = {}
        context1['next'] = u'/app/server/?openid.assoc_handle=%7BHMAC-SHA1%7D%7B49350683%7D%7Bb8u7ng%3D%3D%7D&openid.claimed_id=http%3A%2F%2Flocalhost%3A8000%2Froland&openid.identity=http%3A%2F%2Flocalhost%3A8000%2Froland&openid.mode=checkid_setup&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&openid.realm=http%3A%2F%2Flocalhost%3A8080%2Fconsumer&openid.return_to=http%3A%2F%2Flocalhost%3A8080%2Fconsumer%3Fjanrain_nonce%3D2008-12-02T22%253A04%253A33ZvRBjyk'
        context2['next'] = 'nothing'
        response1 = GetConsumerDomain().render(context1)
        response2 = GetConsumerDomain().render(context2)
        # response should return empty
        self.failIf(response1)
        self.failIf(response2)
        self.failUnless('http://localhost:8080/consumer' in \
                context1['consumer_domain'])
        # check if consumer_domain doesn't exist in context2
        self.failIf(context2.get('consumer_domain'))


def suite():
    s = unittest.TestSuite()
    ms = unittest.makeSuite
    s.addTest(ms(TemplateTag))
    return s
