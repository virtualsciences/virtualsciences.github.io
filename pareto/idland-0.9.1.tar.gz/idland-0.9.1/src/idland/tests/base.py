import unittest

from django.core import mail, management
from django.db import connection
from django.test.client import Client
from django.test.utils import TestSMTPConnection

from idland.settingsimporter import settings_import
from django.conf import settings
User = settings_import(settings.USER)

class OpenIDTestCase(unittest.TestCase):

    def setUp(self):
        # Do not use South during our tests.
        management.get_commands()
        self._syncdb = management._commands['syncdb']
        self._syncdb = management._commands['syncdb'] = 'django.core'

        # Create and populate a test db.
        self.olddbname = settings.DATABASE_NAME
        self.dbname = connection.creation.create_test_db(0)
        self.password = 'wachtwoord'
        self.user = User.objects.create_user(
            'roland', 'roland.van.laar@pareto.nl', self.password)
        self.user.is_staff=True
        self.user.save()

        self.user_p = self.user.get_profile()

        self.inactive_user = User.objects.create_user(
            'deadbeaf', 'deadbeaf@pareto.nl',  self.password)
        self.inactive_user.is_active = False
        self.inactive_user.save()
        #from idland.models import UserProfile
        #UserProfile.objects.create(user=self.inactive_user)

        # Create a temporary OpenID storage directory
        from tempfile import mkdtemp
        self.openid_directory = mkdtemp()
        self.oldopeniddb = settings.OPENID_DATABASE
        settings.OPENID_DATABASE = self.openid_directory

        # Make name and client easier accessible
        self.email = self.user.email
        self.uname = self.user.username
        # always urlquote the identity because it can be an emailaddress.
        self.identity = self.user.identity
        #if settings.USER_ID == 'email':
        #    self.identity = urllib.quote(self.identity)
        self.inactive_uname = self.inactive_user.username
        self.inactive_identity = self.inactive_user.identity
        self.client = Client()
        mail.original_SMTPConnection = mail.SMTPConnection
        mail.SMTPConnection = TestSMTPConnection
        mail.outbox = []

        # Client().get uses testserver as domain and port 80
        self.server = "http://testserver"

        # set up the indentity url
        from django.core.urlresolvers import reverse
        identity_path = reverse('idland.views.provider.identity',
                                kwargs={'username':self.identity})
        self.identity_url = self.server + identity_path

        # set up a site; we are using contrib.sites because we have
        # flatpages
        from django.contrib.sites.models import Site
        self.site = Site.objects.create(
            domain = 'testserver',
            name = 'testserver'
        )
        self.site.save()

    def tearDown(self):
        connection.creation.destroy_test_db(self.olddbname,0)
        settings.OPENID_DATABASE = self.oldopeniddb
        mail.SMTPConnection = mail.original_SMTPConnection
        # Restore South
        management._commands['syncdb'] = self._syncdb

    def response_items_to_dict(self, response):
        """Put django test client response headers in a dict"""
        return dict((k,v) for k, v in response.items())

    def assertIn(self, needle, haystack):
        if needle not in haystack:
            raise AssertionError('%s\n not found in:\n %s' %
                                 (needle, haystack))



