import unittest

import mock
from idland.tests.base import OpenIDTestCase
from idland.settingsimporter import settings_import
from django.conf import settings
User = settings_import(settings.USER)



class UserList(OpenIDTestCase):

    def setUp(self):
        super(UserList, self).setUp()

        #create extra users
        self.user2 = User.objects.create_user('janexample',
                'jan@example.com', self.password)
        self.up2 = self.user2.get_profile()
        self.user3 = User.objects.create_user('joepexample',
                'joep@example.com',  self.password)
        self.up3 = self.user3.get_profile()

        # set up applications
        from idland.models import Application

        self.app_domain = Application.objects.create(name = 'test domain',
                contact_name = 'example name',
                contact_email = 'example@example.com',
                domain = 'my.zeelandia.com')
        self.app_path = Application.objects.create(name = 'test domain+path',
                contact_name = 'example name2',
                contact_email = 'example2@example.com',
                domain = 'my.zeelandia.com/path/path')

        # give users access to the application
        self.user_p.applications.add(self.app_domain)
        self.user_p.applications.add(self.app_path)
        self.up2.applications.add(self.app_path)
        self.up3.applications.add(self.app_path)


    def test_invalid_app_name(self):
        url = '/app/userlist/invalidappname/'
        response = self.client.get(url)
        self.failUnlessEqual(response.status_code, 404)

    def test_valid_app_name(self):
        #Test the validity of the app and check if the
        # returned json is correct
        url = '/app/userlist/' + self.app_path.domain + '/'
        response = self.client.get(url)
        self.failUnlessEqual(response.status_code, 200 )
        from simplejson import loads, dumps
        json = loads(response.content)
        user_dict = lambda a: {'openid': self.server + '/' + a.username}
        user_list = [ user_dict(self.user), user_dict(self.user2),
                user_dict(self.user3)]
        json_test = loads(dumps(user_list))
        self.failUnlessEqual(response['Content-Type'], 'application/json')
        self.failUnlessEqual(json, json_test)

    def test_longer_path(self):
        url = '/app/userlist/' + self.app_path.domain + 'blaat/'
        response = self.client.get(url)
        self.failUnlessEqual(response.status_code, 200 )
        from simplejson import loads, dumps
        json = loads(response.content)
        user_dict = lambda a: {'openid': self.server + '/' + a.username}
        user_list = [ user_dict(self.user), user_dict(self.user2),
                user_dict(self.user3)]
        json_test = loads(dumps(user_list))
        self.failUnlessEqual(json, json_test)

    def test_invalid_user(self):
        # give inactive user access to the application
        i_user = self.inactive_user
        i_user.get_profile().applications.add(self.app_path)
        url = '/app/userlist/' + self.app_path.domain + '/'
        response = self.client.get(url)
        self.failUnlessEqual(response.status_code, 200 )
        self.failIf(i_user.username in response.content)

class MultiSiteSearch(OpenIDTestCase):

    def setUp(self):
        super(MultiSiteSearch, self).setUp()

        from idland.models import Application

        self.app_domain = Application.objects.create(name = 'test domain',
                contact_name = 'example name',
                contact_email = 'example@example.com',
                domain = 'my.zeelandia.com')
        self.app2 = Application.objects.create(name = 'app2',
                contact_name = 'example name',
                contact_email = 'example@example.com',
                domain = 'app2.zeelandia.com')
        self.user_p.applications.add(self.app_domain)
        self.user_p.applications.add(self.app2)


    class MimickUrllib2(object):
        """Mock object that mimicks urllib2 behavior."""

        teller = 1
        json = '[{"url": "http://nohost/plone/front-page", \
                "score": 100, \
                "short_desc": "Congratulations! You have successfully installed Plone.", "title": "Welcome to Plone"}]'
        json2 = '[{"url": "http://nohost/plone/front-page2", \
                "score": 99, \
                "short_desc": "Congratulations! You have successfully installed Plone.2", "title": "Welcome to Plone2"}]'

        def __init__(self, timeout=0):
            self.timeout = timeout

        def read(self):
            if self.teller == 1:
                self.teller = 2
                return self.json
            else:
                self.teller = 1
                from time import sleep
                sleep(self.timeout)
                return self.json2

        def new(urllib2_object):
            """Needed for compatibility with urllib2."""
            pass

    def mock_urllib_403(self, unused_var):
        from urllib2 import HTTPError
        raise HTTPError('http://testserver/sitesearch/url/', 403,
                'Forbidden', None, None)

    def test_secret(self):
        from idland import settings
        self.failUnless(settings.MULTI_SITE_SEARCH_SECRET)

    def test_login_required(self):
        rep = self.client.get('/app/search/query')
        from django.http import HttpResponseRedirect
        self.assertEquals(HttpResponseRedirect, type(rep))

    def test_search_result_403(self):
        """Test if a 403 gets handled correctly."""
        from idland import views
        from mock import Mock
        views.plone.urllib2.urlopen = Mock()
        views.plone.urllib2.urlopen.side_effect = self.mock_urllib_403

        self.client.login(username = self.identity, password = self.password)
        url = '/'
        response = self.client.get(url, {'search' : 'b*'})
        self.assertEquals(response.status_code, 200)
        self.failIf('<ul class="results">' in response.content)

    @mock.patch('urllib2.urlopen')
    def test_search_results(self, urlopen):
        urlopen.return_value = self.MimickUrllib2()

        self.client.login(username = self.identity, password = self.password)
        response = self.client.get('/', {'search':'b*'})
        self.assertEquals(response.status_code, 200)
        self.assertTrue('<ul class="results">' in response.content)
        self.assertTrue('Welcome to Plone2' in response.content)
        self.assertTrue('Welcome to Plone' in response.content)

    @mock.patch('urllib2.urlopen')
    def test_search_results_with_sleep(self, urlopen):
        urlopen.return_value = self.MimickUrllib2(timeout=10)

        self.client.login(username = self.identity, password = self.password)
        response = self.client.get('/', {'search':'b*'})
        self.assertEquals(response.status_code, 200)
        self.assertTrue('<ul class="results">' in response.content)
        self.assertTrue('Welcome to Plone' in response.content)
        self.assertTrue('Welcome to Plone2' not in response.content)
        self.assertTrue("The following domains couldn't be searched"
                in response.content)

    @mock.patch('urllib2.urlopen')
    def test_valid_search_url(self, urlopen):
        urlopen.return_value =  self.MimickUrllib2()

        self.client.login(username = self.identity, password = self.password)
        response = self.client.get('/', {'search' : 'b*'})
        self.assertEquals(response.status_code, 200)

        # Get the urlencoded data from the url
        url_data = urlopen.call_args[0][0]
        from cgi import parse_qs as query_string_to_dict
        qs = query_string_to_dict(url_data.data)
        user_string = 'http://testserver/'+ self.identity
        self.assertEquals(user_string, qs['user'][0])

        from idland import settings
        from hashlib import md5
        secret= md5(settings.MULTI_SITE_SEARCH_SECRET).hexdigest()

        self.assertEquals(secret, qs['secret'][0])
        self.assertEquals('b*', qs['query'][0])

    @mock.patch('urllib2.urlopen')
    def test_FetchSearchUrl(self, urlopen):
        urlopen.return_value =  self.MimickUrllib2()
        from idland.views.plone import FetchSearchUrl
        search = FetchSearchUrl('localhost', '123')
        search.run()
        from simplejson import loads
        json = loads(self.MimickUrllib2.json)
        self.assertEquals(search.result[0]['url'], json[0]['url'])
        self.assertEquals(search.result[0]['domain'], 'http://localhost')

    def test_MultiSiteSearch_without_search(self):
        from idland.views.plone import multi_site_search as mss
        self.client.login(username = self.identity, password = self.password)
        from django.http import HttpRequest
        request= HttpRequest()
        request.REQUEST= {}
        request.user = self.user
        self.assertRaises(KeyError, mss, request)

def suite():
    s = unittest.TestSuite()
    ms = unittest.makeSuite
    s.addTest(ms(UserList))
    s.addTest(ms(MultiSiteSearch))
    return s

