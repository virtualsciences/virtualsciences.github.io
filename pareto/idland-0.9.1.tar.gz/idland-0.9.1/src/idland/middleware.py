import datetime

from django.http import HttpResponseRedirect
from django.core.urlresolvers import reverse
from django.contrib.auth.views import password_reset_confirm
from django.views.static import serve

from idland.views.auth import password_change, userlogout

class UserExpiry(object):
    def process_view(self, request, view_func, view_args, view_kwargs):
        user = request.user
        if user.is_authenticated():
            today = datetime.date.today()
            profile = user.get_profile()
            expiry = profile.password_expiry
            if (expiry < today) and not (view_func in
                    (password_change, password_reset_confirm, serve,
                    userlogout)):
                return HttpResponseRedirect(reverse("expired_pw"))
        return
