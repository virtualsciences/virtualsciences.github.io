from setuptools import setup, find_packages

version = '0.3'

setup(name='pareto.blinker',
      version=version,
      description="Pareto Blinker",
      long_description=open("README.txt").read(),
      classifiers=[
          "Framework :: Plone",
          "Programming Language :: Python",
      ],
      author='Jeroen Vloothuis',
      author_email='jeroen.vloothuis@pareto.nl',
      package_dir={'': 'src'},
      packages=find_packages('src'),
      namespace_packages = ['pareto'],
      include_package_data=True,
      zip_safe=False,
      install_requires=[
        'setuptools',
        'httplib2',
      ],
      )
