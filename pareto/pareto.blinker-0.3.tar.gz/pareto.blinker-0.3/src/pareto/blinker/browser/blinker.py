import urllib

import httplib2
from zope.formlib import form
from zope.schema.vocabulary import SimpleTerm, SimpleVocabulary
from Products.Five.formlib import formbase

from pareto.blinker import blinker_message_factory as _
from pareto.blinker.interfaces import IBlinkerForm

class BlinkerForm(formbase.PageForm):
    form_fields = form.FormFields(IBlinkerForm)

    @form.action(_(u'Submit'), failure='handle_submit_failure')
    def handle_submit(self, action, data):
        formdata = {
            'sendConfirmation': '100',
            'reseller': 'Blinker',
            'redir': 'directSub',
            'SIid': self.context.getServiceInstanceID(),
            'okLink': 'http://localhost/ok',
            'nokLink': 'http://localhost/error',
            'vrij1': '',
            'check': self.context.getCheck(),
            'command': 'insert'}

        field_mappings = {
            'first_name': 'vNaam',
            'last_name': 'aNaam',
            'company': 'bedrijf',
            'email': 'email',
            'inter_fix': 'tussenvoegsel',
            }
        for key, new_key in field_mappings.iteritems():
            formdata[new_key] = data[key] or '' # Convert None to empty strings

        formdata['geslacht'] = data['gender'] and data['gender'][0] or ''

        # TODO: Do something with the list ids
        # 'lijst1': '0',
        for l in self.context.getMailingLists():
            formdata[l['id']] = '0'

        body = urllib.urlencode(formdata)
        h = httplib2.Http()
        resp, content = h.request(
            'http://m8.mailplus.nl/genericservice/code/servlet/Redirect',
            method="POST", body=body,
            headers={'User-Agent': 'Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9) Gecko/2008061015 Firefox/3.0',
                     'Content-Type': 'application/x-www-form-urlencoded'})
        # Update the status according to the success of the post to
        # blinker
        if 'http://localhost/ok' not in content:
            self.errors = list(self.errors) + ['blinker_error']
            self.status = _(u'There was a problem with handling your request.'
                            u' Please contact the site administrator using'
                            u' the contact form.')
        else:
            self.status = _(u'Thanks for subscribing to our newsletter')

    def handle_submit_failure(self, action, data, errors):
        self.status = _(u'Please correct the indicated errors')
    

def AvailableGenderItems(context):
    '''Vocab. to get gender items. '''
    # we need this to translate stuff
    gender_items = [SimpleTerm('O', 'O', _(u'Not relevant')),
                    SimpleTerm('M', 'M', _(u'Male')),
                    SimpleTerm('V', 'V', _(u'Female'))]
    return SimpleVocabulary(gender_items)
