import unittest
import cgi

from httplib2 import Http

from Testing import ZopeTestCase as ztc
from Products.Five import zcml
from Products.Five import fiveconfigure
from Products.Five.testbrowser import Browser
from Products.PloneTestCase import PloneTestCase as ptc
from Products.PloneTestCase.layer import onsetup
from pareto.blinker.browser.blinker import BlinkerForm

ptc.setupPloneSite()

@onsetup
def setup_product():
    """Set up additional products and ZCML required to test this product.

    The @onsetup decorator causes the execution of this body to be deferred
    until the setup of the Plone site testing layer.
    """

    # Load the ZCML configuration for this package and its dependencies

    fiveconfigure.debug_mode = True
    import pareto.blinker
    zcml.load_config('configure.zcml', pareto.blinker)
    fiveconfigure.debug_mode = False

    # We need to tell the testing framework that these products
    # should be available. This can't happen until after we have loaded
    # the ZCML.
    ztc.installPackage('pareto.blinker')
    ztc.installProduct('DataGridField')

# The order here is important: We first call the deferred function and then
# let PloneTestCase install it during Plone site setup

setup_product()
ptc.setupPloneSite(products=['DataGridField', 'pareto.blinker'])

class TestCase(ptc.PloneTestCase):
    """Base class used for test cases
    """

class FunctionalTestCase(ptc.FunctionalTestCase):
    """Test case class used for functional (doc-)tests
    """

    def setUp(self):
        super(FunctionalTestCase, self).setUp()
        self.setRoles(['Manager'])

        # Create a user so that we can login
        self.uf = self.portal.acl_users
        self.uf.userFolderAddUser('root', 'secret', ['Manager'], [])

        # Create a new Blinker content item in the portal root for
        # easy access within the rest of the tests
        self.portal.invokeFactory('Blinker', 'blinker')
        self.item = self.portal.blinker

        self.browser = Browser()

    def login_as_manager(self):
        """Points the browser to the login screen and logs in as user
        root with Manager role"""
        self.browser.open('http://nohost/plone/')
        self.browser.getLink('Log in').click()
        self.browser.getControl('Login Name').value = 'root'
        self.browser.getControl('Password').value = 'secret'
        self.browser.getControl('Log in').click()
        # Make sure we are actually logged in
        self.assert_('You are now logged in.' in self.browser.contents)


class TestBlinkerContentType(TestCase):

    def setUp(self):
        super(TestBlinkerContentType, self).setUp()
        # All content type tests require us to be authorized
        self.setRoles(['Manager'])

    def create_item(self):
        # Create a new Blinker content item in the portal root and
        # return it
        self.portal.invokeFactory('Blinker', 'blinker')
        # This should have created a Blinker item in the site
        return self.portal.blinker
    
    def test_create_item(self):
        # Blinker content types must be available to create anywhere a
        # user wants
        self.portal.invokeFactory('Blinker', 'blinker')
        # This should have created a Blinker item in the site
        item = self.portal.blinker

    def test_blinker_fields(self):
        # A Blinker item has a few fields which can be used to
        # configure the specifics. Let's first create an item so we
        # can set it's fields.
        item = self.create_item()
        
        # One of the fields is the Blinker Service Instance ID
        item.setServiceInstanceID('381557')
        
        # We can also set the options for which lists a user can
        # choose. Each list has a list id and a label.
        item.setMailingLists([
                {'id': 'lijst1', 'label': 'List one'}
                ])


        # The send confirmation id maps to a template for respons
        # emails
        item.setSendConfirmationID('100')

        # We also have a check field. This accepts a code. The code is
        # unique for a service instance ID.
        item.setCheck('c25skP5m2vmX6sPyxuN')

    def test_mailing_list_option(self):
        # Add a test that demonstrates the workings of the list option.
        pass


class TestBlinkerView(FunctionalTestCase):
    
    def setUp(self):
        FunctionalTestCase.setUp(self)
        self.patch_httplib2()

    def tearDown(self):
        self.restore_httplib2()
        FunctionalTestCase.tearDown(self)

    def patch_httplib2(self):
        # Before demonstrating the workings of the registration we
        # need monkey patch httplib2's request method. This avoids
        # needless requests and let's us test the form.

        # This will store data about each call to the request method
        self.http_requests = []
        # Setup the redirection url here so tests can override it
        # later on
        self.response_content = '''
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
\t<META HTTP-EQUIV="Refresh" CONTENT="0; URL=http://localhost/ok">
</head>

<body>
</body>
</html>'''

        def dummy_request(httplib_self, uri, method, body, headers):
            self.http_requests.append({'uri': uri, 'method': method, 'body': body})
            return {}, self.response_content
        # Let's keep a reference so we can restore it later
        self.__old_request = Http.request
        # Now make the switch
        Http.request = dummy_request

    def restore_httplib2(self):
        # Finally we need to restore httplib2 to it's former state
        Http.request = self.__old_request


    def test_available_form_fields(self):
        # Make sure that the fields we need are available on the
        # form. This also makes sure we do not get any more fields
        # than we need / want.
        self.assertEqual(
            [w.__name__ for w in BlinkerForm.form_fields],
            ['email', 'first_name', 'inter_fix', 
             'last_name', 'gender', 'company'])

        # We will also make sure that all these fields show up in the
        # rendered form
        self.login_as_manager()
        self.browser.open(self.item.absolute_url())
        
        self.browser.getControl('E-mail')
        self.browser.getControl('First name')
        self.browser.getControl('Inter fix')
        self.browser.getControl('Last name')
        self.browser.getControl('Gender')
        self.browser.getControl('Company')

    def test_validation(self):
        # Some fields within the form are required or have special
        # validation rules.

        # First we need to load the page with the form
        self.login_as_manager()
        self.browser.open(self.item.absolute_url())
        # Now we can submit it without filling any form field
        self.browser.getControl('Submit').click()
        # We should see some errors on the page
        self.assert_('Please correct the indicated errors'
                     in self.browser.contents)

    def test_form_submission(self):
        # When the form is submitted it should do a post to
        # Blinker. Let's demonstrate this.

        # First we need to load the page with the form
        self.login_as_manager()
        self.browser.open(self.item.absolute_url())
        # We need to enter some data in the fields to make sure the
        # form is valid
        self.browser.getControl('E-mail').value = 'samus.aron@metroid.prime'
        self.browser.getControl('First name').value = 'Samus'
        self.browser.getControl('Last name').value = 'Aron'
        self.browser.getControl('Gender').value = ['V']
        # Now we can submit the form
        self.browser.getControl('Submit').click()
        # We should see a message thanking us for our subscription
        self.assert_('Thanks for subscribing to our newsletter'
                     in self.browser.contents)

    def test_successful_registration(self):
        # We need to load the page and fill in the form.
        self.login_as_manager()
        self.browser.open(self.item.absolute_url())
        self.browser.getControl('E-mail').value = 'samus.aron@metroid.prime'
        self.browser.getControl('First name').value = 'Samus'
        self.browser.getControl('Last name').value = 'Aron'
        self.browser.getControl('Gender').value = ['V']
        # When we submit the form it should send a message to
        # Blinker. Since we patched the library which is used
        # (httplib2) we can see the results in the
        # `self.http_requests` variable.
        self.browser.getControl('Submit').click()
        self.assertEqual(self.http_requests[-1]['uri'], 
                         'http://m8.mailplus.nl/genericservice/code/servlet/Redirect')
        # Since our patched httplib2 indicated success we should get
        # the nice message thanking us for our subscription.
        self.assert_('Thanks for subscribing to our newsletter'
                     in self.browser.contents)

    def test_unsuccessful_registration(self):
        # To make sure we get a failure we will tell the patched
        # httplib2 that it should redirect to the error page.
        self.response_content = ''

        # We need to load the page and fill in the form.
        self.login_as_manager()
        self.browser.open(self.item.absolute_url())
        self.browser.getControl('E-mail').value = 'samus.aron@metroid.prime'
        self.browser.getControl('First name').value = 'Samus'
        self.browser.getControl('Last name').value = 'Aron'
        self.browser.getControl('Gender').value = ['V']
        # When we submit the form it should send a message to
        # Blinker. Since we patched the library which is used
        # (httplib2) we can see the results in the
        # `self.http_requests` variable.
        self.browser.getControl('Submit').click()
        self.assertEqual(self.http_requests[-1]['uri'], 
                         'http://m8.mailplus.nl/genericservice/code/servlet/Redirect')
        # Since our patched httplib2 indicated failure we should get a
        # message indicating to the user that their subscription was
        # unsuccessful.
        self.assert_('There was a problem with handling your request.'
                     in self.browser.contents)

    def test_http_message(self):
        # When a message is send to Blinker it should contain a few
        # fields. This test asserts that the proper fields are send to
        # Blinker.

        # We need to load the page and fill in the form.
        self.login_as_manager()
        self.browser.open(self.item.absolute_url())
        self.browser.getControl('E-mail').value = 'samus.aron@metroid.prime'
        self.browser.getControl('First name').value = 'Samus'
        self.browser.getControl('Last name').value = 'Aron'
        self.browser.getControl('Gender').value = ['V']
        # Now we can submit the form
        self.browser.getControl('Submit').click()
        # This should have made a request object with the proper
        # data. It should be a HTTP POST message.
        self.assertEqual(self.http_requests[-1]['method'], 'POST')
        # It's body should contain the values from both this form and
        # some settings from the content type.
        data = cgi.parse_qs(self.http_requests[-1]['body'])
        self.assertEqual(data, 
                         {'vNaam': ['Samus'], 
                          'geslacht': ['V'], 
                          'reseller': ['Blinker'], 
                          'okLink': ['http://localhost/ok'], 
                          'redir': ['directSub'], 
                          'aNaam': ['Aron'], 
                          'nokLink': ['http://localhost/error'], 
                          'command': ['insert'], 
                          'sendConfirmation': ['100'], 
                          'email': ['samus.aron@metroid.prime']})

    def test_no_location_in_response(self):
        # To show what happens when server forgets to send us a
        # location header we will patch httplib2.
        def dummy_request(httplib_self, uri, method, body, headers):
            self.http_requests.append({'uri': uri, 'method': method, 'body': body})
            return {}, ''
        Http.request = dummy_request
        # Now we can setup the form and submit it
        self.login_as_manager()
        self.browser.open(self.item.absolute_url())
        self.browser.getControl('E-mail').value = 'samus.aron@metroid.prime'
        self.browser.getControl('First name').value = 'Samus'
        self.browser.getControl('Last name').value = 'Aron'
        self.browser.getControl('Gender').value = ['V']
        self.browser.getControl('Submit').click()
        # This should show us an error on the form indicating the
        # problem
        self.assert_('There was a problem with handling your request.'
                     in self.browser.contents)
        

class TestInstallation(TestCase):
    

    def test_installable(self):
        # The product should be visible in the Plone Control
        # panel. This means that the quick installer should mark it as
        # installed.
        self.assert_(self.portal.portal_quickinstaller.isProductInstalled(
                'pareto.blinker'))
        
    def test_portal_types(self):
        # The portal_types tool should have been extended with a
        # custom content type.
        self.assert_('Blinker' in self.portal.portal_types.objectIds())
        
    def test_factory_types(self):
        # Our custom content types should be registerd with the portal
        # factory tool. The next call returns a dictionary we can use
        # to inspect the state of the factory tool.
        types = self.portal.portal_factory.getFactoryTypes()
        # Make sure our items is registered
        self.assert_('Blinker' in types)
        # If should be marked as enabled (it's value should be True)
        self.assert_(types['Blinker'])


def test_suite():
    return unittest.TestSuite([
            unittest.makeSuite(TestInstallation),
            unittest.makeSuite(TestBlinkerContentType),
            unittest.makeSuite(TestBlinkerView),
            ])


if __name__ == '__main__':
    unittest.main(defaultTest='test_suite')
