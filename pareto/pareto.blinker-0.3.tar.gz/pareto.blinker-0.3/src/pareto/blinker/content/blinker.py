from AccessControl import ClassSecurityInfo
from Products.Archetypes.atapi import Schema
from Products.Archetypes.atapi import StringField
from Products.Archetypes.atapi import AnnotationStorage
from Products.Archetypes.atapi import StringWidget
from Products.ATContentTypes.content.base import registerATCT
from Products.ATContentTypes.content import document
from Products.ATContentTypes.content.schemata import finalizeATCTSchema
from Products.DataGridField import DataGridField
from Products.DataGridField import DataGridWidget

from pareto.blinker import blinker_message_factory as _
from pareto.blinker.config import PROJECTNAME

schema = document.ATDocumentSchema.copy() + Schema((
        # Blinker Service Instance ID
        StringField('serviceInstanceID',
                    required=True,
                    storage = AnnotationStorage(migrate=True),
                    widget=StringWidget(label=_(u'Service instance ID'))
                    ),
        DataGridField('mailingLists',
                      required=True,
                      columns=('id', 'label'),
                      storage = AnnotationStorage(migrate=True),
                      widget=DataGridWidget(label=_(u'Mailing lists'))
                    ),
        StringField('sendConfirmationID',
                    required=True,
                    storage = AnnotationStorage(migrate=True),
                    widget=StringWidget(label=_(u'Send confirmation id'))
                    ),
        StringField('check',
                    required=True,
                    storage = AnnotationStorage(migrate=True),
                    widget=StringWidget(label=_(u'Blinker check code'))
                    )
))
finalizeATCTSchema(schema)

class Blinker(document.ATDocumentBase):
    '''A newsletter subscription form .'''

    schema = schema
    portal_type    = 'Blinker'
    archetype_name = 'Blinker'

    security       = ClassSecurityInfo()

registerATCT(Blinker, PROJECTNAME)
