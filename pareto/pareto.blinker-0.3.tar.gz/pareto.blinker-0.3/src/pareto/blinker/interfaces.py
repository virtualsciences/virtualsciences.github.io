from zope import interface, schema
from pareto.blinker import blinker_message_factory as _

class IBlinkerForm(interface.Interface):
    email = schema.TextLine(title=_(u'E-mail'), required=True)
    first_name = schema.TextLine(title=_(u'First name'), required=False)
    inter_fix = schema.TextLine(title=_(u'Inter fix'), required=False)
    last_name = schema.TextLine(title=_(u'Last name'), required=False)
    gender = schema.Choice(title=_(u'Gender'), 
                           vocabulary='pareto.blinker.availablegenderitems',
                           default='O',
                           required=True)
    company = schema.TextLine(title=_(u'Company'), required=False)
