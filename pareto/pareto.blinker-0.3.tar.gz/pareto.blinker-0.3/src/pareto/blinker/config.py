PROJECTNAME = 'pareto.blinker'

ADD_PERMISSIONS = {
    'Blinker': 'pareto.blinker: Add Blinker',
    }
