==============
Pareto Blinker
==============

This package provides support for integrating the Blinker newsletter
system with Plone. Users can subscribe using the provided form.

To create a distribution version:

 - bump version number in setup.py
 - python2.4 setup.py sdist
 - scp the resulting tarball in 'dist' to the distribution server
   e.g. 
