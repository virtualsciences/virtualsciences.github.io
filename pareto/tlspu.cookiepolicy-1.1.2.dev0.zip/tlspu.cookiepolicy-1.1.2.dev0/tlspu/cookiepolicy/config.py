# -*- coding: utf-8 -*-
# File: config.py

__author__ = """TLSPU <contact@tlspu.com>"""
__docformat__ = 'plaintext'

PROJECTNAME = 'tlspu.cookiepolicy'
