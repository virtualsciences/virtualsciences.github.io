from cookiepolicy import ICookiePolicyLayer
from cookiepolicy import ICookiePolicy

ICookiePolicyLayer, ICookiePolicy  # pyflakes
