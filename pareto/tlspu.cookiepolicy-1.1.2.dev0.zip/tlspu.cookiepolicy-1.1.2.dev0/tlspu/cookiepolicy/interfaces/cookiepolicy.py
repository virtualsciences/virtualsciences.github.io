from zope.interface import Interface


class ICookiePolicyLayer(Interface):
    """
    """


class ICookiePolicy(Interface):
    """
    """
