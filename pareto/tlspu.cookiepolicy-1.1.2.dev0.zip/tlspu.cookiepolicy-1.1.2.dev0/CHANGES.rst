Changelog
---------


1.1.2 (unreleased)
^^^^^^^^^^^^^^^^^^

- Improve packaging, uninstall, add locales.
  [maurits]

- Code moved to Google Code.
  [haqa]


1.1.1 (2012-07-04)
^^^^^^^^^^^^^^^^^^

- New release.
  [haqa]


1.1 (2012-07-03)
^^^^^^^^^^^^^^^^

- New release.
  [haqa]


1.0 (2012-06-17)
^^^^^^^^^^^^^^^^

- Initial release
  [haqa]
