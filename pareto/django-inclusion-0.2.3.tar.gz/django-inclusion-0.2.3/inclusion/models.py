from django.db import models


class Fragment(models.Model):
    name = models.CharField(max_length=32)
    content = models.TextField()

    def __unicode__(self):
        return self.name


class Parameter(models.Model):
    fragment = models.ForeignKey(Fragment, name="parameters")
    name_in_fragment = models.CharField(max_length=32)
    name_in_template = models.CharField(max_length=32)
    value = models.CharField(max_length=32)

    def __unicode__(self):
        return "t:%s - f:%s" % (self.name_in_template, self.name_in_fragment)
