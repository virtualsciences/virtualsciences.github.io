from inclusion import models


def pytest_funcarg__inclusion(request):

    def setup():
        fr_id = models.Fragment.objects.create(
            name='openx', content='aa {{p1}} bb')
        models.Parameter.objects.create(fragment=fr_id, name_in_template='p1',
            name_in_fragment='p1', value='foo')
    return request.cached_setup(setup, scope="function")


def test_with_valid_tag(client, inclusion):
    response = client.get('/tagtester/')
    assert 'aa foo bb' in response.content


def test_without_valid_tag(client):
    client.get('/tagtester/')


def test_without_valid_param(client, inclusion):
    param = models.Parameter.objects.get(name_in_fragment='p1')
    param.name_in_fragment = 'p2'
    param.save()
    client.get('/tagtester/')


def test_no_escaping(client, inclusion):
    fragment = models.Fragment.objects.get(name='openx')
    fragment.content = '<script>%s</script>' % fragment.content
    fragment.save()
    response = client.get('/tagtester/')
    assert '<script>' in response.content


def test_name(client, inclusion):
    params = models.Parameter.objects.all()
    assert params.count() == 1
    assert str(params[0]) == "t:p1 - f:p1"

# XXX add tests for name_in_template differences
