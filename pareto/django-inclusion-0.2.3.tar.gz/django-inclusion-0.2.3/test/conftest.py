from django_pytest.conftest import (pytest_funcarg__client,
                                    pytest_funcarg__django_client,
                                    pytest_funcarg__user)

pytest_funcarg__client # pyflakes
pytest_funcarg__django_client # pyflakes
pytest_funcarg__user # pyflakes
