from django.http import HttpResponse
from django.contrib.auth.decorators import login_required


@login_required
def protected(request):
    return HttpResponse('hi there')

