import time
from django.test.client import Client
from django.conf import settings
from django.contrib.sessions.models import Session
from concurrentusage.middleware import ConcurrentUsageMiddleware


def request_helper(clients, amount, sleep_time=0):
    for i in range(amount):
        clients.append(Client())
    for i, client in enumerate(clients):
        client.login(username='user', password='user')
        res = client.get('/protected/')
        if sleep_time > 0 and i > amount - 2:
            time.sleep(sleep_time)
    return res


def test_max_sessions_allowed(client, user):
    ConcurrentUsageMiddleware._users_sessions = {}
    clients = [client]
    last_res = request_helper(clients,
        settings.CONCURRENT_USAGE_DEFAULT_LIMIT - 1)
    assert last_res.status_code == 200
    assert Session.objects.count() == settings.CONCURRENT_USAGE_DEFAULT_LIMIT


def test_last_session_not_allowed(client, user):
    ConcurrentUsageMiddleware._users_sessions = {}
    clients = [client]
    last_res = request_helper(clients, settings.CONCURRENT_USAGE_DEFAULT_LIMIT)
    # now the latest one has be be redirected
    assert last_res.status_code == 302
    assert Session.objects.count() == settings.CONCURRENT_USAGE_DEFAULT_LIMIT


def test_last_session_not_allowed_forbidden(client, user):
    ConcurrentUsageMiddleware._users_sessions = {}
    settings.CONCURRENT_USAGE_MAX_REDIRECT = None
    clients = [client]
    last_res = request_helper(clients, settings.CONCURRENT_USAGE_DEFAULT_LIMIT)
    # now the latest one has be be forbidden, no redirect
    assert last_res.status_code == 403
    assert Session.objects.count() == settings.CONCURRENT_USAGE_DEFAULT_LIMIT


def test_last_session_allowed_with_low_idle_age(client, user):
    ConcurrentUsageMiddleware._users_sessions = {}
    settings.CONCURRENT_USAGE_ACTIVE_SESSION_SECS = 1
    clients = [client]
    last_res = request_helper(clients, settings.CONCURRENT_USAGE_DEFAULT_LIMIT,
            sleep_time=2)
    # now the latest one has be be allowed
    assert last_res.status_code == 200


def test_max_sessions_allowed_for_user(client, user):

    from test.models import ConcurrentUsageProfile

    ConcurrentUsageProfile.objects.create(
        user=user, limit=3)

    ConcurrentUsageMiddleware._users_sessions = {}
    settings.CONCURRENT_USAGE_LIMIT_ATTRIBUTE =\
            'concurrent_usage_profile.limit'
    clients = [client]
    last_res = request_helper(clients,
        settings.CONCURRENT_USAGE_DEFAULT_LIMIT)
    assert last_res.status_code == 200
    assert Session.objects.count() == 3
