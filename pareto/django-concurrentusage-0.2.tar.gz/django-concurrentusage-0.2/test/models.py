from django.db import models
from django.contrib.auth.models import User


class ConcurrentUsageProfile(models.Model):
    user = models.OneToOneField(User, related_name='concurrent_usage_profile')
    limit = models.IntegerField(default=2)

    def __unicode__(self):
        return u'%s, concurrent login limit: %d' % (
            self.user.username, self.limit)
