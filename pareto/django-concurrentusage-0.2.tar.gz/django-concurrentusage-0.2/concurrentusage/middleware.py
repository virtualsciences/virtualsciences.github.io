"""\
Refer to documentation on:
https://webwerken.knmp.nl/wiki/index.php/Gelijktijdig_gebruik_limiteren_TO
"""
from time import time
from django import http
from django.conf import settings
from django.contrib.sessions.models import Session


class ConcurrentUsageMiddleware(object):

    # maybe use Redis' orderedsets for this
    _users_sessions = {}

    def __init__(self):
        # We wanted to load the _users_sessions info
        # here from the Session objects, but that
        # is not possible, because there is no user
        # associated
        # d = session.expire_date - settings.SESSION_COOKIE_AGE
        # time.mktime(d.timetuple()) # to get timestamp
        pass

    def _fetch_concurrent_usage(self, user):

        print '_fetching'
        attr_path = settings.CONCURRENT_USAGE_LIMIT_ATTRIBUTE
        if not attr_path:
            return settings.CONCURRENT_USAGE_DEFAULT_LIMIT
        obj = user
        for attr in attr_path.split('.'):
            try:
                obj = getattr(obj, attr)
            except AttributeError:
                return settings.CONCURRENT_USAGE_DEFAULT_LIMIT
        return obj

    def process_request(self, request):
        # We assume there is a session and a user
        # Django Session- and AuthenticationMiddleware should be available
        # and before this middleware
        assert request.session is not None
        assert request.user is not None
        if request.user.is_anonymous():
            return
        user_id = request.user.id
        user_info = self._users_sessions.get(user_id, None)
        session_key = request.session.session_key
        if user_info is None:
            user_limit = self._fetch_concurrent_usage(request.user)
            user_info = dict(limit=user_limit, sessions={})
            user_sessions = {}
        else:
            user_sessions = user_info['sessions']
            user_limit = user_info['limit']
            if (session_key not in user_sessions and
                len(user_sessions.items()) ==
                    user_limit):
                # maybe disable other sessions
                # try to find idle sessions
                idle_sessions = sorted([(v, k) for k, v in
                    user_sessions.items() if
                        v + settings.CONCURRENT_USAGE_ACTIVE_SESSION_SECS
                            < time()])
                if idle_sessions:
                    del user_sessions[idle_sessions[0][1]]
                    Session.objects.get(
                        session_key=idle_sessions[0][1]).delete()
                else:
                    Session.objects.get(
                        session_key=session_key).delete()
                    request.session = None
                    if settings.CONCURRENT_USAGE_MAX_REDIRECT:
                        return http.HttpResponseRedirect(
                            settings.CONCURRENT_USAGE_MAX_REDIRECT)
                    return http.HttpResponseForbidden(
                        'Er zijn meer gebruikers actief op uw account dan uw '
                        'abonnement toestaat')
        user_sessions[session_key] = time()
        user_info['sessions'] = user_sessions
        self._users_sessions[user_id] = user_info
