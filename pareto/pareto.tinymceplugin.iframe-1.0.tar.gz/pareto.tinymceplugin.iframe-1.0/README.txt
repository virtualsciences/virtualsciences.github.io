Introduction
============
This Plone add-on extends Products.TinyMCE with an iframe embed option.  
