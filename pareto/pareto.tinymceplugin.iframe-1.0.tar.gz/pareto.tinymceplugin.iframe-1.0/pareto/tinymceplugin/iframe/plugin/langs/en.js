tinyMCE.addI18n('en.iframe',{
    desc:   "Insert iframe",
    error:  "The URL has not been entered.",
    url:    "URL",
    height: "Height",
    width:  "Width",
    style:  "Style"
});