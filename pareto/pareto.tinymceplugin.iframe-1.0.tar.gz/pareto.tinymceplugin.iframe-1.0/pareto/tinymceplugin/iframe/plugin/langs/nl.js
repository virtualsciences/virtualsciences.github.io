tinyMCE.addI18n('nl.iframe',{
    desc:   "Iframe invoegen",
    error:  "de URL is niet ingevuld.",
    url:    "URL",
    height: "Hoogte",
    width:  "Breedte",
    style:  "Style"
});