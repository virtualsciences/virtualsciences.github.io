from django.template import Template, Context, Library, Node
from inclusion.models import Fragment, Parameter
register = Library()


@register.tag
def fragmentinclude(parser, token):
    args = token.split_contents()
    return FragmentNode(args[1:])


# XXX caching ???
class FragmentNode(Node):

    def __init__(self, *args):
        try:
            self.fragment = Fragment.objects.filter(name=args[0])[0].content
        except IndexError:
            self.fragment = ''
        self.params = {}
        try:
            for param in args[1:]:
                value = Parameter.objects.filter(name=param,
                    fragment=self.fragment)[0].value
                self.params[param] = value
        except IndexError:
            pass

    def render(self, context):
        raise
        template = Template(self.fragment)
        context = Context(self.params)
        return template.render(context)
