# (c) Copyright 2007 Thomas Bohmbach, Jr.  All Rights Reserved. 
#
# See the LICENSE file that should have been included with this distribution
# for more specific information.

from distutils.core import setup
from distutils.command.install import INSTALL_SCHEMES

# Tell distutils to put the data_files in platform-specific installation
# locations. See here for an explanation:
# http://groups.google.com/group/comp.lang.python/browse_thread/thread/35ec7b2fed36eaec/2105ee4d9e8042cb
for scheme in INSTALL_SCHEMES.values():
    scheme['data'] = scheme['purelib']

# Dynamically calculate the version based on openid_auth.VERSION.
(major, minor, patch, sub) = __import__('openid_auth').VERSION
if patch and sub:
    version = "%d.%d.%d%s" % (major, minor, patch, sub)
elif patch and not sub:
    version = "%d.%d.%d" % (major, minor, patch)
elif not patch and sub:
    version = "%d.%d%s" % (major, minor, sub)
elif not patch and not sub:
    version = "%d.%d" % (major, minor)

setup(
    name = 'openid_auth',
    version = version,
    description = 'OpenID authenication for Django',
    long_description = 'OpenID authenication for Django',
    author = 'Thomas Bohmbach, Jr.',
    author_email = 'thomasbohmbach@gmail.com',
    maintainer = 'Thomas Bohmbach, Jr.',
    maintainer_email = 'thomasbohmbach@gmail.com',
    url = 'http://code.google.com/p/django-openid-auth/',
    packages = ['openid_auth',],
    license = "BSD -- See the LICENSE file for more information",
    classifiers = ['Development Status :: 4 - Beta',
                   'Environment :: Web Environment',
                   'Intended Audience :: Developers',
                   'License :: OSI Approved :: BSD License',
                   'Operating System :: OS Independent',
                   'Programming Language :: Python',
                   'Topic :: Utilities',
                   'Topic :: Security',
                   'Topic :: Software Development :: Libraries :: Python Modules'],
)