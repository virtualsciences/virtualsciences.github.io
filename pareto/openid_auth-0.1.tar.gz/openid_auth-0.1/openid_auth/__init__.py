# (c) Copyright 2007 Thomas Bohmbach, Jr.  All Rights Reserved. 
#
# See the LICENSE file that should have been included with this distribution
# for more specific information.

VERSION = (0, 1, None, None)    #(major, minor, patch, sub)

#Session name constants
OPENIDS_SESSION_NAME = 'openids'
OPENID_ERROR_SESSION_NAME = 'openid_error'
