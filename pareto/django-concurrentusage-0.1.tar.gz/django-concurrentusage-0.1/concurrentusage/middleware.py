"""\
Refer to documentation on:
https://webwerken.knmp.nl/wiki/index.php/Gelijktijdig_gebruik_limiteren_TO
"""
from time import time
from django import http
from django.conf import settings
from django.contrib.sessions.models import Session


class ConcurrentUsageMiddleware(object):

    # maybe use Redis' orderedsets for this
    _users_sessions = {}

    def __init__(self):
        pass

    def process_request(self, request):
        # We assume there is a session and a user
        # Django Session- and AuthenticationMiddleware should be available
        # and before this middleware
        assert request.session is not None
        assert request.user is not None
        if request.user.is_anonymous():
            return
        user_id = request.user.id
        user_sessions = self._users_sessions.get(user_id, None)
        session_key = request.session.session_key
        if user_sessions is None:
            user_sessions = {}
        elif (session_key not in user_sessions and
                len(user_sessions.items()) == settings.MAX_SESSIONS_PER_USER):
                # maybe disable other sessions
                # try to find idle sessions
                # TODO: RRN: limit to the oldest session, to prevent unnecessary logouts
                idle_sessions = sorted([(v, k) for k, v in
                    user_sessions.items() if
                        v + settings.MAX_IDLE_AGE_FOR_SESSION < time()])
                if idle_sessions:
                    del user_sessions[idle_sessions[0][1]]
                    Session.objects.get(
                        session_key=idle_sessions[0][1]).delete()
                else:
                    Session.objects.get(
                        session_key=session_key).delete()
                    request.session = None
                    if settings.SESSION_REDIRECT:
                        return http.HttpResponseRedirect(settings.SESSION_REDIRECT)
                    return http.HttpResponseForbidden('<h1>Forbidden</h1>')
        user_sessions[session_key] = time()
        self._users_sessions[user_id] = user_sessions
