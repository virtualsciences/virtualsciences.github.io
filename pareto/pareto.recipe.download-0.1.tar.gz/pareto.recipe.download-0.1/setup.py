from setuptools import setup, find_packages

version = '0.1'
name ='pareto.recipe.download'

setup(name=name,
      version=version,
      description="Buildout recipe based on the gocept.download recipe which extract specific parts from an archive.",
      classifiers=[
        "Framework :: Buildout",
        "Programming Language :: Python",
        "Topic :: Software Development :: Libraries :: Python Modules",
        ],
      keywords='buildout recipe',
      author='Jeroen Vloothuis',
      author_email='jeroen.vloothuis@pareto.nl',
      license='LGPL',
      packages=find_packages(exclude=['ez_setup']),
      namespace_packages=['pareto'],
      include_package_data=True,
      zip_safe=False,
      install_requires=[
          "gocept.download",
      ],
      entry_points = {'zc.buildout': ['default = %s:Recipe' % name]},
      )
