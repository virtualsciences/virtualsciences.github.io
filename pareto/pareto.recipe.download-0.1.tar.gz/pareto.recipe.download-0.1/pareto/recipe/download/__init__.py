import os
import gocept.download
import shutil

class Recipe(object):
    """
    Simple wrapper for gocept.download which can extract a specific
    subdir. The recipe was written for extracting stuff like
    zpsycopgda.

    Parameters:

    download-directory        ... directory to store downloaded files
                                  default: ${buildout:directory}/downloads
    destination               ... directory to store extracted stuff
                                  default: ${buildout:parts-directory}
    strip-top-level-dir       ... strip the toplevel dir of the archive
                                  default: true
    keep                      ... remove everything exept the files listed 
                                  in keep (space seperated)
    """

    def __init__(self, buildout, name, options):
        self.options = options
        self.buildout = buildout
        self.name = name
        self.package_download = gocept.download.Recipe(buildout, name, options)

    def install(self):
        options = self.options
        location = self.options['location']
        paths = self.package_download.install()

        if self.options.get('keep'):
            files_to_keep = options['keep'].split(' ')
            for f in os.listdir(location):
                if f not in files_to_keep:
                    filename = os.path.join(location, f)
                    if os.path.isdir(filename):
                        shutil.rmtree(filename)
                    else:
                        os.remove(filename)
        return paths

    def update(self):
        pass

