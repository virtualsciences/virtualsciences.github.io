from setuptools import setup, find_packages

version = '0.9.2'

setup(
    name = "idland",
    version = version,
    license = 'proprietary',
    description = "A django OpenID provider.",
    author = 'Roland van Laar',
    packages = find_packages('src'),
    package_dir = {'': 'src'},
    zip_safe = False,
    install_requires = [
        'setuptools',
        'python-openid',
        'simplejson',
        ],

)
