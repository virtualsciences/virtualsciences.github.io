from django.contrib.auth.decorators import login_required
from django.core.mail import send_mail
from django.core.urlresolvers import reverse
from django.http import HttpResponseRedirect
from django.shortcuts import render_to_response
from django.template import RequestContext
from idland.forms import ContactForm

from idland.settingsimporter import settings_import
from django.conf import settings
User = settings_import(settings.USER)

@login_required
def contact(request):
    if request.method == "POST":
        form = ContactForm(request.POST)
        if form.is_valid():
            d = form.cleaned_data
            body = "Tel: " + d['phone_number'] + "\n" + d['message']
            send_mail(d['subject'], body, d['email_address'],
                    [settings.CONTACT_EMAIL])
            return HttpResponseRedirect(reverse('thanks'))
    else:
        form = ContactForm(initial={'name':request.user.username,
                'email_address': request.user.email })
    return render_to_response('idland/contact.html', {"form":form },
        context_instance=RequestContext(request))
