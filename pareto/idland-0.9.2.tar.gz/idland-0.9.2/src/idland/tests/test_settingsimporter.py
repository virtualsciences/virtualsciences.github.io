import unittest

class SettingsImporterTest(unittest.TestCase):
    def test_settings_import(self):
        entry = 'idland.models:UserProfile'

        from idland.settingsimporter import settings_import
        UP = settings_import(entry)
        from idland.models import UserProfile
        self.assertEquals(UP, UserProfile)

def suite():
    s = unittest.TestSuite()
    ms = unittest.makeSuite
    s.addTest(ms(SettingsImporterTest))
    return s
