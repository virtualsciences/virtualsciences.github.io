from idland.tests.base import OpenIDTestCase
import unittest

class WebPages(OpenIDTestCase):
    def setUp(self):
        super(WebPages, self).setUp()
        from django.contrib.flatpages.models import FlatPage

        #self.flatpage1.sites.add(self.site)
        #self.flatpage1.save()
        self.flatpage1 = FlatPage.objects.get(url='/app/faq/')
        self.flatpage2 = FlatPage.objects.get(url='/app/login-help/')

    def tearDown(self):
        super(WebPages, self).tearDown()

    def test_contact_form(self):
        self.client.login(username = self.identity, password = self.password)
        # test post contactform and the email
        post_data = {'name':'roland', 'subject':'Test', \
                'phone_number':'123467890',
                'email_address':'roland.van.laar@pareto.nl',
                'message':'hoi dit is een test bericht'}
        from django.core.urlresolvers import reverse
        response = self.client.post(reverse('contact'), post_data)
        from django.core import mail
        self.failUnlessEqual(len(mail.outbox), 1)
        message = mail.outbox[0].message().get_payload()
        self.failUnless(post_data['message'] in message)
        self.failUnless(post_data['phone_number'] in message)
        self.failUnlessEqual(post_data['email_address'], \
                mail.outbox[0].from_email)

    def test_get_contact_form(self):
        self.client.login(username = self.identity, password=self.password)
        from django.core.urlresolvers import reverse
        response = self.client.get(reverse('contact'))
        self.assertIn(self.email, response.content)


    def test_direct_to_flatpage_not_logged_in(self):
        response1 = self.client.get(self.flatpage1.url)
        response2 = self.client.get(self.flatpage2.url)
        self.failIf(self.flatpage1.content in response1.content)
        self.failUnless(self.flatpage2.content in response2.content)

    def test_direct_to_flatpage_logged_in(self):
        self.client.login(username = self.identity, password = self.password)
        response = self.client.get(self.flatpage1.url)
        self.failUnless(self.flatpage1.content in response.content)

def suite():
    s = unittest.TestSuite()
    ms = unittest.makeSuite
    s.addTest(ms(WebPages))
    return s
