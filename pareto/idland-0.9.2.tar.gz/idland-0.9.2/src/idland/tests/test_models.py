from idland.tests.base import OpenIDTestCase
import unittest

from idland.settingsimporter import settings_import
from django.conf import settings
User = settings_import(settings.USER)

class Signals(OpenIDTestCase):
    """Test signals."""

    def test_create_userprofile(self):
        """Creating of UserProfile via User.save() signal."""

        self.user = User.objects.create_user(
                'test@example.com', self.password)
        from idland.models import UserProfile
        self.failUnless(UserProfile.objects.get(user=self.user))

class ModelsUnicode(OpenIDTestCase):
    """Test the unicode functions of the models."""
    def setUp(self):
        super(ModelsUnicode, self).setUp()
        from idland.models import Application
        self.app = Application.objects.create(name='jan', contact_name='jan',
                                 contact_email='jan@example.com',
                                 domain='jan.example.com')
    def test_user_profile(self):
        self.assertEquals(self.user_p.__unicode__(), self.user.username)

    def test_user_log_entry(self):
        from idland.models import UserLogEntry
        ule = UserLogEntry.objects.create(user=self.user, application=self.app,
                                          tried_app='Jan Rain',
                                          logged_in=False)
        ule_uc = ule.__unicode__()
        self.assertIn(self.user.username, ule_uc)
        self.assertIn(self.app.name, ule_uc)

    def test_application(self):
        app_uc = self.app.__unicode__()
        self.assertIn(self.app.name, app_uc)
        self.assertIn(self.app.domain, app_uc)

    def test_old_password(self):
        from idland.models import OldPassword
        pw = OldPassword.objects.create(password='NoRealPassword')
        self.assertEquals(pw.password, pw.__unicode__())

def suite():
    s = unittest.TestSuite()
    ms = unittest.makeSuite
    s.addTest(ms(Signals))
    s.addTest(ms(ModelsUnicode))
    return s

