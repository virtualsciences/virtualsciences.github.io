def settings_import(entry):
    """Import a class or function from a string.

    The string needs a ':', it imports the class/function after the ':'
    from the given module in front of the ':'.
    """

    path, name = entry.split(':')
    ref = __import__(path, {}, {}, name)
    return getattr(ref, name)
