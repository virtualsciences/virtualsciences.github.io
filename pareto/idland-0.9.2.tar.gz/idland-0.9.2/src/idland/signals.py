from django.dispatch import Signal


attribute_exchange_signal = Signal(providing_args=[
        'request_object', 'response_object', 'http_request', 'openid_query',
        'openid_response', 'user'])


