from setuptools import setup, find_packages
import os

version = 2.6

classifiers=[
        "Programming Language :: Python",
        ("Topic :: Software Development :: "
         "Libraries :: Python Modules")]

setup(name='pareto.skels',
      version=version,
      description=("PasteScript templates for the Expert "
                   "Python programming Book."),
      classifiers=classifiers,
      keywords='paste templates',
      author='Manjula Perumal',
      author_email='manjula.perumal@pareto.nl',
      license='proprietary',
      packages=find_packages(exclude=['ez_setup']),
      namespace_packages=['pareto'],
      include_package_data=True,
      zip_safe=False,
      install_requires=[
          'setuptools',
          'PasteScript'],
      test_suite='pareto.skels.test_paster.test_suite',

      entry_points="""
      # -*- Entry Points: -*-
      [paste.paster_create_template]
      pareto_plone3_project = pareto.skels.pareto_plone3_project:ParetoPlone3Project
      """)

