Old-style Zope products you are developing can be added here
