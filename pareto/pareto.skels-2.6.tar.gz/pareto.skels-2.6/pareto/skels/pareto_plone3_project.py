from paste.script import templates
from pareto.skels.base import var

from pareto.skels.base import BaseTemplate


import copy
import datetime

class ParetoPlone3Project(BaseTemplate):
    _template_dir = 'templates/pareto_plone3_project'
    summary = "A buildout for Pareto Plone 3 projects"
    required_templates = []
    use_cheetah = True

    vars = [  
         var('plone_version',
            "Which Plone version to install",
            default="3.2.1"),
         var('client_name',
             "Enter the client's name. This would be used as the upload path in the fabfile)", 
             default = 'client')
        ]
    
    def pre(self, command, output_dir, vars):
        vars['oldplone'] = vars['plone_version'].startswith("3.0") or \
                            vars['plone_version'].startswith("3.1")
        vars['veryoldplone'] = vars['plone_version'].startswith("2.")
        if vars['veryoldplone']:
            vars['zope2_version'] = "2.9.10"
        vars['newplone'] = not vars['veryoldplone'] and not vars['oldplone']
        vars['timestamp'] = datetime.date.today().strftime("%Y%m%d")
        vars['version']=1.0
        vars['here']='$(here)'
        vars['tarball']='$(tarball)'
        vars['date']='$(date)'
        
        #we need to do this so that cheetah will not give an error
        vars['zope2_install']=''
        vars['plone_products_install']=''
        vars['zope_user']='admin'
        vars['zope_password']='admin'
        vars['http_port' ]=8080
        vars['debug_mode']='on'
        vars['verbose_security']='on'
        vars['include_doc']=False
        vars['skinname']=vars['project']
        vars['zope2product']=False
        vars['skinbase']='Plone Default'
        vars['empty_styles']=True
        vars['fab_host']='dist.pareto.nl'

        
        
        super(ParetoPlone3Project, self).pre(command, output_dir, vars)
        
    
    def post(self, command, output_dir, vars):
        print "-----------------------------------------------------------"
        print "Generation finished"
        print "You probably want to run python bootstrap.py and then edit"
        print "base.cfg before running bin/buildout -v"
        print "-----------------------------------------------------------"
        
        