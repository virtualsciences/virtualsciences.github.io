from Products.CMFCore.permissions import ManageProperties

TOOL_NAME = "Compass"
TOOL_META = TOOL_NAME

GLOBALS = globals()
