from Products.Five import BrowserView
from zope import component
from xmlcontent.interfaces import IContentGateway, ICatalogIndexer
from Products.CMFCore.utils import getToolByName

class CatalogView(BrowserView):

    def _indexer(self):
        gateway = IContentGateway(self.context)
        catalog = getToolByName(self.context, 'portal_catalog')

        return component.queryMultiAdapter((catalog, gateway),
                                           ICatalogIndexer)

class CatalogIndexingView(CatalogView):
    def __call__(self):
        self._indexer().index_all()
        return "indexes update: ok"

class CatalogUnindexingView(CatalogView):
    def __call__(self):
        self._indexer().unindex_all()
        return "indexes update: ok"

class CatalogReindexingView(CatalogView):
    def __call__(self):
        ids = self.request.form.get('ids', [])
        if not isinstance(ids, list):
            ids = [ids]
        self._indexer().reindex(ids)
        return "indexes update: ok"
