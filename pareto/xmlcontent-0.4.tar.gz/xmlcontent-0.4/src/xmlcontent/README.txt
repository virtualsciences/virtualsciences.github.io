XML content
===========

The XML content system is a tool for converting file based xml to content
objects. These content objects are not real content in the sense that they can
be edited. An example for the usage of this system is publishing information
from an external system.

Normally hooking Plone up to an external system like RDBMS-es etc. can be quite
painful. Using a simpler export->publish mechanism this is made easy. The main
idea is that extracting data from an external system is relatively easy.
Integrating it with Plone's indexing etc. is not.

By using XML as a storage layer we can use this system to publish a wide
variaty of content. We will now demonstrate how the system works.

First we define some XML data. You can ignore the `xmlcontent` bits for now.

  >>> recipe_xml = '''
  ... <recipe
  ...     xmlns:xmlcontent="http://namespaces.plone.org/xmlcontent"
  ...     name="Apple pie"
  ...     xmlcontent:interface="xmlcontent.examples.interfaces.IRecipe">
  ...   <ingredient name="Apple's" amount="3kg"/>
  ...   <ingredient name="Sugar" amount="0.5kg"/>
  ... </recipe>'''
  
Now we can convert this into a parsed structure.

  >>> from elementtree import ElementTree
  >>> from StringIO import StringIO
  >>> from xmlcontent.contentproxy import ContentProxy

  >>> treeroot = ElementTree.parse(StringIO(recipe_xml)).getroot()
  >>> recipe = ContentProxy(None, treeroot)
  
This parsed structure is basically just a wrapper around elementtree. It
implements the IXMLContentProxy interface.

  >>> from xmlcontent.interfaces import IXMLContentProxy
  >>> IXMLContentProxy.providedBy(recipe)
  True

To get content out of it you can just call `getroot` to get the root node and
go from there.

  >>> recipe.getroot().tag
  'recipe'

Nice as this may be it still does not offer a lot for integrating our content
with Plone. To make integration a reality we need to hookup a proper view for
our piece of content.


Presentation
------------

A Zope 3 view needs a specific interface to adapt. This interface must be
defined somewhere. You can declare the interface provided in the XML itself.
Look at the previous example for the details. In our example we declared it to
be an `IRecipe`. We can thus hook a view to our recipe object. Before we do
this we will prove that our recipe indeed provides IRecipe.

  >>> from xmlcontent.examples.interfaces import IRecipe
  >>> IRecipe.providedBy(recipe)
  True

Now we can create a view using normal Zope 3 techniques. We will not
demonstrate this as this should be done like normal.
