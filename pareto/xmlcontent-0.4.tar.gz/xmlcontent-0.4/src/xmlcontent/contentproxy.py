from zope import interface
from zope.configuration.name import resolve
from interfaces import IXMLContentProxy
from Products.CMFCore.utils import getToolByName

import Acquisition
from AccessControl import ClassSecurityInfo, Owned

class ContentProxy(Acquisition.Implicit,
           Owned.Owned,
                  ):
    interface.implements(IXMLContentProxy)

    security = ClassSecurityInfo()
    security.declareObjectPublic()

    def __init__(self, gateway, document, id=None):
        self.gateway = gateway
        self.document = document
        self._id = id

        interfacepath = document.get('{http://namespaces.plone.org/xmlcontent}interface')
        if interfacepath is not None:
            contentinterface = resolve(interfacepath)
            interface.directlyProvides(self, contentinterface)

    def getroot(self):
        return self.document

    def indexObject(self):
        catalog = getToolByName(self, 'portal_catalog')
        path = '%s/%s' % ('/'.join(self.aq_parent.getPhysicalPath()), self._id)
        catalog.catalog_object(self, uid=path)
