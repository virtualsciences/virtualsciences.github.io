from elementtree import ElementTree
from xmlcontent.contentproxy import ContentProxy
from xmlcontent.staticproxy import StaticContentProxy
from xmlcontent.interfaces import IContentGateway
import os

class FilesystemProxy(object):
    _caches = {}

    def __init__(self, context):
        self.context = context

    def _path(self):
        return IContentGateway(self.context).filesystemdir

    def load(self, name):
        path = self._path()
        if not path:
            raise IOError

        filename = os.path.join(path, name)


        if os.path.exists(filename):
            return StaticContentProxy(self.context, filename)

        filename = filename + '.xml'
        # Return the object from cache if the modification time has not
        # changed
        cache = self._caches.setdefault(path, {})
        mtime, obj = cache.get(name, (None, None))
        try:
            if mtime == os.stat(filename)[8]:
                return obj
        except OSError:
            raise IOError, 'File does not exist:' + filename

        obj = ContentProxy(self.context, ElementTree.parse(filename).getroot(), name)
        # Cache the object including the modification time
        cache[name] = (os.stat(filename)[8], obj)
        return obj

    def contentnames(self):
        return [name[:-4] for name in os.listdir(self._path())
                if name.endswith('.xml')]
