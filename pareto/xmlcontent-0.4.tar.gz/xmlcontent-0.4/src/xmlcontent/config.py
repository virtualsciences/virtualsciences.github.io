from Products.CMFCore.permissions import setDefaultRoles

PKG_NAME = "xmlcontent"

ADD_PERMISSIONS = {
    'ATFilesystemGateway': 'xmlcontent: Add Filesystem Gateway',
    }

for perm in ADD_PERMISSIONS.keys():
    setDefaultRoles(perm, ("Manager", "Owner"))
