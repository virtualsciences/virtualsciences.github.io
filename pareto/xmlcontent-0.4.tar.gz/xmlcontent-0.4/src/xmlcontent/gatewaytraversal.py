from zope import interface
from xmlcontent.interfaces import IContentGateway, IFilesystemProxy
from zope.publisher.interfaces import IPublishTraverse, NotFound
from ZPublisher.BaseRequest import DefaultPublishTraverse

class GatewayTraversal(DefaultPublishTraverse):
    interface.implements(IPublishTraverse)
        
    def load(self, name):
        """ loads an object from the proxy """
        gateway = IContentGateway(self.context)
        proxy = IFilesystemProxy(gateway)
        return proxy.load(name).__of__(self.context)

    def publishTraverse(self, request, name):
        try:
            return self.load(name)
        except IOError:
            return super(GatewayTraversal, self).publishTraverse(request, name)
