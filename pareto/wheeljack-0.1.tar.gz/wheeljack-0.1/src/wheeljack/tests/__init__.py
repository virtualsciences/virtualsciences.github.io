import unittest

def test_suite():
    return unittest.TestSuite()
