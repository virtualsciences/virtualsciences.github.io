
from wheeljack.project.settings import *
