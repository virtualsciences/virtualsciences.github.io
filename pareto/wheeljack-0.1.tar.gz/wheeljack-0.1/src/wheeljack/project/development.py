from wheeljack.project.settings import *
DEBUG=True
TEMPLATE_DEBUG=DEBUG
