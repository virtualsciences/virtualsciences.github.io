import base64

from zope.contenttype import guess_content_type
from Products.CMFPlone.utils import isDefaultPage
from zope.interface import Interface
from Acquisition import Explicit, aq_inner, aq_parent, aq_acquire

from zope.interface import implements
from zope.component import getMultiAdapter, getUtility

from plone.portlets.interfaces import IPortletDataProvider
from plone.app.portlets.portlets import base

from zope import schema
from zope.formlib import form
from Products.Five.browser.pagetemplatefile import ViewPageTemplateFile
from Products.CMFCore.utils import getToolByName
from Products.Five import BrowserView

from pareto.portlet.banner import BannerPortletMessageFactory as _


def mimetype(context, data):
    #================== BEGIN ====================        
    # Taken from Products.Archetypes.Field
    mtr = getToolByName(context, 'mimetypes_registry')
    kw = {'mimetype':None,
          'filename':''}
    # this may split the encoded file inside a multibyte character
    try:
        d, f, type = mtr(data[:8096], **kw)
    except UnicodeDecodeError:
        d, f, type = mtr(len(data) < 8096 and data or '', **kw)
    #==================  END ======================
    return type.normalized()

class IBannerPortlet(IPortletDataProvider):
    """A portlet

    It inherits from IPortletDataProvider because for this portlet, the
    data that is being rendered and the portlet assignment itself are the
    same.
    """

    # TODO: Add any zope.schema fields here to capture portlet configuration
    # information. Alternatively, if there are no settings, leave this as an
    # empty interface - see also notes around the add form and edit form 
    # below.

    url = schema.TextLine(title=_(u"Banner Url"),
                                 description=_(u"The url you would like the banner to link to"),
                                 required=False)

    img = schema.Bytes(title=_(u"Banner image"),
                              description=_(u"The image to show as banner"),
                              required=True)
                              
    width = schema.Int(title=_(u"Width"),
                                 required=False)
                                 
    height = schema.Int(title=_(u"Height"),
                                 required=False)
    
    caption = schema.TextLine(title=_(u"Banner caption"),
                                 description=_(u"The caption you would like to show below the banner"),
                                 required=False)


class Assignment(base.Assignment):
    """Portlet assignment.
    
    This is what is actually managed through the portlets UI and associated
    with columns.
    """
    
    implements(IBannerPortlet)

    url = u""
    img = ''
    caption = u""
    width = None
    height = None

    # TODO: Add keyword parameters for configurable parameters here
    def __init__(self, url=u"", img='', caption=u"", width=None, height=None):
        self.url = url
        self.img = img
        self.caption = caption
        self.width = width
        self.height = height
        
        
    @property
    def title(self):
        """This property is used to give the title of the portlet in the
        "manage portlets" screen.
        """
        return "Banner portlet"
    
    

class Renderer(base.Renderer):
    """Portlet renderer.
    
    This is registered in configure.zcml. The referenced page template is
    rendered, and the implicit variable 'view' will refer to an instance
    of this class. Other methods can be added and referenced in the template.
    """

    render = ViewPageTemplateFile('bannerportlet.pt')
    @property
    def url(self):
        return self.data.url

    def caption(self):
        return self.data.caption


    @property
    def is_flash(self):
        return mimetype(self.context, self.data.img) == \
            'application/x-shockwave-flash'
            
    def width(self):
        return self.data.width
        
    def height(self):
        return self.data.height
        
    def id(self):
        return 'flash-id-' + base64.urlsafe_b64encode(self.img_url).strip('=')
        
    def express_install(self):
        return getToolByName(self.context, 'portal_url')() + '/++resource++pareto.portlet.banner.scripts/expressInstall.swf'

    #================== BEGIN ====================        
    # Taken from plone.app.portlet.manager
    def _context(self):
        context = aq_inner(self.context)
        if isDefaultPage(context, self.request):
            return aq_parent(context)
        else:
            return context

    #==================  END ======================
        
    @property
    def img_url(self):
        column = self.manager.__name__
        url = self.context.unrestrictedTraverse(self.data.context_path).absolute_url()#  + '/++contextportlets++%s/' % column
        return '%s/%s/view_image' % (url, self.data.__name__) 
        
# NOTE: If this portlet does not have any configurable parameters, you can
# inherit from NullAddForm and remove the form_fields variable.

class AddForm(base.AddForm):
    """Portlet add form.
    
    This is registered in configure.zcml. The form_fields variable tells
    zope.formlib which fields to display. The create() method actually
    constructs the assignment that is being added.
    """
    form_fields = form.Fields(IBannerPortlet)

    def create(self, data):
        assignment = Assignment(**data)
        context_path = '/'.join(filter(lambda s: s, self.context.getPhysicalPath()))
        if context_path.endswith('+'):
            context_path = context_path[:-1]
        assignment.context_path = context_path
        return assignment

# NOTE: IF this portlet does not have any configurable parameters, you can
# remove this class definition and delete the editview attribute from the
# <plone:portlet /> registration in configure.zcml

class EditForm(base.EditForm):
    """Portlet edit form.
    
    This is registered with configure.zcml. The form_fields variable tells
    zope.formlib which fields to display.
    """
    form_fields = form.Fields(IBannerPortlet)
    
class ImageView(BrowserView):
    def __call__(self):
        body = self.context.img
        self.request.response.setHeader('Content-type', mimetype(self.context, body))
        return body
