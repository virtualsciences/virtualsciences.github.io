import subprocess
import os
import time

from paste import fileapp
from webob import Request
import simplejson as json

from wheeljack.publisher import Resource
from wheeljack.publisher import WSGIResource
from wheeljack import settings
from wheeljack.templates import TemplateContext
from wheeljack.templates import template_loader
from wheeljack.templates import render_to_response
from wheeljack import models
from wheeljack import forms


media_app = fileapp.DirectoryApp(settings.mediaroot)
favicon_app = fileapp.FileApp(os.path.join(settings.mediaroot, 'favicon.ico'))


class View(Resource):
    master = 'base.html'

    def __init__(self, environ, path=(), parent=None, context=None):
        super(View, self).__init__(environ, path, parent)
        self.context = context
        self.request = Request(environ)

    def data(self):
        return TemplateContext()

    def __call__(self, start_response):
        if 'REMOTE_USER' not in self.environ:
            start_response('401 Unauthorized', [])
            return 'Authentication required'
        tree = template_loader.get(self.template).render(self.data())

        # TODO: find is recursive and thus more slow than it needs to be. A
        # get_first or something would be nice to have as well.
        content = list(list(tree.find('content'))[0])
        headnodes = list(tree.find('head'))
        if headnodes:
            head = list(headnodes[0])
        else:
            head = []

        return render_to_response(start_response, self.master,
                           {'content': content,
                            'head': head,
                            'user': self.environ['REMOTE_USER']})

class Root(View):
    template = 'index.html'

    def user(self):
        return ''

    def projects(self):
        data = []
        for project in models.Project.objects():
            data.append(
                ProjectView.child(self, (project.id,), context=project).data())
        return data

    def add_project_url(self):
        return self.get_absolute_url() + 'create-project'

    def data(self):
        return {'projects': self.projects(), 'user': self.user(),
                'add_project_url': self.add_project_url()}

    def traverse(self, path):
        key = path.pop(0)
        if key == 'media':
            return WSGIResource(self.environ, (key,), self, media_app)
        elif key == 'favicon.ico':
            return WSGIResource(self.environ, (key,), self, favicon_app)
        elif key == 'logout':
            return LogoutView.child(self, (key,)) 
        elif key == 'create-project':
            return CreateProjectView(self.environ, (key,), self)
        else:
            return ProjectView.child(
                self, (key,), models.Project.load(key))

class LogoutView(View):
    def __call__(self, start_response):
        if self.environ['HTTP_REFERER'].strip('/').endswith('logout'):
            start_response('303 See Other', 
                           [('Location', self.parent.get_absolute_url())])
            return ''
        start_response('401 Unauthorized', [])
        return 'Authentication required'

class ProjectView(View):
    template = 'project.html'

    def __init__(self, environ, path, parent, context, logid=None):
        super(ProjectView, self).__init__(environ, path, parent, context)
        self.logid = logid

    def __call__(self, start_response):
        """Render the view and conditionally start builds."""
        # A forced build is triggered when the view is called with a POST.
        if self.environ['REQUEST_METHOD'] == 'POST':
            subprocess.Popen([settings.builder, 'build', self.context.id,
                              '--configuration=%s' % settings.configfile,
                              '--force'],
                             close_fds=True)
            time.sleep(2)
            # Redirect to avoid more forced builds when people hit refresh.
            start_response('303 See Other',
                           [('Location', self.get_absolute_url())])
            return ''
        return super(ProjectView, self).__call__(start_response)

    def data(self):
        """Return the data for the project view."""
        log = self.context.getlog(self.logid)
        if self.logid is None:
            url = self.get_absolute_url()
        else:
            url = self.parent.get_absolute_url()
        data = TemplateContext(
            super(ProjectView, self).data(),
            TemplateContext.with_attrs(
                self.context, 'watch_list', 'repository',
                'build_cmd', 'name', 'state'),
            {'url': url,
             'edit_url': url + '/edit',
             'delete_url': url + '/delete',
             'other_builds': reversed(
                    [{'id': id, 'url': url + '/logs/%s' % id} for
                     id in self.context.logids()])})
        if log is not None:
            data['log'] = TemplateContext.with_attrs(
                log, 'end', 'duration', 'state',
                'revision', 'text')
            data['log']['json-url'] = url + '/logs/%s.json' % log.id
        return data

    def traverse(self, path):
        """Traverse to specific log entries."""
        if len(path) == 2 and path[0] == 'logs':
            key = tuple(path)
            path[:] = []
            # JSON requests should be handled differently
            if key[1].endswith('.json'):
                log = self.context.getlog(key[1].split('.')[0])
                return AjaxLogView.child(self, key, log)
            return ProjectView.child(self, key, self.context, logid=key[1])
        elif len(path) != 1:
            return
        key = path.pop()
        if key == 'edit':
            return EditProjectView.child(self, (key,), self.context)
        elif key == 'delete':
            return DeleteProjectView.child(self, (key,), self.context)

class AjaxLogView(View):

    def __init__(self, environ, path, parent, context):
        super(AjaxLogView, self).__init__(environ, path, parent, context)

    def __call__(self, start_response):
        line = int(self.request.params['line'])
        log = self.context
        data = {'state': log.state(),
                'newText': '\n'.join(log.lines()[line:]),
                'buildtime': str(log.duration())}
        start_response('200 OK', [('content-type', 'text/json')])
        return json.dumps(data)

class FormView(View):
    """Base class for screens that have a single form.

    It requires that the form is rendered using a separate template. This in
    turn makes it possible to reuse the same form template for different views
    (create / update).
    """
    formtemplate = None

    def data(self):
        return {'form': self.form.render(self.formtemplate)}

class EditProjectView(FormView):
    template = 'edit_project.html'
    formtemplate = 'project_form.html'

    def __call__(self, start_response):
        self.form = forms.ProjectForm(context=self.context,
                                      request=self.request)

        if self.request.method == 'POST' and self.form.validate():
            self.form.save()
            start_response('303 See Other',
                           [('Location', self.get_absolute_url())])
            return ''
        return super(EditProjectView, self).__call__(start_response)


class CreateProjectView(FormView):
    template = 'create_project.html'
    formtemplate = 'project_form.html'

    def __call__(self, start_response):
        project = models.Project()
        self.form = forms.ProjectForm(context=project, request=self.request)

        if self.request.method == 'POST' and self.form.validate():
            self.form.data.save()
            project.id = project.name.lower().replace(' ', '-')
            project.save()
            url = self.parent.get_absolute_url() + project.id
            start_response('303 See Other',
                           [('Location', url)])
            return ''
        return super(CreateProjectView, self).__call__(start_response)


class DeleteProjectView(View):
    template = 'delete_project.html'

    def __call__(self, start_response):
        if self.request.method == 'POST':
            self.context.delete()
            url = self.parent.parent.get_absolute_url()
            start_response('303 See Other',
                           [('Location', url)])
            return ''
        return super(DeleteProjectView, self).__call__(start_response)

    def data(self):
        return TemplateContext.with_attrs(self.context, 'name')
