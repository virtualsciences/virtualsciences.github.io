from datetime import datetime

from django import template
from django.utils.translation import ungettext, ugettext

register = template.Library()

@register.filter
def duration(start, end):
    """Human readable description of the period between two datetimes.

    This differs from the built-in filters in that it will also show seconds.
    """
    if not isinstance(start, datetime) or not isinstance(end, datetime):
        return u''

    difference = end - start
    parts = []

    for time, single, plural in [
        (difference.days, 'day', 'days'),
        (difference.seconds // 60, 'minute', 'minutes'),
        (difference.seconds % 60, 'second', 'seconds')]:
        if time != 0:
            parts.append(ugettext('%(number)d %(type)s') %
                         {'number': time,
                          'type': ungettext(single, plural, time)})
    if len(parts) == 0:
        return u'0 ' +  ugettext('seconds')
    elif len(parts) == 1:
        return parts[0]
    return u', '.join(parts[:-1]) + u' and ' + parts[-1]
