import unittest
import os
import tempfile

import mock

class TestParseCfg(unittest.TestCase):
    def test_load_config(self):
        # We need to create the configuration file first.
        cfg = tempfile.mkstemp()[1]
        f = open(cfg, 'w')
        f.write('''
[locations]
configuration = some-dir

[builder]
builder = location/wheeljack
passwd = password-file
builddir = /megatron
secret = sssht-don't tell

[mail]
from = wheeljack@cybertron.space
smtp-server = smtp.cybertron

[server]
host = cybertron.space
port = 9090
''')
        f.close()
        from wheeljack import settings
        # To be able to restore them we need to store all current settings.
        old = dict([(key, getattr(settings, key)) for key in (
                    'configroot', 'builder', 'passwd',
                    'secret', 'default_from', 'smtp_server',
                    'host', 'port', 'builddir')])
        from wheeljack import scripts
        try:
            scripts.loadconfig(cfg)
            self.assertEqual(settings.configroot, 'some-dir')
            self.assertEqual(settings.builder, 'location/wheeljack')
        finally:
            for key, value in old.iteritems():
                setattr(settings, key, value)
            os.remove(cfg)

class TestLoadConfig(unittest.TestCase):
    @mock.patch('wheeljack.scripts.exit_with_error')
    def test_file_does_not_exist(self, error):
        # Loading a configuration file which does not exist will exit the
        # program.
        from wheeljack import scripts
        scripts.loadconfig('does-not-exist')
        error.assert_called_with('Configuration file for Wheeljack does not'
                                 ' exist: does-not-exist')

def test_suite():
    return unittest.TestSuite([
            unittest.makeSuite(TestParseCfg),
            unittest.makeSuite(TestLoadConfig)
            ])
