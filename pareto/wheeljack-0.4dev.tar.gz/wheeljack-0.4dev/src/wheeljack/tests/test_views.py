import os
import unittest
from datetime import datetime
from datetime import timedelta
from StringIO import StringIO

import mock

class TestView(unittest.TestCase):

    def test_protection(self):
        # The view has protection mechanism where it checks for a REMOTE_USER
        # header.
        from wheeljack.views import View
        view = View({})
        headers = []
        def start_response(*args):
            headers.append(args)
        view(start_response)
        self.assertEqual(headers, [('401 Unauthorized', [])])

class TestRoot(unittest.TestCase):

    def root_view(self):
        from wheeljack.views import Root
        return Root({'wsgi.url_scheme': 'http',
                     'REMOTE_USER': 'Starscream',
                     'SERVER_NAME': 'localhost',
                     'SERVER_PORT': '80'}, (), None, None)

    def test_render(self):
        root =self.root_view()
        output = root(lambda status, headers: True)
        self.assert_('Cybertron' in output)
        self.assert_('failure' in output)
        self.assert_('2009-03-05 22:35:49' in output)

    def test_traverse_to_project_view(self):
        # The root is able to traverse to project views.
        root =self.root_view()
        resource = root.traverse(['cybertron'])
        from wheeljack.views import ProjectView
        self.assertEqual(type(resource), ProjectView)

    def test_traverse_to_static_files(self):
        # Static files are served by a WSGI resource
        root =self.root_view()
        resource = root.traverse(['media'])
        from wheeljack.publisher import WSGIResource
        self.assertEqual(type(resource), WSGIResource)

    def test_traverse_to_create_project(self):
        root =self.root_view()
        resource = root.traverse(['create-project'])
        from wheeljack.views import CreateProjectView
        self.assertEqual(type(resource), CreateProjectView)

    def test_traverse_to_favicon(self):
        root =self.root_view()
        resource = root.traverse(['favicon.ico'])
        from wheeljack.publisher import WSGIResource
        self.assertEqual(type(resource), WSGIResource)

    def test_traverse_to_logout(self):
        root =self.root_view()
        resource = root.traverse(['logout'])
        from wheeljack.views import LogoutView
        self.assertEqual(type(resource), LogoutView)

class TestProjectView(unittest.TestCase):

    def view(self, context=None):
        from wheeljack.views import ProjectView
        return ProjectView({'wsgi.url_scheme': 'http',
                            'REMOTE_USER': 'Starscream',
                            'SERVER_NAME': 'localhost',
                            'SERVER_PORT': '80',
                            'REQUEST_METHOD': 'GET'}, (), None, context)

    def test_render(self):
        class FakeLog(object):
            text = 'log-text'
            id = 1

            def end(self):
                return datetime(2009, 3, 5, 22, 35, 49)

            def duration(self):
                return timedelta(0, 156)

            def state(self):
                return 'SUCCESS'

            def revision(self):
                return 'cybertron-rebuild'

        class FakeProject(object):
            watch_list = []
            repository = ''
            build_cmd = ''
            name = 'Cybertron'
            state = 'success'

            def getlog(self, id):
                return FakeLog()

            def logids(self):
                return []

        view = self.view(context=FakeProject())
        output = view(lambda status, headers: True)
        self.assert_('Cybertron' in output)
        self.assert_('log-text' in output)
        self.assert_('2009-03-05 22:35:49' in output)
        self.assert_('0:02:36' in output)
        self.assert_('SUCCESS' in output)
        self.assert_('cybertron-rebuild' in output)
        self.assert_('<link href="http://localhost//logs/1.json"'
                     ' rel="buildlog">' in output)

    def test_specific_log_url(self):
        # When the view is rendering a specific log id it still creates a
        # proper URL (without appending itself again and again etc.).
        class FakeLog(object):
            text = 'log-text'
            id = 1

            def end(self):
                return datetime(2009, 3, 5, 22, 35, 49)

            def duration(self):
                return timedelta(0, 156)

            def state(self):
                return 'SUCCESS'

            def revision(self):
                return 'cybertron-rebuild'

        class FakeRoot(object):
            def get_absolute_url(self):
                return 'http://some-base-url'

        class FakeProject(object):
            id = 'cybertron'
            watch_list = []
            repository = ''
            build_cmd = ''
            name = ''
            logids = lambda self: range(2)
            state = 'success'

            def getlog(self, id):
                return FakeLog()

        view = self.view(context=FakeProject())
        view.parent = FakeRoot()
        view.logid = '12'
        self.assertEqual(
            list(view.data()['other_builds']),
            [{'url': 'http://some-base-url/logs/1', 'id': 1},
             {'url': 'http://some-base-url/logs/0', 'id': 0}])

    @mock.patch('subprocess.Popen')
    @mock.patch('time.sleep')
    def test_force_build(self, Popen, sleep):
        # Build's can be forced by submitting the form.
        class FakeProject(object):
            id = 'cybertron'

        view = self.view(context=FakeProject())
        view.environ['REQUEST_METHOD'] = 'POST'
        response = []
        def start_response(*args):
            response.append(args)
        # The settings file must have information on which configuration file
        # is to be used.
        from wheeljack import settings
        settings.configfile = '/etc/wheeljack.cfg'
        # Now we can run the view.
        output = view(start_response)
        # Forcing the build should redirect us (to avoid repeated builds with a
        # page refresh).
        self.assertEqual(
            response[0],
            ('303 See Other', [('Location', 'http://localhost/')]))
        # It has also called the subprocess module.
        from wheeljack import settings
        Popen.assert_called_with([settings.builder, 'build', 'cybertron',
                                  '--configuration=/etc/wheeljack.cfg',
                                  '--force'],
                                 close_fds=True)
        # To give the builder time to create a new log file etc. a small delay
        # is provided.
        sleep.assert_called_with(2)

    def test_show_links_to_other_builds(self):
        # The page should have links to other builds if available.
        class FakeLog(object):
            text = 'log-text'
            id = 1

            def end(self):
                return datetime(2009, 3, 5, 22, 35, 49)

            def duration(self):
                return timedelta(0, 156)

            def state(self):
                return 'SUCCESS'

            def revision(self):
                return 'cybertron-rebuild'

        class FakeProject(object):
            watch_list = []
            repository = ''
            build_cmd = ''
            name = 'Cybertron'
            state = 'success'

            def getlog(self, id):
                return FakeLog()

            def logids(self):
                return [112, 213, 346]

        view = self.view(context=FakeProject())
        output = view(lambda status, headers: True)
        self.assert_('<a href="http://localhost//logs/112">112</a>'
                     in output)
        self.assert_('<a href="http://localhost//logs/213">213</a>'
                     in output)
        self.assert_('<a href="http://localhost//logs/346">346</a>'
                     in output)

    def test_traverse_to_log(self):
        # Older log entries can be displayed by traversing to them.
        view = self.view()
        new = view.traverse(['logs', '1'])
        self.assertEqual(new.logid, '1')

    def test_traverse_to_edit_view(self):
        # Projects can be edited by traversing to the edit view.
        view = self.view()
        new = view.traverse(['edit'])
        from wheeljack.views import EditProjectView
        self.assertEqual(type(new), EditProjectView)

    def test_traverse_to_delete_view(self):
        # Projects can be deleted by traversing to the delete view.
        view = self.view()
        new = view.traverse(['delete'])
        from wheeljack.views import DeleteProjectView
        self.assertEqual(type(new), DeleteProjectView)

    def test_traverse_to_json_log(self):
        # For Ajax purposes the log information can be retrieved as a JSON
        # document.
        class FakeContext(object):
            def getlog(self, id):
                return
        view = self.view(FakeContext())
        new = view.traverse(['logs', '1.json'])
        from wheeljack.views import AjaxLogView
        self.assertEqual(type(new), AjaxLogView)

    def test_dont_traverse_all(self):
        # When the path is more than one item and it does not refer to a log
        # item None will be returned.
        view = self.view()
        self.assertEqual(view.traverse(['a', 'b']), None)

class TestEditProjectView(unittest.TestCase):

    def test_render_form(self):
        # A form is provided to edit the project data.
        from wheeljack.views import EditProjectView
        view = EditProjectView({'REMOTE_USER': 'Starscream'}, ())
        output = view(lambda status, headers: True)
        self.assert_('input' in output)

    def test_form_submission(self):
        # The data is saved when the form validates.
        from wheeljack.views import EditProjectView
        class FakeContext(object):
            def save(self):
                self.saved = True
        context = FakeContext()
        view = EditProjectView(
            {'REQUEST_METHOD': 'POST',
             'CONTENT_TYPE': 'application/x-www-form-urlencoded',
             'CONTENT_LENGTH': '-1',
             'wsgi.input': StringIO('name=Cybertron&build_cmd=build-city&'
                                    'vcs=bzr&watch_list_str=megatron%40'
                                    'cybertron%0D%0Aprimus%40cybertron'),
             'wsgi.url_scheme': 'http',
             'SERVER_NAME': '127.0.0.1',
             'SERVER_PORT': '8080',},
            ('project', 'edit'),
            context=context)
        # It will also do a redirect.
        output = []
        view(lambda status, headers: output.append((status, headers)))
        self.assertEqual(output, [('303 See Other', [
                        ('Location','http://127.0.0.1:8080//project/edit')])])
        self.assert_(context.saved)

class TestCreateProjectView(unittest.TestCase):

    def test_render_form(self):
        # A form is provided to edit the project data.
        from wheeljack.views import CreateProjectView
        view = CreateProjectView({'REMOTE_USER': 'Starscream'}, ())
        output = view(lambda status, headers: True)
        self.assert_('input' in output)

    def test_form_submission(self):
        # The data is saved when the form validates.
        from wheeljack.views import CreateProjectView
        class FakeParent(object):
            get_absolute_url = lambda self: 'http://somehost/'
        view = CreateProjectView(
            {'REQUEST_METHOD': 'POST',
             'CONTENT_TYPE': 'application/x-www-form-urlencoded',
             'CONTENT_LENGTH': '-1',
             'wsgi.input': StringIO('name=Home&build_cmd=build-city&'
                                    'vcs=bzr&watch_list_str=megatron%40'
                                    'cybertron%0D%0Aprimus%40cybertron'),
             'wsgi.url_scheme': 'http',
             'SERVER_NAME': '127.0.0.1',
             'SERVER_PORT': '8080',},
            ('project', 'edit'),
            parent=FakeParent())
        # It will also do a redirect.
        output = []
        view(lambda status, headers: output.append((status, headers)))
        self.assertEqual(output, [('303 See Other', [
                        ('Location','http://somehost/home')])])
        # There should now be a new project file
        from wheeljack import settings
        filename = os.path.join(settings.configroot, 'projects', 'home.cfg')
        self.assert_(os.path.exists(filename))
        os.remove(filename)

class TestDeleteProjectView(unittest.TestCase):

    def test_render_form(self):
        # A form is provided to give the user a final choice.
        from wheeljack.views import DeleteProjectView
        class FakeContext(object):
            name = ''
        view = DeleteProjectView({'REMOTE_USER': 'Starscream'},
                                 (), context=FakeContext())
        output = view(lambda status, headers: True)
        self.assert_('Delete' in output)

    def test_form_submission(self):
        # The project is deleted when the form is submitted.
        from wheeljack.views import DeleteProjectView
        class FakeParent(object):
            get_absolute_url = lambda self: 'http://somehost'
        class FakeContext(object):
            def delete(self):
                self.deleted = True
        context = FakeContext()
        parent = FakeParent()
        parent.parent = FakeParent()
        view = DeleteProjectView({'REQUEST_METHOD': 'POST'}, (),
                                 context=context, parent=parent)
        output = []
        view(lambda status, headers: output.append((status, headers)))
        self.assertEqual(output, [('303 See Other', [
                        ('Location','http://somehost')])])
        self.assert_(context.deleted)

class TestLogoutView(unittest.TestCase):

    def test_logout_sets_header(self):
        # To log out of the application it needs to set an unauthorized header.
        from wheeljack.views import LogoutView
        response = []
        def start_response(*args):
            response.append(args)
        view = LogoutView({'HTTP_REFERER': ''})
        view(start_response)
        self.assertEqual(response, [('401 Unauthorized', [])])

    def test_redirect_after_logout(self):
        # When a user submits new credentials to the logout view it will tru to
        # redirect them to the start page.
        from wheeljack.views import LogoutView
        class FakeParent(object):
            get_absolute_url = lambda self: 'http://somehost'
        view = LogoutView({'HTTP_REFERER': '/logout'}, parent=FakeParent())
        response = []
        def start_response(*args):
            response.append(args)
        view(start_response)
        self.assertEqual(
            response,
            [('303 See Other', [('Location', 'http://somehost')])])

class TestAjaxLogView(unittest.TestCase):

    def test_render(self):
        # JSON is returned when the view is rendered.
        class FakeLog(object):
            def state(self): return 'building'
            def lines(self): return ['line 1', 'line 2']
            def duration(self): return datetime(2001, 12, 23)

        from wheeljack.views import AjaxLogView
        view = AjaxLogView(
            environ={'REQUEST_METHOD': 'GET',
                     'CONTENT_LENGTH': '-1',
                     'wsgi.url_scheme': 'http',
                     'QUERY_STRING': 'line=0',
                     'SERVER_NAME': '127.0.0.1',
                     'SERVER_PORT': '8080',},
            path=[],
            parent=None,
            context=FakeLog())

        response = []
        def start_response(*args):
            response.append(args)
        self.assertEqual(
            view(start_response),
            '{"newText": "line 1\\nline 2", "state": "building", '
            '"buildtime": "2001-12-23 00:00:00"}')
        self.assertEqual(response,
                         [('200 OK', [('content-type', 'text/json')])])

def test_suite():
    return unittest.TestSuite([
            unittest.makeSuite(TestView),
            unittest.makeSuite(TestRoot),
            unittest.makeSuite(TestProjectView),
            unittest.makeSuite(TestEditProjectView),
            unittest.makeSuite(TestCreateProjectView),
            unittest.makeSuite(TestDeleteProjectView),
            unittest.makeSuite(TestLogoutView),
            unittest.makeSuite(TestAjaxLogView),
            ])
