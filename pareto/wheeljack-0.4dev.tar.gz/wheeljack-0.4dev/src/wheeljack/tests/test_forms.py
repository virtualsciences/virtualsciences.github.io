import unittest

import mock
from repoze.formapi.error import Errors

class TestTemplessForm(unittest.TestCase):

    def test_template_context_without_fields(self):
        # The template context method returns a context which is suited for use
        # with templess. Without fields the context is pretty sparse.
        from wheeljack.forms import TemplessForm
        form = TemplessForm()
        self.assertEqual(form.template_context(),
                         {'form-class': 'normal', 'errors': Errors()})

    def test_template_context_fields(self):
        from wheeljack.forms import TemplessForm

        class Form(TemplessForm):
            fields = {'name': str, 'count': int}
        form = Form()
        self.assertEqual(form.template_context(),
                         {'count': None, 'errors': Errors(),
                          'name': None, 'form-class': 'normal'})

    def test_template_context_with_errors(self):
        from wheeljack.forms import TemplessForm
        from repoze import formapi

        class Form(TemplessForm):
            fields = {'name': str}
            @formapi.validator('name')
            def check_name(self):
                yield 'name not valid'
        form = Form()
        form.validate()
        errors = Errors()
        errors['name'].append('name not valid')
        self.assertEqual(form.template_context(),
                         {'form-class': 'errorlist', 'errors': errors,
                          'name': None})

    def test_option_fields(self):
        # By defining option fields these fields will be setup for use with
        # templess.
        from wheeljack.forms import TemplessForm

        class Form(TemplessForm):
            fields = {'vcs': str}
            option_fields = {'vcs': (('bzr', 'Bazaar'),
                                     ('svn', 'Subversion'))}
        form = Form()
        self.assertEqual(
            form.template_context(),
            {'vcs': [{'text': 'Bazaar', 'selected': None, 'value': 'bzr'},
                     {'text': 'Subversion', 'selected': None, 'value': 'svn'}],
             'form-class': 'normal', 'errors': Errors()})

    def test_save(self):
        from wheeljack.forms import TemplessForm

        class Form(TemplessForm):
            fields = {'name': str}

        class FakeContext(object):
            def __init__(self):
                self.name = 'Optimus Prime'
            def save(self):
                self.saved = True

        class Request(object):
            params = {'name': 'Megatron'}
        context = FakeContext()
        form = Form(context=context, request=Request())
        form.save()
        self.assertEqual(context.name, 'Megatron')
        self.assert_(context.saved)

    @mock.patch('wheeljack.forms.template_loader')
    def test_render(self, loader):
        # A form can be rendered to use directly with the template system.
        from wheeljack.forms import TemplessForm

        form = TemplessForm()
        class FakeTree(object):
            def find(self, tag):
                return ['data']

        class FakeTemplate(object):
            def render(self, context):
                return FakeTree()
        loader.get.return_value = FakeTemplate()
        self.assertEqual(form.render('fake-template.html'), 'data')

class TestProjectForm(unittest.TestCase):

    def test_validate_name(self):
        # The name field is a required field.
        from wheeljack.forms import ProjectForm
        class Request(object):
            params = {'name': ''}
        form = ProjectForm(request=Request())
        self.failIf(form.validate())
        self.assertEqual(unicode(form.errors['name']), u'Name is required')

def test_suite():
    return unittest.TestSuite([
            unittest.makeSuite(TestTemplessForm),
            unittest.makeSuite(TestProjectForm)])
