import unittest
import os
import shutil
import tempfile
from datetime import datetime
from datetime import timedelta

import mock

class TestProject(unittest.TestCase):

    @property
    def project_factory(self, *args, **kwargs):
        from wheeljack.models import Project
        return Project

    def test_load_project(self):
        # Information from disk is loaded to initialize a project.
        from wheeljack import models
        project = models.Project.load('cybertron')
        self.assertEqual(project.name, 'Cybertron')

    def test_load_non_existing_project(self):
        # Loading a non-existing project raises a KeyError.
        from wheeljack import models
        self.assertRaises(KeyError, models.Project.load, 'does-not-exist')

    def test_create_project(self):
        # A new project can be created by instantiating it with a unique id.
        from wheeljack import models
        project = models.Project('earth')
        # It's default values will be None.
        self.assertEqual(project.name, None)

    def test_save_project(self):
        # A project can be saved to disk. Let's make sure we do not yet have
        # the configuration file for our project.
        from wheeljack import settings
        fn = os.path.join(settings.configroot, 'projects', 'earth.cfg')
        self.assertFalse(os.path.exists(fn))
        # Now we can create the new project an save it.
        from wheeljack import models
        project = models.Project('earth')
        project.name = 'Earth'
        project.save()
        # This has created our configuration file.
        self.assert_(os.path.exists(fn))
        # Let's remove it to clean up again.
        os.remove(fn)

    def test_save_without_projects_dir(self):
        # If the projects directory does not exist when saving a project it
        # should be created.
        tmp = tempfile.mkdtemp()
        from wheeljack import settings
        oldroot = settings.configroot
        settings.configroot = tmp
        fn = os.path.join(settings.configroot, 'projects', 'earth.cfg')
        from wheeljack import models
        project = models.Project('earth')
        project.name = 'Earth'
        try:
            project.save()
            # This has created our configuration file.
            self.assert_(os.path.exists(fn))
        finally:
            # Let's remove the configroot to clean up again.
            shutil.rmtree(tmp)
            settings.configroot = oldroot

    def test_delete_project(self):
        # Projects can be deleted.
        from wheeljack import settings
        fn = os.path.join(settings.configroot, 'projects', 'earth.cfg')
        f = open(fn, 'w')
        f.write('')
        f.close()
        from wheeljack import models
        project = models.Project('earth')
        project.delete()
        self.failIf(os.path.exists(fn))

    def test_objects(self):
        # A class method is provided to get all the available projects.
        from wheeljack import models
        projects = models.Project.objects()
        self.assertEqual(len(projects), 1)
        self.assertEqual(projects[0].name, 'Cybertron')

    def test_watch_list_str(self):
        # The watch list can be accessed as a string.
        from wheeljack import models
        project = models.Project.load('cybertron')
        self.assertEqual(project.watch_list_str,
                         'megatron@cybertron\nprimus@cybertron')
        project.watch_list_str = 'new\nitems\n   '
        self.assertEqual(project.watch_list, ['new', 'items'])

    def test_logids(self):
        # The log ids are taken from the actual log files stored on disk.
        from wheeljack import models
        project = models.Project.load('cybertron')
        self.assertEqual(project.logids(), [12, 140])

    @mock.patch('os.listdir')
    def test_logids_are_sorted(self, listdir):
        # The log ids are sorted.
        listdir.return_value = ['1.log', '5.log', '2.log', '3.log', '4.log']
        from wheeljack import models
        project = models.Project.load('cybertron')
        self.assertEqual(project.logids(), [1, 2, 3, 4, 5])

    def test_state_no_builds(self):
        # The state of the project is based on the state of the last
        # build. When there are no builds it returns an empty string.
        project = self.project_factory('id', 'update-test', 'cmd',
                                       '/some/repo', 'bzr')
        self.assertEqual(project.state(), '')

    def test_state_from_build_log(self):
        # The state of the project is based on the state of the build log.
        project = self.project_factory('id', 'update-test', 'cmd',
                                       '/some/repo', 'bzr')
        # Create a log file with a last line saying success or failure.
        from wheeljack import settings
        logdir = os.path.join(settings.configroot, 'logs', 'id')
        try:
            os.makedirs(logdir)
            f = open(os.path.join(logdir, '124.log'), 'w').write(
                '[23:23:35] Build state: SUCCESS')
            self.assertEqual(project.state(), 'success')
        finally:
            shutil.rmtree(logdir)

    def test_last_revision(self):
        # The last revision is read from the latest log object.
        project = self.project_factory('id', 'update-test', 'cmd',
                                       '/some/repo', 'bzr')
        self.assertEqual(project.last_revision(), None)
        # When there is a log item it will use that.
        from wheeljack import models
        project = models.Project.load('cybertron')
        self.assertEqual(project.last_revision(), 'cybertron-rebuild')

    def test_getlog(self):
        # The current log can be loaded directly from the model.
        from wheeljack import models
        project = models.Project.load('cybertron')
        log = project.getlog()
        self.assertEqual(
            log.text.split('\n')[0],
            "[2009-03-05 22:35:47] Building revision: cybertron-rebuild")


    def test_getlog_specific(self):
        # Specific log id's can be loaded by passing in an argument.
        from wheeljack import models
        project = models.Project.load('cybertron')
        log = project.getlog('12')
        self.assertEqual(log.text.split('\n'),
                         ['[2009-03-05 22:35:47] Building revision: 1254',
                          '[2009-03-05 23:15:29] Build state: SUCCESS'])

    @mock.patch('wheeljack.models.Project.revision')
    def test_is_updated(self, revision):
        # The project can determine if a project has been updated.
        project = self.project_factory('id', 'update-test', 'cmd',
                                       '/some/repo', 'bzr')
        # To demonstrate the functionality we can use the mocked bzrlib
        # objects.
        revision.return_value = 'last-revision'

        self.assert_(project.is_updated())
        # The check returns a different value if bazaar returns the same value
        # for the revision info.
        revision.return_value = None
        self.failIf(project.is_updated())

    @mock.patch('bzrlib.branch.Branch.open_containing')
    def test_is_updated_error(self, bzropen_containing):
        # When the project encounters an error during it's status check it
        # should raise a build error.
        from bzrlib.errors import NotBranchError
        def error():
            raise NotBranchError, 'error'
        bzropen_containing.side_effect = error
        project = self.project_factory('id', 'update-test', 'cmd',
                                       '/some/repo', 'bzr')
        from wheeljack.builder import BuildError
        self.assertRaises(BuildError, project.is_updated)

    @mock.patch('wheeljack.repositories.BzrRepository.__enter__')
    @mock.patch('wheeljack.repositories.BzrRepository.__exit__')
    @mock.patch('wheeljack.models.Project.revision')
    @mock.patch('subprocess.Popen')
    def test_build(self, bzrexport_enter, bzrexport_exit, revision, Popen):
        # Projects know how to build themselves.
        project = self.project_factory('id', 'build-test', 'cmd',
                                       '/some/repo', 'bzr')
        # The build system uses subprocess to do the actual work. It polls the
        # program to see when it is done.
        bzrexport_enter.return_value = '/some/tmp/dir'
        Popen().poll.return_value = 0
        Popen().stdout.read.return_value = ''
        class Log(object):
            def info(self, message):
                pass
        state = project.build(Log())
        import subprocess
        self.assertEqual(Popen.call_args,
                         ((['cmd'],), {'stderr': subprocess.STDOUT,
                                       'stdout': subprocess.PIPE,
                                       'cwd': '/some/tmp/dir'}))
        # The build returns if the build has been completed successfully.
        self.failIf(state)

    @mock.patch('wheeljack.repositories.BzrRepository.__enter__')
    @mock.patch('wheeljack.repositories.BzrRepository.__exit__')
    @mock.patch('wheeljack.models.Project.revision')
    @mock.patch('subprocess.Popen')
    def test_revision_info_in_log(self, bzrexport_enter, bzrexport_exit,
                                  revision, Popen):
        # Revision information is stored in the log file.
        revision.return_value = 'rev-info'
        project = self.project_factory('id', 'build-test', 'cmd',
                                       '/some/repo', 'bzr')
        bzrexport_enter.return_value = '/some/tmp/dir'
        Popen().poll.return_value = 0
        Popen().stdout.read.return_value = ''
        class Log(object):
            log = []
            def info(self, message):
                self.log.append(message)
        project.build(Log())
        self.assertEqual(Log.log[0], 'Building revision: rev-info')

    @mock.patch('wheeljack.repositories.BzrRepository.__enter__')
    @mock.patch('wheeljack.repositories.BzrRepository.__exit__')
    @mock.patch('wheeljack.models.Project.revision')
    @mock.patch('subprocess.Popen')
    def test_failure_state_in_log(self, bzrexport_enter, bzrexport_exit,
                                revision, Popen):
        # The final line in the build log contains the build state.
        project = self.project_factory('id', 'build-test', 'cmd',
                                       '/some/repo', 'bzr')
        bzrexport_enter.return_value = '/some/tmp/dir'
        Popen().poll.return_value = 0
        Popen().stdout.read.return_value = ''
        class Log(object):
            log = []
            def info(self, message):
                self.log.append(message)
        project.build(Log())
        self.assertEqual(Log.log[-1], 'Build state: FAILURE')

    @mock.patch('wheeljack.repositories.BzrRepository.__enter__')
    @mock.patch('wheeljack.repositories.BzrRepository.__exit__')
    @mock.patch('wheeljack.models.Project.revision')
    @mock.patch('subprocess.Popen')
    def test_success_state_in_log(self, bzrexport_enter, bzrexport_exit,
                                revision, Popen):
        # The final line in the build log contains the build state.
        project = self.project_factory('id', 'build-test', 'cmd',
                                       '/some/repo', 'bzr')
        bzrexport_enter.return_value = '/some/tmp/dir'
        Popen().poll.return_value = 0
        Popen().stdout.read.return_value = ''
        Popen().returncode = 0
        class Log(object):
            log = []
            def info(self, message):
                self.log.append(message)
        project.build(Log())
        self.assertEqual(Log.log[-1], 'Build state: SUCCESS')

    @mock.patch('wheeljack.repositories.BzrRepository.__enter__')
    @mock.patch('wheeljack.repositories.BzrRepository.__exit__')
    @mock.patch('wheeljack.models.Project.revision')
    @mock.patch('subprocess.Popen')
    def test_error_state_in_log(self, bzrexport_enter, bzrexport_exit,
                                revision, Popen):
        # The final line in the build log contains the build state.
        project = self.project_factory('id', 'build-test', 'cmd',
                                       '/some/repo', 'bzr')
        bzrexport_enter.return_value = '/some/tmp/dir'
        def raise_error():
            raise OSError('barf')
        Popen.side_effect = raise_error
        class Log(object):
            log = []
            def  info(self, *args):
                pass
            def error(self, message):
                self.log.append(message)
        project.build(Log())
        self.assertEqual(Log.log[-1], 'Build state: ERROR')

    @mock.patch('wheeljack.repositories.BzrRepository.__enter__')
    @mock.patch('wheeljack.repositories.BzrRepository.__exit__')
    @mock.patch('wheeljack.models.Project.revision')
    @mock.patch('subprocess.Popen')
    def test_successful_build(self, bzrexport_enter, bzrexport_exit, revision, Popen):
        # A successful build means that the program executes without problems.
        project = self.project_factory('id', 'build-test', 'cmd',
                                       '/some/repo', 'bzr')
        bzrexport_enter.return_value = '/some/tmp/dir'
        Popen().poll.return_value = 0
        Popen().stdout.read.return_value = ''
        Popen().returncode = 0
        class Log(object):
            def info(self, message):
                pass
        self.assert_(project.build(Log()))


    @mock.patch('wheeljack.repositories.BzrRepository.__enter__')
    @mock.patch('wheeljack.repositories.BzrRepository.__exit__')
    @mock.patch('wheeljack.models.Project.revision')
    @mock.patch('subprocess.Popen')
    @mock.patch('os.kill')
    def test_build_hang_detection(self,  bzrexport_enter, bzrexport_exit,
                                  revision, Popen, kill):
        # A build could potentially have a problem that would hang the
        # builder. To overcome this the builder tries to detect these kind of
        # situations.
        bzrexport_enter.return_value = '/some/tmp/dir'
        bzrexport_exit.return_value = False # Avoid exception swallowing.

        project = self.project_factory('id', 'build-test', 'cmd',
                                       '/some/repo', 'bzr')
        # We will make it look like the stdout pipe never changes.
        Popen().stdout.fileno.return_value = 1
        # A None value form a poll call means the process is still running.
        Popen().poll.return_value = None
        # Before we build the project we need to set a reasonable build
        # timeout.
        from wheeljack import models
        models.build_timeout = 0.001
        # Building the project will raise an exception.
        from wheeljack.builder import BuildError
        class Log(object):
            def info(self, *args):
                pass
        self.assertRaises(BuildError, project.build, Log())
        # The process should have been killed by the builder.
        import signal
        self.assertEqual(kill.call_args[0][1], signal.SIGKILL)

    @mock.patch('wheeljack.repositories.BzrRepository.__enter__')
    @mock.patch('wheeljack.repositories.BzrRepository.__exit__')
    @mock.patch('subprocess.Popen')
    def test_build_subprocess_error(self, bzrexport_enter, bzrexport_exit,
                                    Popen):
        # Calling programs which do not exist should be converted into build
        # errors.
        bzrexport_enter.return_value = '/some/tmp/dir'
        bzrexport_exit.return_value = False # Avoid exception swallowing.	
        project = self.project_factory('id', 'build-test', 'cmd',
                                       '/some/repo', 'bzr')
        # The OSError will be converted into a BuildError for better reporting.
        from wheeljack.builder import BuildError
        log = mock.Mock()
        self.assertRaises(BuildError, project.build, log)

    @mock.patch('wheeljack.repositories.BzrRepository.__enter__')
    @mock.patch('wheeljack.repositories.BzrRepository.__exit__')
    @mock.patch('subprocess.Popen')
    @mock.patch('wheeljack.models.Project.revision')
    @mock.patch('select.select')
    def test_build_updates_log(self, bzrexport_enter, bzrexport_exit,
                                 Popen, revision, select):
        # During a build the log will be frequently updated with information
        # about the progress.
        bzrexport_enter.return_value = '/some/tmp/dir'
        bzrexport_exit.return_value = False # Avoid exception swallowing.
        class FakePoll:
            def __init__(self, counter):
                self.counter = counter
            def __call__(self):
                self.counter -= 1
                if self.counter == 0:
                    return False
        popen = Popen()
        popen.poll = FakePoll(len('output\n') + 1)
        popen.stdout.read.return_value = 'before last\nlast line\n'

        stdout = mock.Mock()
        data_gen = iter(c for c in 'output\n')
        stdout.read = lambda n: data_gen.next()
        select.return_value = [[stdout], None, None]

        project = self.project_factory('id', 'build-test',
                                       'cmd', '/some/repo', 'bzr')

        class Log(object):
            output = []
            def info(self, message):
                self.output.append(message)
        log = Log()

        project.build(log)
        self.assertEqual(log.output[1:], ['output', 'before last',
                                          'last line', 'Build state: FAILURE'])

class TestLog(unittest.TestCase):

    def test_start(self):
        from wheeljack.models import Log
        class Project(object):
            id = 'cybertron'
        log = Log(Project(), '140')
        self.assertEqual(log.start(), datetime(2009, 3, 5, 22, 35, 47))

    def test_end(self):
        from wheeljack.models import Log
        class Project(object):
            id = 'cybertron'
        log = Log(Project(), '140')
        self.assertEqual(log.end(), datetime(2009, 3, 5, 22, 35, 49))

    def test_end_with_empty_log(self):
        # When the log file is empty the current time will be used as a
        # preliminary end time.
        from wheeljack.models import Log
        class Project(object):
            id = 'cybertron'
        log = Log(Project(), '42')
        f = open(log.path, 'w')
        f.close()
        try:
            self.assertEqual(log.end().strftime('%Y%m%d'),
                             datetime.now().strftime('%Y%m%d'))
        finally:
            os.remove(log.path)

    def test_duration(self):
        from wheeljack.models import Log
        class Project(object):
            id = 'cybertron'
        log = Log(Project(), '140')
        self.assertEqual(log.duration(), timedelta(0, 2))

    def test_revision(self):
        # The revision is taken from the log file.
        from wheeljack.models import Log
        class Project(object):
            id = 'cybertron'
        log = Log(Project(), '140')
        self.assertEqual(log.revision(), 'cybertron-rebuild')

    def test_revision_from_empty_file(self):
        from wheeljack.models import Log
        class Project(object):
            id = 'cybertron'
        log = Log(Project(), '923')
        f = open(log.path, 'w')
        f.close()
        try:
            self.assertEqual(log.revision(), None)
        finally:
            os.remove(log.path)

    def test_building_state(self):
        # The state of the log is considered `building` when the last line does
        # not contain a normal state indicator.
        from wheeljack.models import Log
        class Project(object):
            id = 'cybertron'
        log = Log(Project(), '923')
        f = open(log.path, 'w')
        f.write('[2009-04-05 02:15:19] Some output line')
        f.close()
        try:
            self.assertEqual(log.state(), 'building')
        finally:
            os.remove(log.path)


def test_suite():
    return unittest.TestSuite([
            unittest.makeSuite(TestProject),
            unittest.makeSuite(TestLog),
            ])
