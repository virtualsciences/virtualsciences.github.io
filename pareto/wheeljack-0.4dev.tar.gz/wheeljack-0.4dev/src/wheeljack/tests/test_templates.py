import unittest

import mock

class TestPackageLoader(unittest.TestCase):

    def test_get_path(self):
        # Get path should return the path of the template
        from wheeljack.templates import PackageLoader
        loader = PackageLoader('wheeljack')
        self.assertEqual(loader.get_path('some/template.html'),
                         'templates/some/template.html')

    def test_get_filename(self):
        from wheeljack.templates import PackageLoader
        loader = PackageLoader('wheeljack')
        self.assertEqual(loader.get_filename(template='index.html')[-34:],
                         'src/wheeljack/templates/index.html')

    def test_get_non_existing_filename(self):
        # When a file does not exist we will get an error.
        from wheeljack.templates import PackageLoader
        loader = PackageLoader('wheeljack')
        self.assertRaises(KeyError, loader.get_filename, 'does-not-exist')

    def test_get(self):
        # To load a template the get method should be called.
        from wheeljack.templates import PackageLoader
        loader = PackageLoader('wheeljack')
        tmpl = loader.get('index.html')
        from templess.templess import template
        self.assert_(isinstance(tmpl, template))

    def test_get_from_cache(self):
        # When auto reloading is disabled a template will always be loaded from
        # cache.
        from wheeljack.templates import PackageLoader
        loader = PackageLoader('wheeljack')
        tmpl = loader.get('index.html')
        self.assert_(tmpl is loader.get('index.html'))

    @mock.patch('os.path.getmtime')
    def test_get_modified_template(self, getmtime):
        # If template is modified after it has been cached it will be reloaded
        # on a new request.
        from wheeljack.templates import PackageLoader
        loader = PackageLoader('wheeljack', autoreload=True)
        tmpl = loader.get('index.html')
        getmtime.return_value = 0
        self.assert_(tmpl is not loader.get('index.html'))

class TestTemplateContext(unittest.TestCase):

    def test_update(self):
        # The update method is handy in that it returns the context. This makes
        # it possible to chain commands.
        from wheeljack.templates import TemplateContext
        context = TemplateContext()
        self.assert_(context.update({}) is context)

    def test_update_with(self):
        # The context supports being updated based on an object.
        class FakeObj(object):
            name = 'Cybertron'

            def project_count(self):
                return 4

        from wheeljack.templates import TemplateContext
        context = TemplateContext().update_with(FakeObj(),
                                                'name', 'project_count')
        self.assertEqual(context, {'name': 'Cybertron', 'project_count': 4})

    def test_with_attrs(self):
        # A new context can be created with it's keys taken from an objects
        # attributes.
        class FakeObj(object):
            name = 'Cybertron'

            def project_count(self):
                return 4

        from wheeljack.templates import TemplateContext
        context = TemplateContext.with_attrs(FakeObj(),
                                             'name', 'project_count')
        self.assertEqual(context, {'name': 'Cybertron', 'project_count': 4})

    def test_initialize_from_dicts(self):
        # A context can be initialized with values from multiple dictionaries.
        from wheeljack.templates import TemplateContext
        context = TemplateContext({'a': 1, 'b': 2}, {'c': 3, 'd': 4})
        self.assertEqual(context, {'a': 1, 'b': 2, 'c': 3, 'd': 4})

def test_suite():
    return unittest.TestSuite([
            unittest.makeSuite(TestPackageLoader),
            unittest.makeSuite(TestTemplateContext),
            ])
