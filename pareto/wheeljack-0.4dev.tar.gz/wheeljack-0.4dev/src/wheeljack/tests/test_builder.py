import unittest
import os
import shutil
import tempfile

import mock

class TestBuildError(unittest.TestCase):

    def test_str(self):
        # The exception knows how to generate an informative message.
        from wheeljack.builder import BuildError
        self.assertEqual(
            str(BuildError('cmd', 'rev', None, 'output')),
            'Command: cmd failed. Output from executiion:\n\noutput')

class TestBuilder(unittest.TestCase):

    @mock.patch('wheeljack.builder.log')
    @mock.patch('wheeljack.builder.Builder.getlog')
    @mock.patch('wheeljack.models.Project.objects')
    @mock.patch('wheeljack.builder.sendmail')
    def test_build_updated_projects(self, log_info, getlog, objects, send):
        # The builder will build all the projects that have changes.
        project = mock.Mock()
        project.id = 'cybertron'
        project.is_updated.return_value = True
        project.build.return_value = False
        objects.return_value = [project]
        from wheeljack.builder import Builder
        Builder().build_all()
        self.assert_(project.build.called)

    @mock.patch('wheeljack.builder.log')
    @mock.patch('wheeljack.builder.Builder.getlog')
    @mock.patch('wheeljack.models.Project.objects')
    @mock.patch('wheeljack.builder.sendmail')
    def test_no_updates(self, log_info, getlog, objects, send):
        # When a project has no updates the build will be skipped.
        project = mock.Mock()
        project.id = 'cybertron'
        project.is_updated.return_value = False
        project.require_build = False
        objects.return_value = [project]
        from wheeljack.builder import Builder
        Builder().build_all()

        self.failIf(project.build.called)

    @mock.patch('wheeljack.builder.log')
    @mock.patch('wheeljack.builder.Builder.getlog')
    @mock.patch('wheeljack.models.Project.objects')
    @mock.patch('wheeljack.builder.sendmail')
    def test_send_failure_mail(self, log_info, getlog, objects, send):
        # People that are on the watch list are send a mail message when the
        # build fails.
        project = mock.Mock()
        project.id = 'cybertron'
        project.name = 'Cybertron'
        project.is_updated.return_value = True
        project.watch_list = ['starscream@cybertron']
        project.build.return_value = False
        project.getlog().text = 'Error log'
        objects.return_value = [project]
        from wheeljack.builder import Builder
        Builder().build_all()
        send.assert_called_with(['starscream@cybertron'],
                                'Build failure: Cybertron',
                                'The build did not complete successfully for'
                                ' project: Cybertron.\n\nError log')

    @mock.patch('wheeljack.builder.log')
    @mock.patch('wheeljack.builder.Builder.getlog')
    @mock.patch('wheeljack.models.Project.objects')
    @mock.patch('wheeljack.builder.sendmail')
    def test_send_error_mail(self, log_info, getlog, objects, send):
        # People that are on the watch list are send a mail message when the
        # build fails.
        from wheeljack.errors import BuildError
        project = mock.Mock()
        project.id = 'cybertron'
        project.name = 'Cybertron'
        project.is_updated.return_value = True
        project.watch_list = ['starscream@cybertron']
        def raise_error():
            raise BuildError(None, None, None, None)
        project.build.side_effect = raise_error
        project.getlog().text = 'Error log'
        objects.return_value = [project]
        from wheeljack.builder import Builder
        Builder().build_all()
        send.assert_called_with(['starscream@cybertron'],
                                'Build error: Cybertron',
                                'There was a problem building: Cybertron.\n'
                                '\nError log')

    def test_getlog(self):
        # The getlog method creates a log file object.
        from wheeljack.builder import Builder
        builder = Builder()
        project = mock.Mock()
        project.id = 'cybertron'
        project.logids.return_value = []
        log = builder.getlog(project)
        from wheeljack.builder import BuildLogger
        self.assert_(isinstance(log, BuildLogger))

    def test_increasing_log_number(self):
        # Each time a log object is created it will create a new log file with
        # an increasing id.
        from wheeljack.builder import Builder
        builder = Builder()
        project = mock.Mock()
        project.id = 'cybertron'
        project.logids.return_value = [4, 12, 15]
        log = builder.getlog(project)
        self.assertEqual(os.path.split(log.path)[-1], '16.log')

    def test_no_log_folder(self):
        # When a log folder does not exist yet it will be created when a log is
        # object is created.
        from wheeljack.builder import Builder
        builder = Builder()
        project = mock.Mock()
        project.id = 'system-crash'
        project.logids.return_value = [4, 12, 15]
        from wheeljack import settings
        logdir = os.path.join(settings.configroot, 'logs', project.id)
        self.failIf(os.path.exists(logdir))
        log = builder.getlog(project)
        self.assert_(os.path.exists(logdir))
        shutil.rmtree(logdir)

class TestBuildLogger(unittest.TestCase):

    def test_info(self):
        # The info method writes a line to the log file.
        from wheeljack.builder import BuildLogger
        path = tempfile.mktemp()
        log = BuildLogger(path)
        log.info('test message')
        f = open(path)
        # The first part of each line contains a time stamp. To avoid errors
        # this is not tested but just skipped.
        self.assertEqual(f.read()[22:], 'test message\n')
        f.close()
        os.remove(path)

    def test_error(self):
        # The error method writes a line to the log file.
        from wheeljack.builder import BuildLogger
        path = tempfile.mktemp()
        log = BuildLogger(path)
        log.error('test message')
        f = open(path)
        # The first part of each line contains a time stamp. To avoid errors
        # this is not tested but just skipped.
        self.assertEqual(f.read()[22:], 'test message\n')
        f.close()
        os.remove(path)

def test_suite():
    return unittest.TestSuite([
            unittest.makeSuite(TestBuildError),
            unittest.makeSuite(TestBuilder),
            unittest.makeSuite(TestBuildLogger),
     ])
