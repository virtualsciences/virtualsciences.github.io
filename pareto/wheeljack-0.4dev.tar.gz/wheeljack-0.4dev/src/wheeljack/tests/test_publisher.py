import unittest

class TestResource(unittest.TestCase):

    @property
    def resource(self):
        from wheeljack.publisher import Resource
        return Resource

    def test_traverse(self):
        # The default traverse implementation should return None.
        resource = self.resource(None)
        self.assert_(resource.traverse(None) is None)

    def test_rendering(self):
        # A not implemented error is raised from the default rendering.
        resource = self.resource(None)
        self.assertRaises(NotImplementedError, resource, None)

    def test_init_path(self):
        # The path argument to init must be an iterable.
        Resource = self.resource
        self.assertRaises(TypeError, Resource, None, None)

    def test_init_path_convert_to_tuple(self):
        # A path which is passed in to the resource is converted to a tuple.
        self.assertEqual(self.resource(None, xrange(2)).path, (0, 1))

    def test_get_absolute_url(self):
        # The get_absolute_url method makes sure we get a proper URL based on
        # the environ and the currently traversed path.
        resource = self.resource({'wsgi.url_scheme': 'http',
                                  'SERVER_NAME': 'myserver',
                                  'SERVER_PORT': '8000'},
                                 path=('john', 'doe'))
        self.assertEqual(resource.get_absolute_url(),
                         'http://myserver:8000//john/doe')


class TestPublisher(unittest.TestCase):

    @property
    def publisher(self):
        from wheeljack.publisher import Publisher
        return Publisher

    def test_init(self):
        # The init requires one argument; the root object.
        self.assertRaises(TypeError, self.publisher)

    def test_publish_root(self):
        # When no path is given the root will be published.
        called = []
        class Root(object):
            def __init__(self, environ):
                pass
            def __call__(self, start_response):
                called.append(True)
        publisher = self.publisher(Root)
        publisher({}, None)
        self.assert_(called)

    def test_404(self):
        # When no object can be found a 404 is returned.
        responses = []
        def start_response(*args):
            responses.append(args)

        class Root(object):
            def __init__(self, environ):
                pass
            def traverse(self, path):
                pass
        publisher = self.publisher(Root)
        publisher({'PATH_INFO': '/johnny/debris'}, start_response)
        self.assertEqual(
            responses,
            [('404 NOT FOUND', [('content-type', 'text/plain')])])

    def test_object_traversal(self):
        # Objects are traversed as long as there are elements on the
        # path. Traversal may remove multiple elements from the path in one go.
        class Resource(object):
            def __init__(self, environ, path=None):
                self.path = path
            def traverse(self, path):
                a, b = path.pop(0), path.pop(0)
                return Resource(None, (b,))
            def __call__(self, start_response):
                return self.path
        publisher = self.publisher(Resource)
        self.assertEqual(
            publisher({'PATH_INFO': '/johnny/debris/tweedle/dee'}, None),
            ('dee',))

class TestWSGIResource(unittest.TestCase):

    def test_delegate_rendering(self):
        # The WSGI resource delegates the rendering to the given WSGI app.
        from wheeljack.publisher import WSGIResource
        output = []
        def fake_app(environ, start_response):
            output.append((environ, start_response))
        resource = WSGIResource('fake-environ', (), None, fake_app)
        resource('fake-start-response')
        self.assertEqual(output, [('fake-environ', 'fake-start-response')])

    def test_traversal(self):
        # Traversal should return a WSGI resource which has it's environ
        # tweaked.
        from wheeljack.publisher import WSGIResource
        resource = WSGIResource({}, (), None, None)
        new = resource.traverse(['some', 'path'])
        self.assertEqual(new.environ, {'PATH_INFO': 'some/path'})

def test_suite():
    return unittest.TestSuite([
            unittest.makeSuite(TestResource),
            unittest.makeSuite(TestPublisher),
            unittest.makeSuite(TestWSGIResource),
            ])
