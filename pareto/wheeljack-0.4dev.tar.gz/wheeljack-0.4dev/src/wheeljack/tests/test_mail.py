import unittest

import mock

class TestSendMail(unittest.TestCase):

    @mock.patch('smtplib.SMTP')
    def test_multiple_recipients(self, SMTP):
        # The server will get multiple requests to send a message when more
        # than one recipient is given.
        from wheeljack.mail import sendmail
        sendmail(['optimus@cybertron', 'megatron@cybertron'],
                 'My universe',
                 'I will rule the universe, even if I am the'
                 ' only one left in the universe.\n'
                 '--\nStarscream')
        self.assertEqual(len(SMTP().sendmail.call_args_list), 2)

    @mock.patch('smtplib.SMTP')
    def test_format_mail(self, SMTP):
        # The message is pre-pended with mail headers.
        from wheeljack.mail import sendmail
        sendmail(['optimus@cybertron'], 'My universe',
                 'I will rule the universe, even if I am the'
                 ' only one left in the universe.\n'
                 '--\nStarscream')
        SMTP().sendmail.assert_called_with(
            'wheeljack@cybertron.space', 'optimus@cybertron',
            'To: optimus@cybertron\nFrom: wheeljack@cybertron.space\n'
            'Subject: My universe\n\nI will rule the universe, even if I'
            ' am the only one left in the universe.\n--\nStarscream')

    @mock.patch('smtplib.SMTP')
    def test_connect_to_settings(self, SMTP):
        # The connection being used is based on the one from the settings file.
        from wheeljack.mail import sendmail
        from wheeljack import settings
        old = settings.smtp_server
        settings.smtp_server = 'does-not-exist'
        sendmail([], '', '')
        SMTP.assert_called_with('does-not-exist')
        settings.smtp_server = old


def test_suite():
    return unittest.makeSuite(TestSendMail)
