import unittest
import os

from wheeljack import settings
from wheeljack import scripts

class TestOptionValues(unittest.TestCase):
    """test scripts.parse_cfg()    
    
    """
    keys = ('configroot', 'builder', 'passwd', 'secret',
            'default_from', 'smtp_server', 'host', 'port', 'builddir')

    def test_dummy_config(self):
        # Keep the old settings to restore them later.
        old_settings = [(key, getattr(settings, key))
                             for key in self.keys]
        # Load every setting from an example configuration file.
        try:
            scripts.parse_cfg(os.path.join(os.path.dirname(__file__),
                                           'config', 'dummy.cfg'))

            # Make sure everything is setup right
            self.assertEqual(settings.configroot,
                             '/some/path/tests/fake-root')
            self.assertEqual(settings.builder,
                             '/some/path/wheeljack')
            self.assertEqual(settings.passwd, 'passwd')
            self.assertEqual(settings.secret,
                             r'M6+0A\FhQfr=FbwkQL_\\aBPDPJS')
            self.assertEqual(settings.default_from ,
                             'wheeljack@cybertron.space' )
            self.assertEqual(settings.smtp_server, 'smtp.cybertron')
            self.assertEqual(settings.host, 'cybertron.space')
            self.assertEqual(settings.port, '9090')
        finally:
            # Restore the old values
            for key, value in old_settings:
                setattr(settings, key, value)

def test_suite():
    return unittest.TestSuite([
            unittest.makeSuite(TestOptionValues)
        ])
