function wheeljack() {};

// Periodically update the displayed information using a async
// request.
wheeljack.updateBuildLog = function() {
    $("link").each(function(i, link) {
        if(link.rel == "buildlog") {
            var output = $("#logtext");
            var currentText = output.text();
            var currentLine = currentText.split('\n').length;
            $.getJSON(link.href, {"line": currentLine}, function (data) {
                if (data["newText"]) {
                    output.text(currentText + "\n" + data["newText"]);
                }
                var state = $("#build-state");
                state.text(data["state"]);
                state.attr("class", data["state"].toLowerCase());
                $("#build-time").text(data["buildtime"]);
                if(data["state"] == "success" || data["state"] == "failure") {
                    clearInterval(wheeljack.updateInterval);
                }
            });
        }
    });
}

wheeljack.updateInterval = setInterval(wheeljack.updateBuildLog, 1000);