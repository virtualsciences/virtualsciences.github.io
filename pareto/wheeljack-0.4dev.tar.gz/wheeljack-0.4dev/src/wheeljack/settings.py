import os
import tempfile

_root = os.path.dirname(os.path.abspath(__file__))
configroot = os.path.join(_root, 'tests', 'fake-root')
mediaroot = os.path.join(_root, 'media')
builder = os.path.join(os.path.dirname(os.path.dirname(_root)),
                       'bin', 'wheeljack')
builddir = tempfile.gettempdir() 
passwd = os.path.join(configroot, 'passwd')
secret = 'M6+0A\FhQfr=FbwkQL_\\aBPDPJS'
# Mail settings
default_from = "wheeljack@cybertron.space"
smtp_server = 'smtp.cybertron'
# Server settings
host = '0.0.0.0'
port = 8080
