from __future__ import with_statement
with_statement # Code checker

import os
from glob import glob
from datetime import datetime
import subprocess
import select
import signal

import dateutil.parser

from wheeljack import settings
from wheeljack.errors import BuildError
from wheeljack.errors import RepositoryError
from wheeljack.repositories import open_repository

build_timeout = 1800 # The timeout for when a process can be considered to hang
timeout_message = '''
Build terminated by Wheeljack, reason: TIMEOUT EXCEEDED. 

The build took more than %s seconds without printing to stdout or
stderr. Wheeljack assumes this means that process is stuck and terminates it.

Process output:
===============
''' % build_timeout

command_error_message = '''
Build terminated abnormally. The build command failed:

%s
'''

repository_error_message = '''
Error trying to interact with the source repository. Please make sure the
setting is correct. Error output:

%s
'''

class Log(object):

    def __init__(self, project, id):
        self.project = project
        self.id = id

    @staticmethod
    def logroot():
        """Return the root configuration directory."""
        return os.path.join(settings.configroot, 'logs')

    @property
    def path(self):
        """Return the path the log file."""
        return os.path.join(self.logroot(), self.project.id,
                            self.id + '.log')

    @property
    def text(self):
        try:
            return self._text
        except AttributeError:
            self._text = '\n'.join(self.lines())
            return self._text

    def lines(self):
        """Return a list of lines from the log file."""
        try:
            return self._lines
        except AttributeError:
            self._lines = [l.strip() for l in open(self.path).readlines()]
            return self._lines

    def start(self):
        """Return the creation time of this log."""
        lines = self.lines()
        return dateutil.parser.parse(lines[0][1:20])

    def end(self):
        """Return the last modified time of this log."""
        lines = self.lines()
        if len(lines) > 1:
            return dateutil.parser.parse(lines[-2][1:20])
        return datetime.now()

    def duration(self):
        """Return the duration of the build."""
        return self.end() - self.start()

    def state(self):
        """Return the state of the build."""
        lastline = self.lines()[-1]
        state = lastline.split('Build state: ')[-1].strip().lower()
        if state in ('success', 'failure'):
            return state
        return 'building'

    def revision(self):
        """Return the revision that was used for this build."""
        try:
            firstline = self.lines()[0]
        except IndexError:
            return None
        return firstline.split('Building revision: ')[-1].strip()

class Project(object):
    """Project's contain information on what to build."""

    def __init__(self, id=None, name=None, build_cmd=None,
                 repository=None, vcs=None, watch_list=()):
        self.id = id
        self.name = name
        self.build_cmd = build_cmd
        self.repository = repository
        self.vcs = vcs
        self.watch_list = watch_list
        self.require_build = False

    @property
    def path(self):
        if self.id is not None:
            return os.path.join(self.configroot(), self.id + '.cfg')
    # Create a text friendly version of the watch list for use with HTML forms
    # etc.
    def _get_watch_list_str(self):
        return '\n'.join(self.watch_list)
    def _set_watch_list_str(self, value):
        self.watch_list = value.strip().splitlines()
    watch_list_str = property(_get_watch_list_str, _set_watch_list_str)

    @classmethod
    def load(cls, id):
        """Load an object."""
        path = os.path.join(cls.configroot(), id + '.cfg')
        if not os.path.exists(path):
            raise KeyError, 'No object with id: %s' % id

        project = Project(id)
        for line in open(path):
            attr, value = [s.strip() for s in line.split('=')]
            if attr == 'watch_list':
                value = value.split(',')
            setattr(project, attr, value)
        return project

    def save(self):
        """Save this project to disk."""
        if not os.path.exists(self.configroot()):
            os.mkdir(self.configroot())
        f = open(self.path, 'w')

        for attr in ('name', 'build_cmd', 'repository', 'vcs', 'watch_list'):
            value = getattr(self, attr)
            if attr == 'watch_list':
                value = ','.join(value)
            f.write('%s=%s\n' % (attr, value))
        f.close()

    def delete(self):
        """Permanently remove a project."""
        assert self.path is not None
        os.remove(self.path)

    @staticmethod
    def configroot():
        """Return the root configuration directory."""
        return os.path.join(settings.configroot, 'projects')

    @classmethod
    def objects(cls):
        """Return all available projects."""
        projects = []
        for filename in glob(os.path.join(cls.configroot(), '*.cfg')):
            id = os.path.splitext(os.path.basename(filename))[0]
            projects.append(cls.load(os.path.basename(id)))
        return projects

    def logdir(self):
        return os.path.join(settings.configroot, 'logs', self.id)

    def logids(self):
        """Return the ids for the logs that have been created."""
        extension = len('.log')
        if os.path.exists(self.logdir()):
            return sorted(
                [int(f[:-extension]) for f in os.listdir(self.logdir())])
        return []

    def state(self):
        """Return the project's state.

        This is based on the last build that has taken place.
        """
        log = self.getlog()
        if log is None:
            return ''
        return log.state()

    def getlog(self, logid=None):
        """Return the most recent log object."""
        if logid is None:
            ids = self.logids()
            if ids:
                return Log(self, str(ids[-1]))
        else:
            return Log(self, logid)

    def last_revision(self):
        log = self.getlog()
        if log is not None:
            return log.revision()

    def revision(self):
        """Return the current revision of this project."""
        try:
            return open_repository(self.repository, self.vcs).revision()
        except RepositoryError, e:
            raise BuildError(
                self.build_cmd, 'checkout-problem',
                datetime.now(), repository_error_message % str(e.msg))

    def is_updated(self):
        """Check if the project has been updated since the last build."""
        return self.last_revision() != self.revision()

    def build(self, buildlog):
        """Build the project.

        This returns the output from the execution as a string in case of
        success. Problems with the build are raised as a `BuildError`.
        """
        start = datetime.now()
        export = open_repository(self.repository, self.vcs)

        buildlog.info('Building revision: %s' % self.revision())

        with export as build_dir:
            try:
                process = subprocess.Popen(self.build_cmd.split(' '),
                                           cwd=build_dir,
                                           stdout=subprocess.PIPE,
                                           stderr=subprocess.STDOUT)
            except OSError, e:
                buildlog.error(command_error_message % e.strerror)
                buildlog.error('Build state: ERROR')
                raise BuildError(self.build_cmd, self.revision(), start,
                                 command_error_message % e.strerror)
            # Build the project in a way that it won't hang the builder in case
            # of problems.
            output = []
            while process.poll() is None:
                r, w, x = select.select([process.stdout], [], [],
                                        build_timeout)
                if len(r) == 0: # The timeout was triggered
                    os.kill(process.pid, signal.SIGKILL)
                    raise BuildError(self.build_cmd, self.revision(), start,
                                     timeout_message + ''.join(output))
                else:
                    char = r[0].read(1)
                    if char == '\n':
                        buildlog.info(''.join(output))
                        output = []
                    else:
                        output.append(char)
            for line in process.stdout.read().rstrip().split('\n'):
                buildlog.info(line)
            if process.returncode == 0:
                buildlog.info('Build state: SUCCESS')
                return True
            buildlog.info('Build state: FAILURE')
            return False
