from wsgiref.util import application_uri

class Resource(object):

    def __init__(self, environ, path=(), parent=None):
        """Initialize a new resource.

        Path should be an iterable.
        """
        self.environ = environ
        # Convert to a tuple to avoid accidental mutation of the path list.
        self.path = tuple(path)
        self.parent = parent

    def __call__(self, start_response):
        """Render this resource."""
        raise NotImplementedError

    def get_absolute_url(self):
        """Return the absolute URL for this resource.

        The URL is constructed using the URL the parent is at. This is where it
        becomes important that the path for the current object (or that of its
        parent) is an iterable and not a single key.
        """
        if self.parent is None:
            parent_url = application_uri(self.environ)
        else:
            parent_url = self.parent.get_absolute_url().rstrip('/')
        return '/'.join((parent_url,) + self.path)

    def traverse(self, path):
        """Return the resource located at path.

        This method should return None When no resource is available for
        path. Making traverse a required method avoids capturing
        `AttributeError` exceptions that could occur within a traverse method.

        Each element from the path that is used should be removed from the path
        list. The publisher will continue to traverse until either a traversal
        results in None or the path list is empty.
        """

    @classmethod
    def child(cls, parent, path, *args, **kwargs):
        """Create a new resource from the values in its parent."""
        return cls(parent.environ, path, parent, *args, **kwargs)


class Publisher(object):

    def __init__(self, root):
        self.root = root

    def __call__(self, environ, start_response):
        # Create the path list without any empty values
        path = [p for p in environ.get('PATH_INFO', '').split('/') if p]
        obj = self.root(environ)
        while path:
            obj = obj.traverse(path)
            if obj is None:
                start_response('404 NOT FOUND',
                               [('content-type', 'text/plain')])
                return ['Not found']
        return obj(start_response)


# New woppie stuff
class WSGIResource(Resource):
    """A WSGIResource wraps a WSGI app to make it work with the publisher."""

    def __init__(self, environ, path, parent, app):
        super(WSGIResource, self).__init__(environ, path, parent)
        self.app = app

    def __call__(self, start_response):
        return self.app(self.environ, start_response)

    def traverse(self, path):
        """Traverse to the same app but fix up the environment.
        
        This will return a new WSGIResource that has it's environment changed
        so that it any WSGI app will think it is located on that root.
        """
        environ = self.environ.copy()
        environ['PATH_INFO'] = '/'.join(path)
        path[:] = []
        return WSGIResource(environ, self.path, self.parent, self.app)
