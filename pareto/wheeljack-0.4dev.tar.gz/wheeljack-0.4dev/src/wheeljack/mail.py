import smtplib
from string import Template

from wheeljack import settings

mail_template = Template('To: $recipient\n'
                         'From: $sender\n'
                         'Subject: $subject\n\n'
                         '$message')

def sendmail(to_addrs, subject, msg):
    """Send a message using the default connection.

    The message must be text without mail headers. Headers will be added when
    the message is send.
    """
    server = smtplib.SMTP(settings.smtp_server)
    for recipient in to_addrs:
        mail = mail_template.substitute(sender=settings.default_from,
                                        recipient=recipient,
                                        subject=subject,
                                        message=msg)
        server.sendmail(settings.default_from, recipient, mail)
    server.quit()
