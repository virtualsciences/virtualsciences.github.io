import os
import logging
from datetime import datetime

from wheeljack.errors import BuildError
from wheeljack import models
from wheeljack import settings
from wheeljack.mail import sendmail

log = logging.getLogger('Wheeljack')

error_message = ('There was a problem building: %(project)s.\n\n'
                 '%(log)s')

failure_message = ('The build did not complete successfully for project: '
                   '%(project)s.\n\n'
                   '%(log)s')

class BuildLogger(object):
    """A simple logger which can be used for build logs.
    
    It's main feature is that it always flushes each message to disk. This
    makes it easier to track progress of a build by reading the log file."""

    def __init__(self, path):
        self.path = path

    def info(self, message):
        prefix = datetime.now().strftime('[%Y-%m-%d %H:%M:%S]')
        f = open(self.path, 'a')
        f.write('%s %s\n' % (prefix, message))
        f.close()

    def error(self, message):
        self.info(message)


class Builder(object):

    def build_all(self):
        for project in models.Project.objects():
            self.build(project)

    def getlog(self, project):
        log_folder = os.path.join(settings.configroot, 'logs', project.id)
        if not os.path.exists(log_folder):
            os.makedirs(log_folder)

        # Get the latest build number based on the existing log files. Make
        # sure to always have at least the number zero for when no build has
        # been done yet.
        buildnr = max(project.logids() + [0]) + 1

        return BuildLogger(os.path.join(log_folder, '%s.log' % buildnr))

    def build(self, project):
        """Build the project and submit the build report."""
        buildlog = self.getlog(project)
        try:
            if not (project.is_updated() or project.require_build):
                log.info('Project is up-to-date, skipping build')
                return
            success = project.build(buildlog)
            if not success:
                message =  failure_message % {'log': project.getlog().text,
                                              'project': project.name}
                sendmail(project.watch_list,
                         'Build failure: %s' % project.name, message)
            return success
        except BuildError, e:
            message =  error_message % {'log': project.getlog().text,
                                        'project': project.name}
            sendmail(project.watch_list, 'Build error: %s' % project.name,
                     message)
            return False
