from optparse import OptionParser
import sys
import os
import logging
import logging.handlers
import time
import ConfigParser

from wheeljack.builder import Builder
from wheeljack import settings

log = logging.getLogger('Wheeljack')
sth = logging.StreamHandler()
sth.setFormatter(logging.Formatter(
        "[%(asctime)s] - %(message)s", "%x %X"))
log.addHandler(sth)
log.setLevel(logging.DEBUG)

def exit_with_error(*messages):
    print ' '.join(messages)
    sys.exit(1)

def show_help(parser):
    parser.print_help()
    sys.exit(1)

def parse_cfg(cfg_path):
    cfg_parser = ConfigParser.ConfigParser()
    cfg_parser.read(cfg_path)
    for section, key, target in [('locations', 'configuration', 'configroot'),
                                 ('builder', 'builder', 'builder'),
                                 ('builder', 'passwd', 'passwd'),
                                 ('builder', 'secret', 'secret'),
                                 ('builder', 'builddir', 'builddir'),
                                 ('mail', 'from', 'default_from'),
                                 ('mail', 'smtp-server', 'smtp_server'),
                                 ('server', 'host', 'host'),
                                 ('server', 'port', 'port')]:
        setattr(settings, target, cfg_parser.get(section, key))

def loadconfig(path):
    if not os.path.exists(path):
        return exit_with_error(
            'Configuration file for Wheeljack does not exist: %s' % path)
    try:
        parse_cfg(path)
    except ConfigParser.Error, e:
        exit_with_error('Error reading configuration.', e.message)
    settings.configfile = path

def build_project(command):
    """This builds a single project based on command line arguments."""
    parser = OptionParser(
        usage=('usage: %prog ' + command + ' project\n'
               'PROJECT is the id of the project'))
    parser.add_option(
        '-f', '--force', dest='force', metavar='MINUTES',
        default=False, action='store_true',
        help='Sleep the specified amount of time in between build runs.')
    parser.add_option('-c', '--configuration', dest='conf',
                      default='/etc/wheeljack.cfg')
    options, args = parser.parse_args()

    if len(args) != 1:
        show_help(parser)

    loadconfig(options.conf)
    builder = Builder()
    log.info('Starting build')
    print settings.configroot
    from wheeljack import models
    try:
        project = models.Project.load(args[0])
    except KeyError:
        print 'Project: %s does not exists.' % args[0]
        sys.exit(1)
    if options.force:
        project.require_build = True
    if not builder.build(project):
        # Let the process calling us know we failed.
        log.error('Project failed to build')
        sys.exit(1)

def buildall(command):
    parser = OptionParser(
        usage='usage: %prog ' + command +' [options] path')
    parser.add_option(
        "-s", "--sleep", dest="sleep", metavar='MINUTES',
        default=1, type="int",
        help=("Sleep the specified amount of time in between build runs. "
              "Use this in combination with --loop."))
    parser.add_option(
        '-l', '--loop', dest='loop',
        default=False, action='store_true',
        help='Keep running in loops.')
    parser.add_option('-c', '--configuration', dest='conf',
                      default='/etc/wheeljack.cfg')
    options, args = parser.parse_args()
    loadconfig(options.conf)

    log.info('Starting builds')

    builder = Builder()
    if options.loop:
        while True:
            builder.build_all()
            time.sleep(options.sleep * 60) # Let the system relax for a bit
    else:
        builder.build_all()

def server(command):
    parser = OptionParser(
        usage='usage: %prog ' + command +' [options]')
    parser.add_option(
        "-p", "--port", dest="port", metavar='PORT',
        default=8080, type="int",
        help="The port number on which the server will run.")
    parser.add_option('-c', '--configuration', dest='conf',
                      default='/etc/wheeljack.cfg')
    options, args = parser.parse_args()
    loadconfig(options.conf)
    log.info('Starting server')
    from wheeljack.wsgi import app
    from paste.httpserver import serve
    serve(app, server_version="Wheeljack",
          protocol_version="HTTP/1.1", port=settings.port,
          host=settings.host)


commands = {
    'build': build_project,
    'build-all': buildall,
    'server': server,
}

def main():
    from bzrlib.plugin import load_plugins
    load_plugins()
    #server('')
    script = sys.argv[0]
    if len(sys.argv) < 2:
        print 'Usage %s subcommand [options] [args]:' % script
        print ''
        print "Type '%s subcommand --help' for help on a specific subcommand" % script
        print 'Available subcommands:'
        for command in sorted(commands):
            print '  ', command
        sys.exit(1)
    command = sys.argv.pop(1)
    try:
        handler = commands[command]
    except KeyError:
        print "Unknown command: '%s'" % command
        print "Type '%s' for usage" % script
        sys.exit(1)
    handler(command)

if __name__ == '__main__':
    main()
