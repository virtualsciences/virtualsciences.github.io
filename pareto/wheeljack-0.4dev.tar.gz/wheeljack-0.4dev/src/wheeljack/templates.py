import os

from templess import templess
from templess.convert import (convertor, util, elnode, cdatanode,
                              commentnode, textnode)
from pkg_resources import DefaultProvider, get_provider, ResourceManager

class PackageLoader(object):

    def __init__(self, package_name, package_path='templates',
                 autoreload=False):
        self.provider = get_provider(package_name)
        self.filesystem_bound = isinstance(self.provider, DefaultProvider)
        self.package_path = package_path
        self._cache = {}
        self.autoreload = autoreload
        self.manager = ResourceManager()

    def get_path(self, template):
        return self.package_path + '/' + template

    def get_filename(self, path=None, template=None):
        if template is not None:
            assert path is None, ('Either path or template must be set, '
                                  'not both.')
            path = self.get_path(template)
        if not self.provider.has_resource(path):
            raise KeyError, 'Template not found: %s' % path
        return self.provider.get_resource_filename(self.manager, path)

    def _load(self, template):
        path = self.get_path(template)
        filename = self.get_filename(path=path)
        source = self.provider.get_resource_string(self.manager, path)

        tmpl = templess.template(source)
        self._cache[template] = (tmpl, os.path.getmtime(filename))
        return tmpl


    def get(self, template):
        try:
            tmpl = self._cache[template][0]
        except KeyError:
            # The template has not yet been loaded
            return self._load(template)
        else:
            # Return the template directly if auto reloading is disabled
            if not self.autoreload:
                return tmpl
            # Otherwise make check to see if there are any updates
            filename = self.get_filename(template=template)
            mtime = os.path.getmtime(filename)
            if mtime != self._cache[template][1]:
                return self._load(template)
            return tmpl


class TemplateContext(dict):

    def __init__(self, *dicts):
        super(TemplateContext, self).__init__()
        for d in dicts:
            self.update(d)

    def update(self, dct):
        super(TemplateContext, self).update(dct)
        return self

    def update_with(self, obj, *attrs):
        for attr in attrs:
            value = getattr(obj, attr)
            if callable(value):
                value = value()
            self[attr] = value
        return self

    @classmethod
    def with_attrs(cls, context, *attrs):
        return cls().update_with(context, *attrs)

class ConversionError(Exception):
    """Specific error for conversion problems."""

class html4serializer(convertor):
    voidtags = frozenset(['base', 'link', 'meta', 'hr', 'br', 'img', 'embed',
                          'param', 'area', 'col','input'])
    requiredendtags = frozenset(['script'])

    def unicode(self):
        """Convert the contained node to a HTML4 unicode string.

        This does _not_ implicitly call convert.
        """
        return self._unicode(self.node)

    def _unicode(self, node):
        if isinstance(node, elnode):
            return self._unicode_element(node)
        elif isinstance(node, cdatanode):
            raise ConversionError('CDATA nodes are not support by HTML: %s' %
                                  node.text)
        elif isinstance(node, commentnode):
            return u'<!--%s-->' % (node.text,)
        elif isinstance(node, textnode):
            return node.text

    def _start_node_start(self, node, attrs):
        return u'<%s%s>'% (node.name, self._serialize_attrs(node, attrs))

    def _end_node(self, node):
        return u'</'  + node.name + '>'

    def _serialize_attrs(self, node, attrs):
        """ return the attributes as a string
        """
        if not len(attrs):
            return ''
        items = sorted(attrs.items())
        return ' ' + ' '.join(
            [k + '="' + util.strconvert(v, node.charset) + '"'
             for (k, v) in items])

    def _unicode_element(self, node):
        """ return a string (XML) representation of ourselves (unrendered!)
        """
        ret = [self._start_node_start(node, node.attrs)]
        nodename = node.name.lower()
        if len(node) and nodename in self.voidtags:
            raise ConversionError(
                "Nodes of type: %s may not contain content." % node.name)
        elif not len(node) and nodename in self.requiredendtags:
            ret.append(self._end_node(node))
        elif len(node):
            for child in node:
                ret.append(self._unicode(child))
            ret.append(self._end_node(node))
        return ''.join(ret)

def render_to_response(start_response, template, context):
    t = template_loader.get(template)
    s = html4serializer(t)
    s.convert(context)
    # Execute the conversion to HTML before running start_response. This makes
    # sure any errors show up properly (which they can't after start_response
    # has been called).
    data = s.unicode()
    start_response('200 OK', [('content-type', 'text/html')])
    doctype = ('<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" '
               '"http://www.w3.org/TR/html4/strict.dtd">\n')
    return ''.join((doctype, data.encode('utf8')))


template_loader = PackageLoader('wheeljack', 'templates', autoreload=True)
