from weberror import errormiddleware
from repoze.who.middleware import PluggableAuthenticationMiddleware
from repoze.who.interfaces import IIdentifier
from repoze.who.interfaces import IChallenger
from repoze.who.plugins.auth_tkt import AuthTktCookiePlugin
from repoze.who.plugins.form import FormPlugin
from repoze.who.plugins.htpasswd import HTPasswdPlugin
from repoze.who.plugins.htpasswd import crypt_check
from repoze.who.classifiers import default_request_classifier
from repoze.who.classifiers import default_challenge_decider

from wheeljack.publisher import Publisher
from wheeljack.views import Root
from wheeljack.templates import template_loader
from wheeljack import settings

clean_app = Publisher(Root)

# Authentication setup
def render_login_form(environ):
    tmpl = template_loader.get('login.html')
    c = {'access-denied': environ['REQUEST_METHOD'] == 'POST'}
    return tmpl.unicode(c, html=True).encode('utf8')

htpasswd = HTPasswdPlugin(settings.passwd, crypt_check)
auth_tkt = AuthTktCookiePlugin(settings.secret, 'auth_tkt')
form = FormPlugin('__do_login', rememberer_name='auth_tkt',
                  formcallable=render_login_form)
form.classifications = {IIdentifier: ['browser'],
                        IChallenger: ['browser']} # only for browser
identifiers = [('form', form),('auth_tkt',auth_tkt)]
authenticators = [('htpasswd', htpasswd)]
challengers = [('form',form)]
mdproviders = []

app = PluggableAuthenticationMiddleware(
    clean_app, identifiers, authenticators, challengers, mdproviders,
    default_request_classifier, default_challenge_decider)

app = errormiddleware.ErrorMiddleware(app)
