from repoze import formapi

from wheeljack.templates import template_loader

class TemplessForm(formapi.Form):

    option_fields = {}

    def template_context(self):
        c = {'form-class': 'errorlist' if self.errors else 'normal',
             'errors': self.errors}
        for key in self.fields.iterkeys():
            if key in self.option_fields:
                c[key] = [
                    {'text': o[1], 'value': o[0],
                     'selected': 'selected' if o[0]==self.data[key] else None}
                    for o in self.option_fields[key]]
            else:
                c[key] = self.data[key]
        return c

    def render(self, template):
        """Render the form to a tree structure for use with the template."""
        tree = template_loader.get(template).render(self.template_context())
        return list(tree.find('form'))[0]

    def save(self):
        # This writes the data from the form to the context object.
        self.data.save()
        # The data can now be committed to disk.
        self.context.save()

class ProjectForm(TemplessForm):
    fields = {
        'name': unicode,
        'build_cmd': str,
        'repository': str,
        'vcs': str,
        'watch_list_str': str,
        }

    option_fields = {'vcs': (('bzr', 'Bazaar'), ('svn', 'Subversion'))}

    @formapi.validator('name')
    def validate_name(self):
        if not self.data['name']:
            yield 'Name is required'

