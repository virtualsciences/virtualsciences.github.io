"""This is an integration doctest test. It uses PloneTestCase and doctest
syntax.
"""

import unittest
import doctest
from Testing import ZopeTestCase as ztc
from five.intid.site import add_intids
from Products.Five import zcml, fiveconfigure
from plone.app.relations.utils import add_relations
from zope.component import queryUtility
from plone.relations.interfaces import IComplexRelationshipContainer
from zope.app.intid.interfaces import IIntIds

from pareto.relations.tests import base

def setUp(app):
    from pareto import relations
    fiveconfigure.debug_mode = True
    zcml.load_config('configure.zcml', relations)
    fiveconfigure.debug_mode = False

    util = queryUtility(IIntIds, context=app)
    if util is None:
        add_intids(app)
    util = queryUtility(IComplexRelationshipContainer,
                      name='relations', context=app)
    if util is None:
        add_relations(app)

def test_suite():
    """This sets up a test suite that actually runs the tests in the class
    above
    """
    return unittest.TestSuite([

        # Here, we create a test suite passing the name of a file relative 
        # to the package home, the name of the package, and the test base 
        # class to use. Here, the base class is a full PloneTestCase, which
        # means that we get a full Plone site set up.

        ztc.ZopeDocFileSuite(
            'tests/relations.txt', package='pareto.relations',
            test_class=base.RelationsFunctionalTestCase,
            optionflags=doctest.REPORT_ONLY_FIRST_FAILURE | 
                        doctest.NORMALIZE_WHITESPACE | doctest.ELLIPSIS),

        ])

