import unittest
import doctest
from zope.interface import implements
from zope.app.testing import placelesssetup
from Testing import ZopeTestCase as ztc
# from Products.PloneTestCase import PloneTestCase as ptc
from OFS.SimpleItem import SimpleItem

from five.intid.lsm import USE_LSM
from five.intid.site import add_intids
from plone.app.relations.utils import add_relations

from Products.Five import zcml, fiveconfigure
from Products.ATContentTypes.interface.interfaces import IATContentType

class Demo(SimpleItem):
    # Add marker interface
    implements(IATContentType)

    def __init__(self, id):
        self.id = id
    def __repr__(self):
        return '<%s %s>' % (self.__class__.__name__, self.id)

def contentSetUp(app):
    for i in range(30):
        oid = 'ob%d' % i
        app._setObject(oid, Demo(oid))

def base_setup(app):
    """Setup without basic CA stuff because PTC already provides this"""
    import pareto.relations
    # XXX The try/except is dangerous, it also catches regular
    # zcml errors that are not triggered when instance is started normally!
    try:
        fiveconfigure.debug_mode = True
        zcml.load_config('configure.zcml', pareto.relations)
        fiveconfigure.debug_mode = False
    except:
        # XXX: When ptc has setup plone, then the zcml product
        # registration causes errors when run twice :-(
        pass
    if not USE_LSM:
        # monkey in our hooks
        from Products.Five.site.metaconfigure import classSiteHook
        from Products.Five.site.localsite import FiveSite
        from zope.interface import classImplements
        from zope.app.component.interfaces import IPossibleSite
        klass = app.__class__
        classSiteHook(klass, FiveSite)
        classImplements(klass, IPossibleSite)
    add_intids(app)
    add_relations(app)
    contentSetUp(app)

def setUp(app):
    """A setup that includes the basic CA setup"""
    placelesssetup.setUp()
    from Products import Five, GenericSetup
    import plone.app.portlets
    zcml.load_config('meta.zcml', Five)
    zcml.load_config('permissions.zcml', Five)
    zcml.load_config('configure.zcml', Five)
    zcml.load_config('meta.zcml', plone.app.portlets)
    zcml.load_config('meta.zcml', GenericSetup)
    base_setup(app)


def test_suite():
    readme = ztc.FunctionalDocFileSuite('tests/README.txt',
                        optionflags=doctest.REPORT_ONLY_FIRST_FAILURE | 
                                    doctest.NORMALIZE_WHITESPACE | doctest.ELLIPSIS,
                                        package='pareto.relations')
    return unittest.TestSuite([readme])

if __name__ == '__main__':
    unittest.main(defaultTest='test_suite')
