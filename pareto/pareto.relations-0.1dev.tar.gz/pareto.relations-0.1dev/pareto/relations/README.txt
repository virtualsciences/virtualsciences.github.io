================
pareto.relations
================

A package to make relations between plone content items. It is supposed to replace the use of references in Plone.
The relations are orderable. The order of the targets is stored as a list of intids on the source object (as a zope3
style annotations).

There is an event handlers to remove the relation intid from the orderings when a target is deleted.

The five.intid package is used. To install intids and a relations container, there is a view on plone.app.relations.

Use it as follows:

http://host/plone_site/@@install-relations.html

There is also a view to register plone objects with the intid machinery as part of plone.relations, use it as follows:

http://host/plone_site/@@register-intids.html
