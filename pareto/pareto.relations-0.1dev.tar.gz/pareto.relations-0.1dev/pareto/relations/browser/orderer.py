from AccessControl import Unauthorized # , getSecurityManager
from Products.CMFCore.utils import getToolByName
from Products.Five import BrowserView
from zope.interface import implements
from pareto.relations.interfaces import IRelationsView
from zope.app.annotation.interfaces import IAttributeAnnotatable
from plone.app.relations import interfaces
from plone.memoize.instance import memoize
from pareto.relations import interfaces as pareto_interfaces
from zope.app.intid.interfaces import IIntIds
from zope.component import getUtility
from Products.Five.browser.pagetemplatefile import ViewPageTemplateFile

class OrdererView(BrowserView):
    implements(IRelationsView) 

    template = ViewPageTemplateFile('manage_relations.pt')

    def __init__(self, context, request):
        self.source = interfaces.IRelationshipSource(context)
        self.orderer = pareto_interfaces.IOrderedRelationship(context)
        self.intids_util = getUtility(IIntIds)
        super(OrdererView, self).__init__(context, request)

    def __call__(self):

        form = self.request.form
        submitted = form.get('form.submitted', None)
        portal = getToolByName(self.context, 'portal_url').getPortalObject()             
        plone_utils = getToolByName(self.context, 'plone_utils')
        path = form.get('path', None)

        if not (submitted or path):
            return self.template()
        
        browse_button = form.get('form.button.Browse', None)

        if browse_button or path:
            if not path:
                path = form.get('path', '/'.join(portal.getPhysicalPath()))
            items =  self._getItemsForPath(path)
            breadcrumb = self._getBreadcrumb(path)
            return self.template(browsing=True, breadcrumb=breadcrumb, items=items)

        add2_button = form.get('form.button.Add2', None)
        if add2_button:
            category = form.get('category')
            paths = form.get('paths', None)
            if paths is None:
                plone_utils.addPortalMessage(u'Er was niets geselecteerd.')
            else:
                for path in paths:
                    obj = portal.restrictedTraverse(path)
                    intid = self.intids_util.getId(obj)
                    self.addRelation(intid, category)
            return self.template()

        delete_button = form.get('form.button.Delete', None)

        # The zope :records approach does seem to break on checkboxes
        # Presumably, because they sometimes can have none values.
        if delete_button:
            for entry in form['entries']:
                category, intid = tuple(entry.split('::'))
                if intid:
                    self.deleteRelation(int(intid), category)
       
        for movement in ('Up', 'Down'):
            button = form.get('form.button.%s' % movement, None)
            if button:
                entries = [e for e in form['entries'] if e.split('::')[1]]
                if not entries:
                    break
                method = getattr(self, 'moveRelation%s' % movement)
                if movement == 'Down':
                    entries.reverse()
                for entry in entries:
                    category, intid = tuple(entry.split('::'))
                    method(int(intid), category)

        return self.template()
    
    @memoize
    def getRelationCategories(self):
        arboreal_tool = getToolByName(self.context, 'portal_arboreal', None)
        if not arboreal_tool:
            return ['Wetgeving', 'Hulpmiddelen', 'Links']
        tree_mgr_id_default = 'relations'
        properties_tool = getToolByName(self.context, 'portal_properties')
        try:
            tree_mgr_id = properties_tool.pareto_relations_properties.getProperty('arboreal_tree_id', 
                    tree_mgr_id_default)
        except AttributeError:
            tree_mgr_id = tree_mgr_id_default
        tree_mgr = arboreal_tool.getTree(tree_mgr_id)
        return [n.Title() for n in tree_mgr.objectValues('ArborealNode')]

    def addRelation(self, intid, category):
        plone_utils = getToolByName(self.context, 'plone_utils')
        obj = self.intids_util.getObject(intid)
        rel = self.source.createRelationship((obj,), relation=category,
                interfaces=(IAttributeAnnotatable,))
        self.orderer.relation_type = category
        self.orderer.add_item(intid)
        plone_utils.addPortalMessage(u'Relatie toegevoegd.')

    def moveRelationUp(self, intid, category):
        plone_utils = getToolByName(self.context, 'plone_utils')
        self.orderer.relation_type = category
        orderable = pareto_interfaces.IOrderable(self.orderer)
        orderable.moveObjUp(intid)
        plone_utils.addPortalMessage(u'Relatie op.')

    def moveRelationDown(self, intid, category):
        plone_utils = getToolByName(self.context, 'plone_utils')
        self.orderer.relation_type = category
        orderable = pareto_interfaces.IOrderable(self.orderer)
        orderable.moveObjDown(intid)
        plone_utils.addPortalMessage(u'Relatie neer.')

    def setOrder(self, ordering, category):
        self.orderer.relation_type = category
        orderable = pareto_interfaces.IOrderable(self.orderer)
        if len(ordering) != len(self.orderer.order):
            raise IndexError('New ordering has incorrect length.')
        orderable.setOrder(ordering)
    
    def deleteRelation(self, intid, category):
        plone_utils = getToolByName(self.context, 'plone_utils')
        obj = self.intids_util.getObject(intid)
        self.source.deleteRelationship(obj, relation=category, multiple=True)
        self.orderer.relation_type = category
        self.orderer.remove_item(intid)
        plone_utils.addPortalMessage(u'Relatie verwijderd.')
        
    def getRelationsFor(self, category):
        self.orderer.relation_type = category
        relations = []
        for intid in self.orderer.order:
            try:
                relations.append(dict(object=self.intids_util.getObject(intid), 
                      intid=intid))
            except Unauthorized:
                pass
        return relations

    def hasRelations(self):
        # Unfortunately, we have to wake up the objects
        # to have the neccesary security check
        relations_info = self.getRelations()
        for relation_info in relations_info:
            if relation_info['relations']:
                return True
        return False
                
        
    def getRelations(self):
        categories = self.getRelationCategories()
        result = []
        for category in categories:
            self.orderer.relation_type = category
            relations = []
            for intid in self.orderer.order:
                try:
                    relations.append(dict(object=self.intids_util.getObject(intid), 
                          intid=intid))
                except Unauthorized:
                    pass
            result.append(dict(category=category, relations=relations))
        return result

    def doit(self):
        from zope.component import queryUtility
        from plone.relations.interfaces import IComplexRelationshipContainer
        from zope.app.intid.interfaces import IIntIds
        util = queryUtility(IIntIds, context=self.context)
        
        util = queryUtility(IComplexRelationshipContainer,
                          name='relations', context=self.context)
        
    def registerOldContent(self):
        portal_catalog = getToolByName(self.context, 'portal_catalog')
        brains = portal_catalog()
        res = ['The following objects have been registered:']
        res.append('-' * len(res[0]))
        for b in brains:
            try:
                object = b.getObject()
                self.intids_util.getId(object)
            except KeyError:
                self.intids_util.register(object)
                res.append(b.getURL())
        return '\n'.join(res)


    def _getBreadcrumb(self, path):
        portal_catalog = getToolByName(self.context, 'portal_catalog')
        portal = getToolByName(self.context, 'portal_url').getPortalObject()             
        brains = list(portal_catalog(path=dict(query=path, navtree=1, depth=0)))
        brains.sort(key=lambda b: b.getPath()) 
        res = [dict(path='/'.join(portal.getPhysicalPath()), title='home')]
        for b in brains:
            res.append(dict(path=b.getPath(), title=b.Title))
        return res

    def _getItemsForPath(self, path):
        # We assume kupu is there
        kupuTool = getToolByName(self, 'kupu_library_tool')
        linkable = list(kupuTool.getPortalTypesForResourceType('linkable'))
        portal_catalog = getToolByName(self.context, 'portal_catalog')
        brains = portal_catalog(portal_type=linkable, path=dict(query=path, depth=1), sort_on='sortable_title')
        folderish_types = list(kupuTool.getPortalTypesForResourceType('collection'))
        # folderish_types = ['Folder', 'Large Plone Folder']
        result = []
        for b in brains:
            result.append(dict(folderish=b.portal_type in folderish_types,
                path=b.getPath(), title=b.Title))
        return result



