Graphic Text
============

Graphic Text renders images which dynamic text. This can be used for
sites that need special fonts that are not installed on clients.