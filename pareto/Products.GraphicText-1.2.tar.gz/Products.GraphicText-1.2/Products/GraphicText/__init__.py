from Products.CMFPlone.utils import ToolInit
from Products.GraphicText.graphictext import GraphicTextTool
from Products.CMFCore import utils, DirectoryView

from Products.GraphicText.config import *

DirectoryView.registerDirectory('skins', GLOBALS)
DirectoryView.registerDirectory('skins/graphictext', GLOBALS)


def initialize(context):
    # initialize tree management tool
    utils.ToolInit(TOOL_NAME,
                   tools=[GraphicTextTool],
                   icon='graphictext.png').initialize( context )
