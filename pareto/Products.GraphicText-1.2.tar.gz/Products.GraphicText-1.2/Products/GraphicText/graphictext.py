from AccessControl import ClassSecurityInfo
from Globals import InitializeClass, INSTANCE_HOME
from Products.BTreeFolder2.BTreeFolder2 import BTreeFolder2
from Products.CMFCore.utils import UniqueObject
from Products.CMFPlone.interfaces.NonStructuralFolder import INonStructuralFolder
from AccessControl import getSecurityManager
from OFS.Image import Image as OFSImage
from Products.PlacelessTranslationService import utranslate
import pkg_resources
from StringIO import StringIO

import os

from PIL import Image
from PIL import ImageDraw
from PIL import ImageColor
from PIL import ImageFont
import sha
import base64

class GraphicTextTool(UniqueObject, BTreeFolder2):
    id = 'portal_graphictext'
    meta_type = 'GraphicText'

    __implements__ = (INonStructuralFolder,)

    security = ClassSecurityInfo()

    def __create_image_hash(self, position, text, backgroundname, color, fontname, fontsize, textalign, backgroundmode):
        """Create an image tag that shows the text as image"""
        imghash = sha.new(text.encode('utf8'))
        imghash.update(backgroundname)
        imghash.update(color)
        imghash.update(fontname)
        imghash.update(str(fontsize))
        imghash.update(str(position))
        imghash.update(textalign)
        imghash.update(backgroundmode)
        return 'img'+base64.urlsafe_b64encode(imghash.digest())

    def _load_skin_image(self, imageobj):
        return Image.open(StringIO(imageobj._readFile(False)))

    def __get_image(self, position, text, backgroundname, color, fontname, fontsize,
                    textalign='left', backgroundmode='fixed', **kwargs):
        try:
            text = unicode(text, 'utf-8')
        except TypeError:
            pass

        imgid = self.__create_image_hash(position, text, backgroundname, color, fontname, fontsize, textalign, backgroundmode)
    
        lines = text.replace('\r', '').split('\n')

        if not self.has_key(imgid):
            background = getattr(self, backgroundname)
            if not getSecurityManager().checkPermission('View', background):
                raise Exception # TODO:must be security exception

            # Initialize the font
            font = None
            for entry_point in pkg_resources.iter_entry_points('graphictext', 'fonts'):
                plugin = entry_point.load()
                for path in plugin():
                    fontpath = os.path.join(path, fontname)
                    try:
                        font = ImageFont.truetype(fontpath, fontsize)
                    except IOError, e:
                        continue
                    else:
                        break
            if not font:
                raise IOError("Problem loading font: %s" % fontname)
                


            # Load and create the background image
            if backgroundmode=='fixed':
                textimage = self._load_skin_image(background)
            elif backgroundmode=='scaled':
                originalimage = self._load_skin_image(background)
                width = 0
                for line in lines:
                    linewidth = font.getsize(line)[0]
                    if linewidth>width:
                        width = linewidth
                margin = position[0]*2
                textimage = originalimage.resize(
                    (width+margin, originalimage.size[1]),
                     Image.ANTIALIAS)
            else:
                raise ValueError("Invalid background mode specified: %s"%backgroundmode)


            drawing = ImageDraw.Draw(textimage)
            
            x, y = position
            for i, line in enumerate(lines):
                if textalign=='right':
                    x = textimage.size[0]-(position[0]+drawing.textsize(line, font=font)[0])
                    
                drawing.text((x, y),
                             line,
                             fill=ImageColor.getrgb(color),
                             font=font)
                fontheight = font.getsize(line)[1]
                y+=fontheight+2
            del drawing

            imagedata = StringIO()
            textimage.save(imagedata, 'PNG')

            imagedata.seek(0)

            self._setOb(imgid, OFSImage(imgid, text, imagedata))
        
        return self.get(imgid)
    
    security.declarePublic('imgtag')
    def imgtag(self, *args, **kwargs):
        image = self.__get_image(*args, **kwargs)
        return image.tag(**kwargs.get('imgattrs', {}))
        
    security.declarePublic('imgurl')
    def imgurl(self, *args, **kwargs):
        image = self.__get_image(*args, **kwargs)
        return image.absolute_url()

    security.declarePublic('translated_imgtag')
    def translated_imgtag(self,  position, domain, text, *args, **kwargs):
        text = utranslate(domain, text, default=text, context=self)
        return self.imgtag(position, text, *args, **kwargs)

    security.declarePublic('translated_imgurl')
    def translated_imgurl(self,  position, domain, text, *args, **kwargs):
        text = utranslate(domain, text, default=text, context=self)
        image = self.imgurl(position, text, *args, **kwargs)
        return image

InitializeClass(GraphicTextTool)
