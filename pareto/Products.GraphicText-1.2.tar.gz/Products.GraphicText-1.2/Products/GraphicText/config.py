from Products.CMFCore.permissions import ManageProperties

TOOL_NAME = "GraphicText"
TOOL_META = TOOL_NAME

GLOBALS = globals()
