"""Common configuration constants
"""

PROJECTNAME = 'pareto.governmentplayer'

ADD_PERMISSIONS = {
    # -*- extra stuff goes here -*-
    'Government Player Clip': 'pareto.governmentplayer: Add Government Player Clip',
}
