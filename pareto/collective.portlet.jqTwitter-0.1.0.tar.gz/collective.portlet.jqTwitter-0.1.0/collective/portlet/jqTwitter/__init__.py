from zope.i18nmessageid import MessageFactory
jqTwitterPortletMessageFactory = MessageFactory('collective.portlet.jqTwitter')


def initialize(context):
    """Initializer called when used as a Zope 2 product."""
