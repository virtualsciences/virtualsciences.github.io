from zope.i18nmessageid import MessageFactory
TTMF = MessageFactory('vs.portlet.twittertimeline')


def initialize(context):
    """Initializer called when used as a Zope 2 product."""
