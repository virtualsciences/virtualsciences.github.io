# -*- coding: utf-8 -*-
"""Setup/installation tests for this package."""

from cmaas.base.testing import IntegrationTestCase
from plone import api


class TestInstall(IntegrationTestCase):
    """Test installation of cmaas.base into Plone."""

    def setUp(self):
        """Custom shared utility setup for tests."""
        self.portal = self.layer['portal']
        self.installer = api.portal.get_tool('portal_quickinstaller')

    def test_product_installed(self):
        """Test if cmaas.base is installed with portal_quickinstaller."""
        self.assertTrue(self.installer.isProductInstalled('cmaas.base'))

    def test_uninstall(self):
        """Test if cmaas.base is cleanly uninstalled."""
        self.installer.uninstallProducts(['cmaas.base'])
        self.assertFalse(self.installer.isProductInstalled('cmaas.base'))

    # browserlayer.xml
    def test_browserlayer(self):
        """Test that ICmaasBaseLayer is registered."""
        from cmaas.base.interfaces import ICmaasBaseLayer
        from plone.browserlayer import utils
        self.failUnless(ICmaasBaseLayer in utils.registered_layers())
