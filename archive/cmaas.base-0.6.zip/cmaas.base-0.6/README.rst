===============================================================================
cmaas.base
===============================================================================

Base CMaaS to handle everything CMaaS

How it works
============

...


Installation
============

To install `cmaas.base` you simply add ``cmaas.base``
to the list of eggs in your buildout, run buildout and restart Plone.
Then, install `cmaas.base` using the Add-ons control panel.


Configuration
=============

...

