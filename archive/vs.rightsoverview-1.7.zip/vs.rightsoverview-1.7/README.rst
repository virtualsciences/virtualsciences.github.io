vs.rightsoverview
=================

Plone package giving an overview page with rights, both the main rights and the overrides though the sharing tab.
