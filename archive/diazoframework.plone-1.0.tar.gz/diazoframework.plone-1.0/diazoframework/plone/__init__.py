from plone.resource.traversal import ResourceTraverser

class FrameworkTraverser(ResourceTraverser):
    name = 'framework'

