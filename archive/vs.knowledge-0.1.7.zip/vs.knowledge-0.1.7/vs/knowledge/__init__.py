from zope.i18nmessageid import MessageFactory

VSKnowledgeMessageFactory = MessageFactory('vs.knowledge')

def initialize(context):
    """Initializer called when used as a Zope 2 product."""
