wowbook
=======

wowBook is a jQuery plugin that let's you publish a book on your website with awesome page flipping effects.

Demo: http://3.s3.envato.com/files/89504756/index.html

Documentation: http://www.neuearbeit.de/wow_book_plugin/documentation/
