vs.wowbook
==========

Plone package using collective.documentviewer to generate the pages and 
using wowBook (https://github.com/yapro/wowbook,
http://www.neuearbeit.de/wow_book_plugin/documentation/) for a pageflipping 
viewer.
