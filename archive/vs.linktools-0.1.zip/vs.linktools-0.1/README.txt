vs.deadfiles
================

Find and fix dead links and files that are not linked to within a Plone site.


Questions, remarks, etc.
------------------------

For questions, remarks, etc. send a mail to thijs.jonkman at virtualsciences dot nl.
