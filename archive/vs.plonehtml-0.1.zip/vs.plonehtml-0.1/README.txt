vs.plonehtml
================

Find and process all HTML snippets in a Plone site. Very simple library (no
Zope/Plone dependencies except that its API works on Plone content) to find
all HTML schema fields and the core Plone portlet fields that contain
HTML and process those snippets.
