# -*- coding: utf-8 -*-
from zope.interface import Interface


class IKnowledgeView(Interface):
    """ Marker interface """


class IProfileView(Interface):
    """ Marker interface """


class ICVView(Interface):
    """ Marker interface """


class IKnowledgeExport(Interface):
    """ Marker interface """


class ICleanupView(Interface):
    """ Marker interface """


class ISkillView(Interface):
    """ Marker interface """


class IChangeSkill(Interface):
    """ Marker interface """
