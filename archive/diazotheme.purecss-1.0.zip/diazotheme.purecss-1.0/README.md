Introduction
============
This package provides diazo themes based on the
[PureCSS framework](http://purecss.io/). For documentation
on the framework itself, check the website.

The themes in this package use 
[diazoframework.purecss](https://github.com/TH-code/diazoframework.purecss).

For more information on:
- how to create a child theme based on the themes in this package, see:
  [diazotheme.plone](https://github.com/TH-code/diazotheme.plone#how-to-create-a-child-theme)
- more frameworks, see: [diazoframework.plone](https://github.com/TH-code/diazoframework.plone#current-frameworks)

