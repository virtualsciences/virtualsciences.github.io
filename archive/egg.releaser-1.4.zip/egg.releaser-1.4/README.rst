egg.releaser
============

Extending zest.releaser to use with git-flow
