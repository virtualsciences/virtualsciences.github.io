vs.uidfixer Package Readme
=========================

Overview
--------

Find relative hrefs in HTML fields, and replace then with resolveuid ones.


Your tests here
---------------

    >>> 1 + 1
    3
