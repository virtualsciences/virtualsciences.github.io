CMaaS Introduction
==================
This product is meant to:
- Provide a CMaaS specific browser layer
- Handle default CMaaS add-ons
- Handle default CMaaS functionality
- Handle CMaaS upgrades in case of hotfixes and or new plone versions
