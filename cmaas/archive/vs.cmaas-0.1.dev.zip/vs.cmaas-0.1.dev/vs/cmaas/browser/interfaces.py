from plone.theme.interfaces import IDefaultPloneLayer

class ICMaaS(IDefaultPloneLayer):
    """Marker interface that defines a Zope 3 browser layer.
    """
