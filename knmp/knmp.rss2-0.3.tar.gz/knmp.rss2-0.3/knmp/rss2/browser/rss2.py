import time
import datetime

import PyRSS2Gen

from Products.CMFCore.utils import getToolByName

from Products.Five import BrowserView
from Products.Five.browser.pagetemplatefile import ViewPageTemplateFile

CACHE_TIME = 5 * 60


class KnmpRSSItem(PyRSS2Gen.RSSItem):
    """Publish an RSS Item"""
    element_attrs = {}

    def __init__(self, **kwargs):
        for attr in (
                'title', 'link', 'description', 'author', 'categories',
                'comments', 'enclosure', 'guid', 'pubDate', 'source',
                'location', 'startdate', 'enddate'):
            value = kwargs.get(attr)
            if attr == 'categories' and value is None:
                value = []
            setattr(self, attr, value)
        if self.title is None:
            raise TypeError('title is mandatory')

    def publish(self, handler):
        handler.startElement("item", self.element_attrs)
        PyRSS2Gen._opt_element(handler, "title", self.title)
        PyRSS2Gen._opt_element(handler, "link", self.link)
        self.publish_extensions(handler)
        PyRSS2Gen._opt_element(handler, "description", self.description)
        PyRSS2Gen._opt_element(handler, "author", self.author)

        for category in self.categories:
            if isinstance(category, basestring):
                category = PyRSS2Gen.Category(category)
            category.publish(handler)

        PyRSS2Gen._opt_element(handler, "comments", self.comments)
        if self.enclosure is not None:
            self.enclosure.publish(handler)
        PyRSS2Gen._opt_element(handler, "guid", self.guid)

        pubDate = self.pubDate
        if isinstance(pubDate, datetime.datetime):
            pubDate = PyRSS2Gen.DateElement("pubDate", pubDate)
        PyRSS2Gen._opt_element(handler, "pubDate", pubDate)

        if self.source is not None:
            self.source.publish(handler)

        if self.location is not None:
            PyRSS2Gen._element(
                handler, "mailplus:location", self.location,
                {'xmlns:mailplus': 'mailplus:'})

        if self.startdate is not None:
            if isinstance(self.startdate, datetime):
                date = self.startdate.strftime('%d-%m-%Y')
                enddate = self.enddate and self.enddate.strftime('%d-%m-%Y')
                if enddate and enddate != date:
                    date = '%s t/m %s' % (date, enddate)
            else:
                date = str(self.startdate)
                if self.enddate and self.enddate != self.startdate:
                    date = '%s t/m %s' % (date, self.enddate)
            PyRSS2Gen._element(
                handler, "mailplus:eventdate", date,
                {'xmlns:mailplus': 'mailplus:'})

        handler.endElement("item")


class RSS2View(BrowserView):
    template = ViewPageTemplateFile('rss2.pt')

    # shared between instances
    _cache = {}

    def __call__(self):
        return self.template()

    def head(self):
        offset = int(self.request.get('offset', 0))
        limit = int(self.request.get('limit', 2))
        return self._xml(offset, limit, True)

    def tail(self):
        offset = int(self.request.get('offset', 2))
        limit = int(self.request.get('limit', -1))
        return self._xml(offset, limit, False)

    def xml(self):
        show_desc = self.request.get('format', 'full') != 'compact'
        offset = int(self.request.get('offset', 0))
        limit = int(self.request.get('limit', -1))
        return self._xml(offset, limit, show_desc)

    def _xml(self, offset=0, limit=-1, show_desc=True):
        self.request.RESPONSE.setHeader('Content-Type', 'text/xml')
        cachekey = (self.request.URL, offset, limit, show_desc)
        cached = self._cache.get(cachekey)
        timestamp = time.time()
        if (cached is not None and
                cached['timestamp'] > timestamp - CACHE_TIME):
            return cached['data']
        rss = PyRSS2Gen.RSS2(
            title=self.context.title.encode('utf-8'),
            link=self.context.absolute_url(),
            description=self.context.Description(),
            lastBuildDate=datetime.datetime.now(),
            items=self.get_items(offset, limit, show_desc))
        xml = rss.to_xml(encoding='utf-8')
        self._cache[cachekey] = {
            'timestamp': timestamp,
            'data': xml,
        }
        return xml

    def get_items(self, offset, limit, show_desc):
        portal_syndication = getToolByName(self.context, 'portal_syndication')
        objects = portal_syndication.getSyndicatableContent(self.context)
        count = portal_syndication.getMaxItems(self.context)
        if offset:
            objects = objects[offset:]
        if limit == -1:
            limit = count
        else:
            limit = min(limit, count)
        objects = objects[:limit]
        for newsitem in objects:
            url = newsitem.absolute_url()
            # note that because we use and/or, if the show_desc is True but
            # the description is empty (resolves to False), we still get nbsp
            # as value
            desc = show_desc and newsitem.Description() or ''
            try:
                location = newsitem.getLocation()
            except (KeyError, AttributeError):
                location = ''
            try:
                startdate = newsitem.startDate
                enddate = newsitem.endDate
            except (KeyError, AttributeError):
                startdate = enddate = None
            yield KnmpRSSItem(
                title=newsitem.title.encode('utf-8'),
                link=url,
                guid=PyRSS2Gen.Guid(url),
                description=desc,
                location=location,
                startdate=startdate,
                enddate=enddate)
