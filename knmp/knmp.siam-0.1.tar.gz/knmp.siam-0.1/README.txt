.. contents::

=========
KNMP SIAM
=========

Introduction
============

This module provides SIAM (single sign-on) support for KNMP, using their own
SIAM server (Anoigo). It exposes a PAS (Pluggable Authentication System) plugin
that redirects a user to the authentication service to authenticate, then
allows access based on the return value of the server.

Installation
============

Add knmp.siam to your buildout.cfg::

  [buildout]
  find-links =
    ...
    https://dist.pareto.nl/public
  eggs =
    ...
    knmp.siam
  zcml =
    ...
    knmp.siam

then re-run bin/buildout. When done, start Zope and visit the Plone root in
the ZMI. Find 'portal_quickinstaller' and install the 'KNMP SIAM' product, this
will add a 'KNMP SIAM service' to the 'acl_users' PAS instance in your Plone
root.

Next, visit that PAS ('acl_users' in the Plone root) and click the
SIAM service 'knmp-siam-service', this will open the SIAM configuration screen.
Enter the KNMP SIAM information (server URL, shared secret, aselect server
name, app id) and optionally set the title, refresh interval and whether SSL
certificates should be validated.

The refresh interval describes the amount of
seconds a session is valid without verification. This should always be lower
than the SIAM session time minus the Zope session time, so refresh interval +
Zope session expiration time must be less than the SIAM session expiration
time. If unsure, keep low (e.g. 60 seconds).

Whether SSL certificates should be checked depends on whether your certificates
can be validated. Check the checkbox if your server-side SSL certificates are
valid, leave unchecked if you're using e.g. self-signed certificates that can
not be validated. Leaving this unchecked may speed up communication between
the web-server and SIAM server too, so you may wish to disable even if your
certificates can be validated, though it does imply reduced security.

After you have entered the settings, press 'save' and the system is ready for
use. This means that a new link 'log in using the KNMP SIAM system' is added
to the login form (so displayed when a user tries to access a resource that
requires authentication), clicking it will start the SIAM authentication
process. Authenticating to Zope directly is still possible using the username
and password fields that remain in the form.

Questions, remarks, etc.
========================

For questions, remarks, etc. send a mail to guido.wesdorp at pareto dot nl.

