from zope import interface


class IDatabase(interface.Interface):
    """A database wrapper"""
