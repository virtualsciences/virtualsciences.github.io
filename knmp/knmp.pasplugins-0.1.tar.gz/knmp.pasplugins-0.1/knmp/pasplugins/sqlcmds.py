# -*- coding: utf-8 -*-
THESAURUSNUMMER = 524
THESAURUSTAAL = "NL"
vars = {'tnr': THESAURUSNUMMER, 'ttaal': THESAURUSTAAL}
DATABASE_ENCODING = "iso-8859-1"
SQL_CMDS = {\
'plugins_NAL':
"""        SELECT nanaam AS fullname
           FROM admdta.nagpf, admdta.wuspf
           WHERE wuusid='%s' AND wunanwnr=nanwnr""",
'plugins_Email':
"""        SELECT nwademl AS email
           FROM admdta.nwapf, admdta.wuspf
           WHERE wuusid='%s' AND wunanwnr=nanwnr""",
'plugins_User':
"""        SELECT wuusid AS username
           FROM admdta.wuspf, admdta.usvpf
           WHERE wuusid='%s' AND wupwd='%s' AND wuusid=ususid
                             AND usactief='J'""",
'plugins_update_password':
"""        UPDATE admdta.wuspf SET wupwd='%s' WHERE wuusid='%s'
""",
'plugins_update_email':
"""        SELECT wunanwnr
           FROM admdta.wuspf
           WHERE wuusid='%s'""",
'plugins_update_email2':
"""        UPDATE admdta.nwapf SET nwademl='%s' WHERE nanwnr=%s""",
'plugings_load_users':
"""        SELECT wuusid AS username
           FROM admdta.wuspf
""",
'plugins_search_users':
"""        SELECT wuusid AS username
           FROM admdta.wuspf
           WHERE UPPER(wuusid) LIKE '%s%%'
""",
'plugins_load_user':
"""        SELECT wuusid AS username
           FROM admdta.wuspf
           WHERE wuusid='%s'
""",
}
