from zope.component import adapts
from zope.interface import implements
from archetypes.schemaextender.interfaces import ISchemaExtender
from Products.ATContentTypes.interface import IATTopic
from Products.ATReferenceBrowserWidget.ATReferenceBrowserWidget import ReferenceBrowserWidget
from Products.Archetypes import atapi
from archetypes.schemaextender.field import ExtensionField

class HiliteField(ExtensionField, atapi.ReferenceField):
    """A hilite field """

class HiliteExtender(object):
    implements(ISchemaExtender)
    adapts(IATTopic)

    _fields = [
        HiliteField('hilited',
            schemata = "categorization",
            relationship='Hilited',
            languageIndependent = True,
            multiValued=True,
            widget = ReferenceBrowserWidget(
                label="Select items")),
            ]

    def __init__(self, context):
        self.context = context

    def getFields(self):
        return self._fields
