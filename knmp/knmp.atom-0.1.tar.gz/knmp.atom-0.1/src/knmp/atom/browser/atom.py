from Products.Five import BrowserView

class AtomView(BrowserView):
    pass
