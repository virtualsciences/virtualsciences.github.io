from plone.app.testing import PloneSandboxLayer
from plone.app.testing import PLONE_FIXTURE
from plone.app.testing import TEST_USER_NAME
from plone.app.testing import IntegrationTesting, FunctionalTesting
from zope.configuration import xmlconfig
from plone.testing import z2

class MyProduct(PloneSandboxLayer):

    defaultBases = (PLONE_FIXTURE,)

    def setUpZope(self, app, configurationContext):
        # Load ZCML
        import knmp.atom
        xmlconfig.file('configure.zcml', knmp.atom, context=configurationContext)

        # Note: you can skip this if my.product is not a Zope 2-style
        # product, i.e. it is not in the Products.* namespace and it
        # does not have a <five:registerPackage /> directive in its
        # configure.zcml.


    def setUpPloneSite(self, portal):

        user_folder = portal.acl_users
        z2.setRoles(user_folder, TEST_USER_NAME, ['Manager'])
        z2.login(user_folder, TEST_USER_NAME)
        topic_id = portal.invokeFactory('Topic', 'atom', title=u"My Atom")
        topic = portal[topic_id]
        for i in range(4):
            portal.invokeFactory(
                'News Item', 
                'n{0}'.format(i), 
                description='d{0}'.format(i),
                title='t{0}'.format(i),
                text='news item text {0}'.format(i))
        # set up some news items and publish them
        # set the criteria of the Topic
        crit = topic.addCriterion('Type', 'ATPortalTypeCriterion')
        crit.setValue('News Item')
        z2.setRoles(user_folder, TEST_USER_NAME, ['Member'])
        self['topic'] = topic # vlgs. mij zet dit een layer variabele

MY_PRODUCT_FIXTURE = MyProduct()
MY_PRODUCT_INTEGRATION_TESTING = IntegrationTesting(bases=(MY_PRODUCT_FIXTURE,), name="MyProduct:Integration")
MY_PRODUCT_FUNCTIONAL_TESTING = FunctionalTesting(bases=(MY_PRODUCT_FIXTURE,), name="MyProduct:Functional")

