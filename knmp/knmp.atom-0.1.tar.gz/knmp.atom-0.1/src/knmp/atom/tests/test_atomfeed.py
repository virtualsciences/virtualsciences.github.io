import unittest2 as unittest
from knmp.atom.testing import MY_PRODUCT_FUNCTIONAL_TESTING
from plone.testing.z2 import Browser

#class TestFasterThanLightTravel(unittest.TestCase):
#    def test_me(self):
#        assert True

class IntegrationTest(unittest.TestCase):

    layer = MY_PRODUCT_FUNCTIONAL_TESTING

    def helper(self):
        from Products.CMFCore.utils import getToolByName
        portal = self.layer['portal']
        error_log = getToolByName(portal, 'error_log')
        return error_log.getLogEntries()[-1]['tb_text']

    def test_atomfeed(self):
        portal = self.layer['portal']
        topic = self.layer['topic']
        app = self.layer['app']
        browser = Browser(app)
        portalURL = portal.absolute_url()
        browser.open('{0}/atom/atom.xml'.format(portalURL))
        open('/tmp/out.html', 'w').write(browser.contents)


        #self.assertEquals(topic.queryCatalog().sequence_length, 4)



