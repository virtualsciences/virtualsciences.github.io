import pycurl
import urllib
import urllib2
import urlparse
import base64
import time

try:
    from cStringIO import StringIO
except ImportError:
    from StringIO import StringIO

from Products.CMFCore.utils import getToolByName
from Products.PluggableAuthService.plugins.BasePlugin import BasePlugin
from AccessControl.SecurityInfo import ClassSecurityInfo
from Globals import InitializeClass
from Products.PageTemplates.PageTemplateFile import PageTemplateFile
from Products.PlonePAS.plugins.ufactory import PloneUser
from zope.schema import ValidationError

from Products.PluggableAuthService.utils import classImplements
from Products.PluggableAuthService.interfaces.plugins import (
    IExtractionPlugin, IAuthenticationPlugin, IRolesPlugin)

from Products.ATContentTypes import ATCTMessageFactory as _

RESPONSE_OK = '0000'


class KnmpSIAMService(BasePlugin):
    """ KNMP single sign-on solution

        This functions as a Zope Pluggable Authentication System (PAS)
        plugin to handle authentication and credential extraction by
        interfacing with a SIAM server hosted by KNMP. Using this plugin
        users can use the SIAM server as an external authentication/
        authorization system (though authorization beyond authentication
        is currently out of scope).

        The object exposes a ZMI view for editing its properties, and
        in addition it exposes some public views to log in and out, and
        one that the user is redirected to by the system. The rest of the
        methods are helpers for interfacing with the system.

        For every user the service authenticates, it connects to the system
        first to retrieve a special token (RID), then lets the user
        authenticate against the system by redirecting it to a system URL,
        then when the user gets back (the system redirects back to a local
        URL) it verifies the credentials the system placed on the redirect URL
        again using a local to system connection. Every once in a while, the
        object also 'pings' the system to notify the session is still alive.
        On logout, the user is redirected to the system after removing the
        local session info.
    """

    meta_type = 'KNMP SIAM PAS plugin'
    security = ClassSecurityInfo()

    _session_key_creds = '__knmp_siam_credentials'
    _session_key_referer = '__knmp_siam_referer'

    manage_options = (
        {'label': 'Edit', 'action': 'edit'},
    ) + BasePlugin.manage_options

    attribute_to_role = (
        'attributes/aselectLdapRegistered|true|Authenticated\n'
        'attributes/subscription|pw_abonnee|Member\n'
        'attributes/subscription|pw_abonnee|Premium Member\n'
        'attributes/subscription|knmp_lid|Member\n'
        'attributes/subscription|knmp_lid|Premium Member\n'
        'attributes/employee|webeditor|Editor\n'
        'attributes/employee|webeditor|Contributor\n'
    )


    def __init__(
            self, id, title=None, SIAM_URL=None, shared_secret=None,
            a_select_server=None, app_id=None, upgrade_interval=60,
            attribute_to_role=attribute_to_role,
            validate_SSL=False):
        self._setId(id)
        self.title = title
        self.SIAM_URL = SIAM_URL
        self.shared_secret = shared_secret
        self.a_select_server = a_select_server
        self.app_id = app_id
        self.upgrade_interval = upgrade_interval
        self.attribute_to_role = attribute_to_role
        self.validate_SSL = validate_SSL

    # management and login/logout views
    edit = PageTemplateFile('www/edit.pt', globals())

    security.declareProtected('View management screens', 'manage_save')
    def manage_save(
            self, title, SIAM_URL, shared_secret, a_select_server,
            app_id, upgrade_interval, attribute_to_role,
            validate_SSL=False, REQUEST=None):
        """ save object data
        """
        errors = []
        if not title:
            errors.append(_('Title'))
        if not SIAM_URL:
            errors.append(_('SIAM URL'))
        if not shared_secret:
            errors.append(_('Shared secret'))
        if not a_select_server:
            errors.append(_('ASelect server'))
        if not app_id:
            errors.append(_('App ID'))
        if not upgrade_interval:
            errors.append(_('Upgrade interval'))
        try:
            upgrade_interval = int(upgrade_interval)
        except ValueError:
            errors.append(_('Upgrade interval must be a number'))
        if not attribute_to_role:
            errors.append(_('Attribute to role mapping'))

        if errors:
            self.REQUEST['message'] = _(
                'The following fields can not be empty: ${fields}',
                mapping={'fields': ', '.join(errors)})
        else:
            self.title = title
            self.SIAM_URL = SIAM_URL
            self.shared_secret = shared_secret
            self.a_select_server = a_select_server
            self.app_id = app_id
            self.upgrade_interval = upgrade_interval
            self.attribute_to_role = attribute_to_role
            self.validate_SSL = validate_SSL

            self.REQUEST['message'] = _('Your data has been saved')

        return self.edit(self.REQUEST)

    security.declarePublic('login')
    def login(self):
        """ log in to the SIAM system

            connects to the system, retrieves an auth token (rid) and then
            redirects the user to the single sign-on service's login page
            with this token, when done, the user is redirected to 'logged_in'
            below
        """
        # store the referer (sic) in a session so we can redirect back on
        # login
        referer = self.REQUEST['HTTP_REFERER']
        if 'came_from=' in referer:
            # referer is the login page, we need to poke a bit more to get
            # the actual referer
            getvars = dict(
                (k, v[0]) for (k, v) in
                urlparse.parse_qs(referer.split('?', 1)[1]).items())
            referer = getvars.get('came_from', referer)
        if not referer:
            referer = self.REQUEST.get('came_from')
        self.REQUEST.SESSION[self._session_key_referer] = referer

        # authenticate our system against the SIAM system to get an RID and
        # URL for the login process
        getvars = {
            'request': 'authenticate',
            'shared_secret': self.shared_secret,
            'a-select-server': self.a_select_server,
            'app_id': self.app_id,
            'app_url': '%s/logged_in' % (self.absolute_url(),)}
        res = self._request(**getvars)
        if res['result_code'] != RESPONSE_OK:
            self._error(res['result_code'])

        # build a login URL based on the response data
        getvars = {
            'a-select-server': res['a-select-server'],
            'rid': res['rid']}

        # redirect the user to the login URL (SIAM) to perform the
        # actual login
        url = res['as_url']
        if '?' in url:
            url += '&'
        else:
            url += '?'
        url += urllib.urlencode(getvars)
        self.REQUEST.RESPONSE.redirect(url)

    security.declarePublic('logged_in')
    def logged_in(self):
        """ verify credentials and retrieve attributes

            this is the URL where the user is redirected to by the SIAM
            server, once the login process is complete
        """
        # we know now the user is logged in, credentials should be in
        # the URL, verify and store in the session
        req = self.REQUEST
        creds = req['aselect_credentials']

        # create a verification request
        getvars = {
            'request': 'verify_credentials',
            'shared_secret': self.shared_secret,
            'a-select-server': req['a-select-server'],
            'rid': req['rid'],
            'aselect_credentials': creds,
        }
        res = self._request(**getvars)
        if res['result_code'] != RESPONSE_OK:
            self._error(res['result_code'])

        # the response to the verification request contains all the info
        # we're interested in
        attributes_str = res.get('attributes')
        attributes = {}
        if attributes_str is not None:
            attributes_str = base64.decodestring(attributes_str)
            attributes = dict(
                (k, v[0]) for (k, v) in
                    urlparse.parse_qs(attributes_str).items())

        req.SESSION[self._session_key_creds] = {
            'ticket': creds,
            'uid': res['uid'],
            'organisation': res.get('organisation', ''),
            'a-select-server': req['a-select-server'],
            'app_level': res['app_level'],
            'tgt_exp_time': int(res['tgt_exp_time']) / 1000.0, # msecs
            'last_check_time': time.time(),
            'authsp': res['authsp'],
            'authsp_level': res['authsp_level'],
            'screenname': attributes['screenname'],
            'attributes': attributes,
        }

        # redirect to the URL from which the login was initiated, with a
        # message
        referer = req.SESSION[self._session_key_referer]
        self.plone_utils.addPortalMessage(_('You are logged in'))
        self.REQUEST.RESPONSE.redirect(referer)

    security.declarePublic('logout')
    def logout(self):
        """ log out of SIAM
        """
        req = self.REQUEST
        sessdata = req.SESSION.get(self._session_key_creds)
        try:
            del(req.SESSION[self._session_key_creds])
        except KeyError:
            pass
        try:
            del(req.SESSION[self._session_key_referer])
        except KeyError:
            pass
        if sessdata:
            redirect_url = (
                '%s?request=kill_tgt&tgt_blob=%s&a-select-server=%s'
                '&logout_return_url=%s' % (
                    self.SIAM_URL, sessdata['ticket'],
                    sessdata['a-select-server'],
                    urllib.quote('%s/logged_out' % (
                        self.absolute_url(),))))
        else:
            redirect_url = self.SIAM_URL
        req.RESPONSE.redirect(redirect_url)

    security.declarePublic('logged_out')
    def logged_out(self):
        """ handle SIAM logout redirect

            if logging out was successful, redirect to the Plone root, else
            raise a 500
        """
        req = self.REQUEST
        if req['result_code'] != RESPONSE_OK:
            self._error(req['result_code'])
        portal_url = getToolByName(self, 'portal_url')
        portal = portal_url.getPortalObject()
        redirect_url = portal.absolute_url()
        req.RESPONSE.redirect(redirect_url)

    # PAS plugin methods
    def extractCredentials(self, request=None):
        creds = self.REQUEST.SESSION.get(self._session_key_creds)
        if creds is None:
            return None
        return {
            'login': creds['uid'],
            'screenname': creds['screenname'],
            'knmp-siam-ticket': creds['ticket'],
            'a-select-server': creds['a-select-server'],
        }

    def authenticateCredentials(self, credentials):
        creds = credentials.get('knmp-siam-ticket')
        if creds is None:
            return None

        # XXX meh, feels like this is the wrong place/time to do this...
        # verify/refresh stored credentials if they're 'old'
        now = time.time()
        last = self.REQUEST.SESSION[
            self._session_key_creds]['last_check_time']
        if now - last > self.upgrade_interval:
            # re-set session var immediately to tell other threads they
            # don't have to check
            self.REQUEST.SESSION[
                self._session_key_creds]['last_check_time'] = now
            getvars = {
                'request': 'upgrade_tgt',
                'a-select-server': credentials['a-select-server'],
                'crypted_credentials': creds}
            res = self._request(**getvars)
            if res['result_code'] != RESPONSE_OK:
                self._error(res['result_code'])

        return (credentials['login'], credentials['screenname'])

    def getRolesForPrincipal(self, user, request=None):
        credentials = self.REQUEST.SESSION.get(self._session_key_creds)
        if credentials is None:
            return []
        # we can only provide role information for the users we have in
        # our database - use an LDAP solution as IRolesPlugin instead of
        # this one if you want to find and enumerate users (SIAM users
        # are never stored in the system, nor does the SIAM server allow
        # retrieving lists of said users)
        if user.getUserId() != credentials['uid']:
            return []
        roles = []
        for line in self.attribute_to_role.split('\n'):
            line = line.strip()
            if not line:
                continue
            path, expected, role = line.split('|')
            value = credentials
            for segment in path.split('/'):
                try:
                    value = value[segment]
                except KeyError:
                    break
            else:
                value = value.split(',')
                if expected in value:
                    roles.append(role)
        return roles

    # helper functionality
    def _request(self, **kwargs):
        url = '%s?%s' % (self.SIAM_URL, urllib.urlencode(kwargs))
        s = StringIO()
        # use pycurl, as httplib doesn't deal with self-signed certificates
        # and such
        conn = pycurl.Curl()
        conn.setopt(pycurl.URL, url)
        conn.setopt(pycurl.WRITEFUNCTION, s.write)
        conn.setopt(pycurl.TIMEOUT, 30) # XXX configurable?
        if not self.validate_SSL:
            conn.setopt(pycurl.SSL_VERIFYHOST, 0)
            conn.setopt(pycurl.SSL_VERIFYPEER, 0)
        conn.perform()
        conn.close()

        s.seek(0)
        res = s.read()
        # values are always only once in the request, so we can safely
        # flatten
        form = dict((k, v[0]) for (k, v) in urlparse.parse_qs(res).items())
        return form

    def _error(self, code):
        raise urllib2.HTTPError(
            self.REQUEST['URL'], 500, 'SIAM error: %s' % (code,), {}, None)

classImplements(
    KnmpSIAMService, IExtractionPlugin, IAuthenticationPlugin,
    IRolesPlugin)
InitializeClass(KnmpSIAMService)

def addKnmpSIAMService(self, id, title='', REQUEST=None):
    p = KnmpSIAMService(id, title)
    self._setObject(p.getId(), p)
    if REQUEST is not None:
        REQUEST.RESPONSE.redirect(
            '%s/manage_main?manage_tabs_message=SIAM+Service+added.' %
                (self.absolute_url(),))

manage_addKnmpSIAMServiceForm = PageTemplateFile(
    'www/add.pt', globals(), __name__='manage_addKnmpSIAMServiceForm')
