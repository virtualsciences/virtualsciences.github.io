from Products.PlonePAS.Extensions.Install import activatePluginInterfaces
from Products.CMFCore.utils import getToolByName
from StringIO import StringIO
from service import addKnmpSIAMService

def importInstall(context):
    """ Install KNMP SIAM Service
    """
    out = StringIO()
    portal = context.getSite()

    uf = getToolByName(portal, 'acl_users')
    installed = uf.objectIds()

    if 'knmp_siam_service' not in installed:
        addKnmpSIAMService(uf, 'knmp_siam_service', 'KNMP SIAM Service')
        activatePluginInterfaces(portal, 'knmp_siam_service', out)
        print >> out, 'KNMP SIAM Service installed'
    else:
        print >> out, 'KNMP SIAM Service already installed'

    print out.getvalue()
