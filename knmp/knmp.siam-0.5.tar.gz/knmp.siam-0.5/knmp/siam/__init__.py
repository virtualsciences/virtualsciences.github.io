from AccessControl.Permissions import manage_users
from . import service

def initialize(context):
    context.registerClass(
        service.KnmpSIAMService,
        permission=manage_users,
        constructors=(
            service.manage_addKnmpSIAMServiceForm,
            service.addKnmpSIAMService),
        visibility=None,
        icon="www/icon.png")
