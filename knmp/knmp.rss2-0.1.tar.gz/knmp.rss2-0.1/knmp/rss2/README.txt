knmp.rss2 - RSS 2.0 syndication for Plone
=========================================
