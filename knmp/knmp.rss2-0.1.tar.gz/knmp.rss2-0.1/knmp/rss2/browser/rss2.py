import datetime

import PyRSS2Gen

from Products.CMFCore.utils import getToolByName

from Products.Five import BrowserView
from Products.Five.browser.pagetemplatefile import ViewPageTemplateFile

CACHE_TIME = 5 * 60


class RSS2View(BrowserView):
    template = ViewPageTemplateFile('rss2.pt')

    def __init__(self, *args, **kwargs):
        self._cache = {}
        super(RSS2View, self).__init__(*args, **kwargs)

    def __call__(self):
        return self.template()

    def head(self):
        self.request['format'] = 'head'
        return self()

    def tail(self):
        self.request['format'] = 'tail'
        return self()

    def xml(self):
        format = self.request.get('format', 'full')
        return self._xml(format)

    def _xml(self, format='full'):
        rss = PyRSS2Gen.RSS2(
            title=self.context.title.encode('utf-8'),
            link=self.context.absolute_url(),
            description=self.context.Description(),
            lastBuildDate=datetime.datetime.now(),
            items=self.get_items(format))
        return rss.to_xml()

    def get_items(self, format):
        portal_syndication = getToolByName(self.context, 'portal_syndication')
        objects = portal_syndication.getSyndicatableContent(self.context)
        for i, newsitem in enumerate(objects):
            if format == 'head' and i >= 2:
                break
            elif i < 2 and format == 'tail':
                continue
            url = newsitem.absolute_url()
            desc = (
              format != 'tail' and newsitem.Description()
                or None)
            yield PyRSS2Gen.RSSItem(
                title=newsitem.title.encode('utf-8'),
                link=url,
                guid=PyRSS2Gen.Guid(url),
                description=desc)
