import copy
import os
import logging

from zope import component
from App.special_dtml import DTMLFile
from AccessControl import ClassSecurityInfo
from App.class_init import default__class_init__ as InitializeClass
from OFS.Cache import Cacheable

from Products.PluggableAuthService.utils import createViewName
from Products.PluggableAuthService.utils import classImplements
from Products.PluggableAuthService.interfaces.plugins import (
    IAuthenticationPlugin, IUserEnumerationPlugin)
from Products.PluggableAuthService.interfaces.plugins import IPropertiesPlugin
from Products.PluggableAuthService.permissions import ManageUsers
from Products.PluggableAuthService.plugins.BasePlugin import BasePlugin
from Products.PlonePAS.interfaces.plugins import IUserManagement
from Products.PlonePAS.interfaces.plugins import IMutablePropertiesPlugin
from Products.PlonePAS.interfaces.capabilities import IPasswordSetCapability
from Products.PlonePAS.sheet import MutablePropertySheet

from knmp.pasplugins.interfaces import IDatabase
from knmp.pasplugins import sqlcmds

logger = logging.getLogger('KNMP PASPlugins')

manage_options = list(BasePlugin.manage_options + Cacheable.manage_options)

manage_addKNMPPasManagerForm = DTMLFile(
    os.path.join('zmi', 'KNMPPasManagerForm'), globals())

_marker = []


def clearnasties(*values):
    """Remove all potentially nasty values from each item and return it.
    This can be used to prevent SQL injection attacks."""
    return [str(value.replace('"', '').replace("'", '')) for value in values]


def manage_addKNMPPasManager(self, id, title='', sql_connection='',
                            REQUEST=None):
    """Add a KNMPPasManager to a Pluggable Auth Service."""
    um = KNMPPasManager(id, title, sql_connection)
    self._setObject(um.getId(), um)
    if REQUEST is not None:
        REQUEST['RESPONSE'].redirect(
                                '%s/manage_workspace'
                                '?manage_tabs_message='
                                'KNMPPasManager+added.'
                            % self.absolute_url())


class KNMPPasManager(BasePlugin, Cacheable):
    """PAS plugin for managing users in the Z-Index database."""
    meta_type = 'KNMP PAS Manager'
    security = ClassSecurityInfo()

    _properties = (
        {'id': 'connection', 'type': 'string', 'mode': 'w'},
    )

    manage_options = manage_options

    def __init__(self, id, title=None, connection=None):
        super(KNMPPasManager, self).__init__()
        self._id = self.id = id
        self.title = title
        self._connection = connection

    def query(self, q, debug=False):
        db = component.getUtility(IDatabase, 'db')
        return db.query(self, q, debug=debug)
    #
    # IAuthenticationPlugin implementation
    #
    security.declarePrivate('authenticateCredentials')

    def authenticateCredentials(self, credentials):
        """See IAuthenticationPlugin.

        o We expect the credentials to be those returned by
          ILoginPasswordExtractionPlugin.
        """
        login, password = clearnasties(credentials.get('login'),
                                       credentials.get('password'))
        if login is None or password is None:
            return None

        try:
            user = self.getUserInfo(login, password, auth=True)
        # Any (db) error must be ignored
        except:
            logger.exception('Could not lookup user in database: %s', login)
            return
        if user is not None:
            pas = self._getPAS()
            pas.updateCredentials(self.REQUEST,
                                  self.REQUEST.RESPONSE, login, password)
            return login, login

    #
    # IUserManagement implementation
    #
    security.declarePrivate('doChangeUser')

    def doChangeUser(self, login, password, **kw):
        login, password = clearnasties(login, password)
        try:
            self.updateUserPassword(login, login, password)
        except KeyError:
            raise RuntimeError('User does not exist: ' + login)

    security.declarePrivate('doDeleteUser')

    def doDeleteUser(self, login):
        return False  # Deleting from Plone is not supported

    #
    # IUserEnumerationPlugin implementation
    #
    security.declarePrivate('enumerateUsers')

    def enumerateUsers(self, id=None, login=None, exact_match=False,
                       sort_by=None, max_results=None, **kw):
        """See IUserEnumerationPlugin.
           Searches for user in plone control panel
        """
        view_name = createViewName('enumerateUsers', id or login)

        #if isinstance(id, str):
        #    id = [id]
        #if isinstance(login, str):
        #    login = [login]

        # Check cached data
        keywords = copy.deepcopy(kw)
        info = {
            'id': id,
            'login': login,
            'exact_match': exact_match,
            'sort_by': sort_by,
            'max_results': max_results,
        }
        keywords.update(info)
        cached_info = self.ZCacheable_get(view_name=view_name,
                                          keywords=keywords)
        if cached_info is not None:
            return cached_info

        terms = []
        for i in (id, login):
            if i is None:
                continue
            if isinstance(i, list):
                terms.extend(i)
            else:
                terms.append(i)

        results = []
        if exact_match:
            for term in terms:
                for info in self.sqlLoadUser(username=term).tuples():
                    results.append(info)
        elif 'fullname' in kw:
            results = self.sqlSearchUsers(kw['fullname']).tuples()
        else:
            results = self.sqlLoadAllUsers().tuples()

        all = {}
        for n, record in enumerate(results):
            uid = record[0]
            data = {
                'id': uid,
                'login': uid,
                'pluginid': self.getId(),
            }

            if max_results is not None and len(all) == max_results:
                break

            if exact_match or not terms:
                all.setdefault(uid, data)
            else:
                for term in terms:
                    if term in uid:
                        all.setdefault(uid, data)
                        if max_results is not None and len(all) == max_results:
                            break

        values = tuple(all.values())

        # Cache data upon success
        self.ZCacheable_set(values, view_name=view_name, keywords=keywords)
        return values

    # IPropertiesPlugin implementation
    def getPropertiesForUser(self, user, request=None):
        """Get property values for a user or group.

        Returns a dictionary of values.
        """
        view_name = createViewName('getPropertiesForUser', user.getUserName())
        cached_info = self.ZCacheable_get(view_name=view_name)
        if cached_info is not None:
            return MutablePropertySheet(self.id, **cached_info)

        # Setup the default values
        data = {}

        username = user.getUserName()
        # Set the NAL properties, but only from the first record found.
        res = self.sqlLoadNAL(username)
        for (fullname,) in res.tuples():
            data['fullname'] = fullname
            break
        # Set the email address
#        res = self.sqlLoadEmail(username)
#        for (email,) in res.tuples():
#            data['email'] = email
#            break

        self.ZCacheable_set(data, view_name=view_name)
        return MutablePropertySheet(self.id, **data)

    #
    # IMutablePropertiesPlugin
    #

    def setPropertiesForUser(self, user, propertysheet):
        username = user.getUserName()
        # XXX Disable this, maybe we get extra tables
        # email = propertysheet.getProperty('email')
        # that can be used to implement this (JM)
        # self.sqlUpdateEmail(username, email)
        # Clear the cache
        view_name = createViewName('getPropertiesForUser', username)
        self.ZCacheable_invalidate(view_name=view_name)

    #
    # IPasswordSetCapability implementation
    #

    def allowPasswordSet(self, id):
        """True if this plugin can set the password of a certain user."""
        info = self.getUserInfo(id)
        return info is not None

    #
    # (notional)IZODBUserManager interface
    #
    security.declareProtected(ManageUsers, 'listUserIds')

    def listUserIds(self):
        res = self.sqlLoadAllUsers()
        tuples = res.tuples()
        all = [row['username'] for row in tuples]
        return tuple(all)

    security.declareProtected(ManageUsers, 'getUserInfo')

    def getUserInfo(self, uid, password=None, auth=False):
        view_name = createViewName('getUserInfo', uid)
        keywords = dict(auth=auth)

        # Only load from cache when we are not authenticating as a security
        # precaution.
        if not auth:
            cached_info = self.ZCacheable_get(view_name=view_name,
                    keywords=keywords,
                    default=_marker)
            if cached_info is not _marker:
                return cached_info

        if auth:
            res = self.sqlAuthUser(username=uid, password=password)
        else:
            res = self.sqlLoadUser(username=uid)

        tuples = res.tuples()
        if tuples:
            record = tuples[0]
            uid = record[0]
            data = {
                'id': str(uid),
                'login': str(uid),
                'pluginid': self.getId(),
            }
        else:
            data = None

        if not auth:
            self.ZCacheable_set(data, view_name=view_name, keywords=keywords)

        return data

    security.declareProtected(ManageUsers, 'listUserInfo')

    def listUserInfo(self):
        res = self.sqlLoadAllUsers()
        tuples = res.tuples()
        return tuples

    security.declareProtected(ManageUsers, 'getUserIdForLogin')

    def getUserIdForLogin(self, login_name):
        return login_name

    security.declareProtected(ManageUsers, 'getLoginForUserId')

    def getLoginForUserId(self, user_id):
        return user_id

    security.declarePrivate('updateUserPassword')

    def updateUserPassword(self, user_id, login_name, password):
        user_id, password = clearnasties(user_id, password)
        existingUser = self.getUserInfo(user_id)
        if existingUser is None:
            raise KeyError('Invalid user ID: %s' % user_id)
        self.sqlUpdatePassword(uid=login_name, password=password)

    # SQL Queries
    security.declarePrivate('sqlLoadNAL')

    def sqlLoadNAL(self, username):
        """Load the NAL data set for the given user."""
        username = clearnasties(username)[0]
        return self.query(sqlcmds.SQL_CMDS['plugins_NAL'] % username)

    security.declarePrivate('sqlLoadEmail')

    def sqlLoadEmail(self, username):
        """Return the email address for the given user."""
        username = clearnasties(username)[0]
        return self.query(sqlcmds.SQL_CMDS['plugins_Email'] % (username,))

    security.declarePrivate('sqlAuthUser')

    def sqlAuthUser(self, username, password):
        """Retrieve a user."""
        username, password = clearnasties(username, password)
        return self.query(sqlcmds.SQL_CMDS['plugins_User'] % (username,
                                                              password))

    security.declarePrivate('sqlUpdatePassword')

    def sqlUpdatePassword(self, uid, password):
        """Retrieve a user and password."""
        q = sqlcmds.SQL_CMDS['plugins_update_password'] % (
            password, uid)
        db2 = component.getUtility(IDatabase, 'db2')
        db2.query(self, q, debug=True)
        return self.query(q, debug=True)

    security.declarePrivate('sqlUpdateEmail')

    def sqlUpdateEmail(self, username, email):
        """Change the user's email."""
        db2 = component.getUtility(IDatabase, 'db2')
        nalids = self.query(sqlcmds.SQL_CMDS['plugins_update_email'] % (
                username)).tuples()
        if len(nalids) == 0:
            # At least one match must have been found
            return

        if len(nalids) > 1:
            logger.info("usermanagement plugin update email: "
                        "found more user accounts for %s" % (username))

        for record in nalids:
            q = sqlcmds.SQL_CMDS['plugins_update_email2'] % (email, record[0])
            db2.query(self, q, debug=True)
            self.query(q, debug=True)

    security.declarePrivate('sqlLoadAllUsers')

    def sqlLoadAllUsers(self):
        """Retrieve all users."""
        return self.query(sqlcmds.SQL_CMDS['plugins_load_users'])

    security.declarePrivate('sqlSearchUsers')

    def sqlSearchUsers(self, name):
        """Retrieve all users."""
        return self.query(sqlcmds.SQL_CMDS['plugins_search_users'] % (
                clearnasties(name)[0].upper()))

    security.declarePrivate('sqlLoadUser')

    def sqlLoadUser(self, username):
        """Retrieve a user."""
        return self.query(sqlcmds.SQL_CMDS['plugins_load_user'] % (
                username))

classImplements(KNMPPasManager,
                IAuthenticationPlugin,
                IUserManagement,
                IPasswordSetCapability,
                IUserEnumerationPlugin,
                IPropertiesPlugin,
                IMutablePropertiesPlugin)

InitializeClass(KNMPPasManager)
