from setuptools import setup, find_packages
import os

version = '1.0'

setup(name='knmp.ldapimport',
      version=version,
      description="Import new users to LDAP",
      long_description=open("README.txt").read() + "\n" +
                       open(os.path.join("docs", "HISTORY.txt")).read(),
      classifiers=[
        "Programming Language :: Python",
        ],
      keywords='',
      author='',
      author_email='',
      url='http://svn.plone.org/svn/collective/',
      license='GPL',
      packages=find_packages(exclude=['ez_setup']),
      namespace_packages=['knmp'],
      include_package_data=True,
      zip_safe=False,
      install_requires=[
          "setuptools",
          "z3c.form",
          "five.grok",
          "plone.app.z3cform",
          "plone.namedfile",
          "plone.formwidget.namedfile",
          "plone.directives.form",
          "Products.statusmessages",
          "Products.CMFCore",
          "Products.GenericSetup",
          "Products.PloneLDAP",
          "Plone",
          "Zope2",
      ],
      )
