import csv
from smtplib import SMTPRecipientsRefused
import ldap.modlist
from cStringIO import StringIO
import logging
from Acquisition import aq_inner
from five import grok
from plone.namedfile.field import NamedFile
from plone.directives import form
from z3c.form.button import buttonAndHandler
from Products.statusmessages.interfaces import IStatusMessage
from Products.CMFCore.interfaces import ISiteRoot
from Products.CMFCore.utils import getToolByName

log = logging.getLogger(__name__)


class IUserData(form.Schema):
    users = NamedFile(
            title = u"CSV user",
            required = True)



class UserDataDialect(csv.Dialect):
    delimiter = ";"
    skipinitialspace = True
    quotechar = '"'
    doublequote = True
    lineterminator = '\r\n'
    quoting = csv.QUOTE_MINIMAL


class UploadUsersForm(form.SchemaForm):
    grok.context(ISiteRoot)
    grok.name("upload-users")
    grok.require("cmf.ManagePortal")

    ignoreContext = True
    schema = IUserData
    label = "Upload gebruikers gegevens"
    description = "Hier komt de description"
    default_fieldset_label = None

# KNMPNR3;ADR013;ADR014;ADR010;ADR063;ABO037;ADE009;ABO018
# VOORLETT = ADR013
# TUSSENV = ADR014
# ACHTERNAAM = ADR010
# KNMPNR = KNMPNR3
# E-MAILADRES = ADE009

    def extract(self, input):
        reader=csv.DictReader(input, dialect=UserDataDialect)
        for row in reader:
            prefix=row["ADR013"].decode("cp850")
            inter=row["ADR014"].decode("cp850")
            surname=row["ADR010"].decode("cp850")
            yield { "uid": row["KNMPNR3"],
                    "fullname": u" ".join(filter(None, [prefix, inter, surname])),
                    "surname": surname,
                    "email": row["ADE009"]}


    def assertUserInLdap(self, user):
        membership = getToolByName(self.context, 'portal_membership')
        regtool = getToolByName(self.context, 'portal_registration')
        luf=aq_inner(self.context).acl_users.ldap.acl_users
        result=luf._delegate.search(luf.users_base, luf.users_scope,
                "(&(objectClass=inetOrgPerson)(uid=%s))" % user["uid"],
                bind_dn=luf._binduid,
                bind_pwd=luf._bindpwd)
        if result["size"]:
            log.debug("User %s already in LDAP, skipping", user["uid"])
            return {}
        log.info("Adding user %s to LDAP" % user["uid"])

        connection=luf._delegate.connect(bind_dn=luf._binduid, bind_pwd=luf._bindpwd)
        dn="uid=%s,ou=People,o=knmp" % ldap.dn.escape_dn_chars(user["uid"])
        entries={
            "objectClass": [ "inetOrgPerson", "uidObject"],
            "uid": [user["uid"]],
            "cn": [user["fullname"].encode("utf-8")],
            "sn": [user["surname"].encode("utf-8")],
            "userPassword": ["\xff\xff\xff\xff"],
            }
        if user.get("email"):
            entries["mail"]=[user["email"]]
        else:
            entries["mail"]=["{0}@{1}".format(user["uid"], 'pw.nl')]
        modlist=ldap.modlist.addModlist(entries)
        try:
            connection.add_s(dn, modlist)
        except:
            log.error("LDAP error adding user %s", user["uid"])
            return {}
        else:
            if not user.get("email").strip():
                member = membership.getMemberById(user['uid'])
                secret_code = regtool.getPassword(4)
                member.setMemberProperties({'description': secret_code})
                entries['secret_code'] = secret_code

        return entries


    def activate_users(self, ldap_entries):
        """ Activate a user based on user_id """
        output = []
        propstool = getToolByName(self.context, 'portal_properties')
        urltool = getToolByName(self.context, 'portal_url')
        portal = urltool.getPortalObject()
        for ldap_entry in ldap_entries:
            output.append('{0}:{1}'.format(
                ' '.join(ldap_entry['uid']), ldap_entry['secret_code']))
        mail_text = 'Voor de volgende gebruikers is een code gegenereerd:\n\n'
        mail_text += '\n'.join(output)
        subject = 'Gebruikers van code voorzien'
        m_to = propstool.site_properties.getProperty('helpdesk_email')
        m_from = portal.getProperty('email_from_address')
        host = getToolByName(self.context, 'MailHost')
        try:
            host.send(mail_text, m_to, m_from, subject=subject)
        except SMTPRecipientsRefused:
            # add logging if needed
            log.warn("Problem mailing")


    def expireUsers(self, valid_users):
        counter=0
        luf=aq_inner(self.context).acl_users.ldap.acl_users
        connection=luf._delegate.connect(bind_dn=luf._binduid, bind_pwd=luf._bindpwd)
        mid=connection.search(luf.users_base, luf.users_scope,
                "(&(objectClass=inetOrgPerson)(objectClass=uidObject))", ["uid"])
        result_type,result_list,result_msgid,result_serverctrls = connection.result3(mid,0,-1)
        while result_type and result_list:
            for (dn, info) in result_list:
                uid=info["uid"][0]
                if uid not in valid_users:
                    connection.delete_s(dn)
                    log.info("Deleted user %s", uid)
                    counter+=1
            result_type,result_list,result_msgid,result_serverctrls = connection.result3(mid,0,-1)
        return counter

    def send_activation_mails(self, ldap_entries):
        """ Send activation mails to the users """
        regtool = getToolByName(self.context, 'portal_registration')
        acl_users = getToolByName(self.context, 'acl_users')
        for ldap_entry in ldap_entries:
            email = ldap_entry['mail'][0]
            pw = regtool.generatePassword()
            # ... and set it on the member
            acl_users.userFolderEditUser(ldap_entry['uid'][0], pw,
                ('Member',), ())
            # push new_password on the request, for regtool.mailPassword
            self.context.REQUEST.form['new_password'] = pw
            # Now generate the mail
            regtool.mailPassword(email, self.request)

    @buttonAndHandler(u"Upload", name="upload")
    def handleUpload(self, action):
        flash=IStatusMessage(self.request).addStatusMessage
        data, errors=self.extractData()
        if errors:
            self.status="Verbeter de aangegeven fouten"
            return

        valid_users=set()
        new_users=[]
        no_email_users=[]
        for user in self.extract(StringIO(data["users"].data)):
            log.debug("Processing user %s", user["uid"])
            valid_users.add(user["uid"])
            ldap_entry = self.assertUserInLdap(user)
            if ldap_entry:
                if not user.get('email'):
                    no_email_users.append(ldap_entry)
                else:
                    new_users.append(ldap_entry)
        if new_users:
            self.send_activation_mails(new_users)
            flash("%d gebruikers zijn toegevoegd" % len(new_users), "success")
        if no_email_users:
            self.activate_users(no_email_users)
            flash("%d gebruikers zijn geregistreerd" % len(no_email_users), "success")
        else:
            flash("Geen nieuwe gebruikers gevonden", "notice")

        count=self.expireUsers(valid_users)
        if count:
            flash("%s gebruikers verwijderd" % count, "success")
        portal_url=aq_inner(self.context).absolute_url()
        self.request.response.redirect(portal_url)

