"""Common configuration constants
"""

PROJECTNAME = 'knmp.base'

ADD_PERMISSIONS = {
    # -*- extra stuff goes here -*-
    'Dossier': 'knmp.base: Add Dossier',
}
