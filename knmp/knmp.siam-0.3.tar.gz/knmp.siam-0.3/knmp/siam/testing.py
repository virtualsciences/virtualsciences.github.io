from plone.app.testing import PloneSandboxLayer
from plone.app.testing import applyProfile
from plone.app.testing import PLONE_FIXTURE
from plone.app.testing import IntegrationTesting
from plone.app.testing import FunctionalTesting

from plone.testing import z2

from zope.configuration import xmlconfig


class KnmpSiamLayer(PloneSandboxLayer):

    defaultBases = (PLONE_FIXTURE,)

    def setUpZope(self, app, configurationContext):
        # Load ZCML
        import knmp.siam
        xmlconfig.file(
            'configure.zcml',
            knmp.siam,
            context=configurationContext
        )

        # Install products that use an old-style initialize() function
        #z2.installProduct(app, 'Products.PloneFormGen')

#    def tearDownZope(self, app):
#        # Uninstall products installed above
#        z2.uninstallProduct(app, 'Products.PloneFormGen')


KNMP_SIAM_FIXTURE = KnmpSiamLayer()
KNMP_SIAM_INTEGRATION_TESTING = IntegrationTesting(
    bases=(KNMP_SIAM_FIXTURE,),
    name="KnmpSiamLayer:Integration"
)
KNMP_SIAM_FUNCTIONAL_TESTING = FunctionalTesting(
    bases=(KNMP_SIAM_FIXTURE, z2.ZSERVER_FIXTURE),
    name="KnmpSiamLayer:Functional"
)
