import unittest2 as unittest

import urlparse
import time
import base64

from plone.app.testing import ploneSite, quickInstallProduct
from knmp.siam.testing import KNMP_SIAM_INTEGRATION_TESTING
from knmp.siam import service

class DictObject(dict):
    def __getattr__(self, name):
        return self.__getitem__(name)


class DummyCurlClass(object):
    def __init__(self):
        DummyCurlModule._curls.append(self)
        self.opts = {}
        self.performed = 0

    def setopt(self, name, value):
        self.opts.setdefault(name, []).append(value)

    def perform(self):
        self.performed += 1
        self.opts[DummyCurlModule.WRITEFUNCTION][-1](
            DummyCurlModule.rets.pop(0))
    
    def close(self):
        pass


class DummyCurlModule(object):
    URL = 0
    WRITEFUNCTION = 1
    SSL_VERIFYHOST = 2
    SSL_VERIFYPEER = 3

    Curl = DummyCurlClass
    _curls = []
    rets = []
    redirects = []
    portalMessages = []


def physicalPathToURL(path):
    return 'http://localhost:8080/%s' % ('/'.join(path),)

def redirect(url):
    DummyCurlModule.redirects.append(url)

def addPortalMessage(msg):
    DummyCurlModule.portalMessages.append(msg)


class TestPAS(unittest.TestCase):
    layer = KNMP_SIAM_INTEGRATION_TESTING

    def setUp(self):
        self.org_pycurl = service.pycurl
        pycurl = service.pycurl = self.pycurl = DummyCurlModule
        pycurl._curls = []
        pycurl.rets = []
        pycurl.redirects = []
        pycurl.portalMessages = []

        #with ploneSite() as portal:
        #    quickInstallProduct(portal, 'knmp.siam')

        self.plugin = service.KnmpSIAMService(
            id='foo',
            title='Foo',
            SIAM_URL='https://siam.myhost.com',
            shared_secret='shared secret',
            a_select_server='aselect.server',
            app_id='APPID',
            validate_SSL=False,
        )

        response = DictObject([
            ('redirect', redirect),
        ])
        self.plugin.REQUEST = DictObject([
            ('SESSION', DictObject()),
            ('HTTP_REFERER', 'http://localhost/secret'),
            ('physicalPathToURL', physicalPathToURL),
            ('RESPONSE', response),
        ])
        self.plugin.plone_utils = DictObject([
            ('addPortalMessage', addPortalMessage),
        ])

    def tearDown(self):
        service.pycurl = self.org_pycurl

    def test_login(self):
        self.pycurl.rets = [
            'result_code=0000&rid=1234&as_url=http://www.foo.bar'
            '&a-select-server=foobar',
        ]
        self.plugin.login()

        # check auth url and opts
        self.assertEquals(len(self.pycurl._curls), 1)
        curl = self.pycurl._curls[0]
        authurl = curl.opts[self.pycurl.URL][0]
        url, data = authurl.split('?')
        self.assertEquals(url, self.plugin.SIAM_URL)
        getvars = urlparse.parse_qs(data)
        self.assertEquals(getvars['request'], ['authenticate'])
        # see physicalPathToURL above
        self.assertEquals(
            getvars['app_url'], ['http://localhost:8080/foo/logged_in'])
        self.assertEquals(
            getvars['a-select-server'], [self.plugin.a_select_server])
        self.assertEquals(getvars['app_id'], [self.plugin.app_id])
        self.assertEquals(
            getvars['shared_secret'], [self.plugin.shared_secret])

        # check redirect url
        self.assertEquals(len(self.pycurl.redirects), 1)
        redirect = self.pycurl.redirects.pop()
        url, data = redirect.split('?', 1)
        self.assertEquals(url, 'http://www.foo.bar')

        # check redirect url vars
        getvars = urlparse.parse_qs(data)
        keys = getvars.keys()
        keys.sort()
        self.assertEquals(keys, ['a-select-server', 'rid'])
        self.assertEquals(getvars['rid'], ['1234'])
        self.assertEquals(getvars['a-select-server'], ['foobar'])

    def test_logged_in(self):
        self.plugin.REQUEST['aselect_credentials'] = 'encoded-secret'
        self.plugin.REQUEST['rid'] = '1234'
        self.plugin.REQUEST['a-select-server'] = 'aselect.server'
        self.plugin.REQUEST['SESSION']['__knmp_siam_referer'] = (
            'http://www.foo.bar')

        exptime = int(time.time() + 1000)
        attributes = base64.encodestring('foo=bar')
        self.pycurl.rets.append((
            'rid=1234&app_id=APPID&uid=0011&app_level=10&tgt_exp_time=%s&'
            'authsp=auth.sp&authsp_level=10&asp=ldap&asp_level=10&'
            'attributes=%s&result_code=0000'
        ) % (exptime, attributes))

        self.plugin.logged_in()
