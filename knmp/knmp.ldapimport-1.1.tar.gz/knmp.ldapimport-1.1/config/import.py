#!/usr/bin/python

import ldap
import ldap.dn
import ldap.filter
import ldap.modlist
import csv


LDAP_URI = "ldapi:///"
BIND_DN = "cn=admin,o=knmp"
BIND_PW = "secret"
BASE_DN = "ou=People,o=knmp"

dummy = { "uid": "123123",
          "email": "j.vloothuis@knmp.nl",
          "fullname": "Jeroen Vloothuis",
          "surname": "Vloothuis",
        }


ldap_con = ldap.initialize(LDAP_URI)
ldap_con.bind_s(BIND_DN, BIND_PW)

for user in [dummy]:
    current=ldap_con.search_s(BASE_DN, ldap.SCOPE_ONELEVEL,
            ldap.filter.filter_format("uid=%s", [user["uid"]]))
    if current:
        print "Uid %s already exists, skipping" % user["uid"]
        continue
    
    dn="uid=%s,ou=People,o=knmp" % ldap.dn.escape_dn_chars(user["uid"])
    entries={
        "objectClass": [ "inetOrgPerson", "uidObject"],
        "uid": [user["uid"]],
        "cn": [user["fullname"]],
        "sn": [user["surname"]],
        "userPassword": ["\xff\xff\xff\xff"],
        }
    if user.get("email"):
        entries["mail"]=[user["email"]]
    modlist=ldap.modlist.addModlist(entries)
    ldap_con.add_s(dn, modlist)
    print "Added uid %s" % user["uid"]
