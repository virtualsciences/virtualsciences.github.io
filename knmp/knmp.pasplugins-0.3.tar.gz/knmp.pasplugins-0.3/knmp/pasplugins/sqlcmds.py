# -*- coding: utf-8 -*-
THESAURUSNUMMER = 524
THESAURUSTAAL = "NL"
vars = {'tnr': THESAURUSNUMMER, 'ttaal': THESAURUSTAAL}
DATABASE_ENCODING = "iso-8859-1"
SQL_CMDS = {\
'plugins_NAL':
"""        SELECT userid AS fullname
           FROM administratie.users
           WHERE userid='%s'""",
'plugins_Email':
"""        SELECT nwademl AS email
           FROM administratie.nwapf, administratie.wuspf
           WHERE wuusid='%s' AND wunanwnr=nanwnr""",
'plugins_User':
"""        SELECT userid AS username
           FROM administratie.users
           WHERE userid='%s' AND password='%s'""",
'plugins_update_password':
"""        UPDATE administratie.users SET password='%s' WHERE userid='%s'
""",
'plugins_update_email':
"""        SELECT wunanwnr
           FROM administratie.wuspf
           WHERE wuusid='%s'""",
'plugins_update_email2':
"""        UPDATE administratie.nwapf SET nwademl='%s' WHERE nanwnr=%s""",
'plugings_load_users':
"""        SELECT userid AS username
           FROM administratie.users
""",
'plugins_search_users':
"""        SELECT userid AS username
           FROM administratie.users
           WHERE UPPER(userid) LIKE '%s%%'
""",
'plugins_load_user':
"""        SELECT userid AS username
           FROM administratie.users
           WHERE userid='%s'
""",
}
