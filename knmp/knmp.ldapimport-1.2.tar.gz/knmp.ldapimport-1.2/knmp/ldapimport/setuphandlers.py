import logging
import ldap
from Products.PloneLDAP.factory import manage_addPloneLDAPMultiPlugin
from Products.PluggableAuthService.interfaces import plugins
from Products.PlonePAS.interfaces import plugins as plonepas

log = logging.getLogger(__name__)

def setupVarious(context):
    if context.readDataFile("knmp.ldapimport.txt") is None:
        return

    site=context.getSite()
    setupLdap(site)


ACTIVE_INTERFACES = [
        plugins.IAuthenticationPlugin,
        plugins.ICredentialsResetPlugin,
        plugins.IPropertiesPlugin,
        plugins.IRoleEnumerationPlugin,
        plugins.IRolesPlugin,
        plugins.IUserAdderPlugin,
        plugins.IUserEnumerationPlugin,
        plonepas.IUserManagement,
        ]

LDAP_SERVER_IP = "10.14.8.132"
# LDAP_SERVER_IP = "127.0.0.1"

def setupLdap(site):
    pas=site.acl_users
    if "ldap" not in pas.objectIds():
        log.info("Adding LDAP plugin")
        manage_addPloneLDAPMultiPlugin(
                pas,
                "ldap",
                "KNMP LDAP server",
                LDAP_SERVER_IP,             # LDAP server
                "mail",                     # login attribute
                "uid",                      # uid attribute
                "ou=People,o=knmp",         # user base DN
                ldap.SCOPE_ONELEVEL,        # User search scope
                ["Member", "Anonymous"],    # User roles
                "ou=Groups,o=knmp",         # group base DN
                ldap.SCOPE_ONELEVEL,        # Group search scope
                "cn=admin,o=knmp",          # Bind DN
                "secret",                   # Bind password
                rdn_attr="uid",             # RDN attribute
                local_groups=True,          # Local groups only (no LDAP groups)
                )
        luf=pas.ldap.acl_users
        luf._user_objclasses=luf.u_classes=["inetOrgPerson", "uidObject"]
        luf._ldapschema["mail"]["friendly_name"]="E-mail adres"
        luf._ldapschema["mail"]["public_name"]="email"

    for iface in ACTIVE_INTERFACES:
        ids=pas.plugins.listPluginIds(iface)
        if "ldap" not in ids:
            log.info("Activating interface %s for LDAP", iface.__name__)
            pas.plugins.activatePlugin(iface, "ldap")
            for i in range(len(ids)):
                pas.plugins.movePluginsUp(iface, ["ldap"])

