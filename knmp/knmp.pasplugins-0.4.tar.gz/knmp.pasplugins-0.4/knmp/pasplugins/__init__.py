from Products.PluggableAuthService import registerMultiPlugin
from AccessControl.Permissions import add_user_folders
from knmp.pasplugins import plugins


registerMultiPlugin(plugins.KNMPPasManager.meta_type)


def initialize(context):
    # Register the plug-in with PAS
    context.registerClass(plugins.KNMPPasManager,
                          permission=add_user_folders,
                          constructors=(
                              plugins.manage_addKNMPPasManagerForm,
                              plugins.manage_addKNMPPasManager),
                          visibility=None,
                          icon='zmi/zindex.gif')
