from setuptools import setup, find_packages
import os

version = '0.1.0'

setup(name='knmp.base',
      version=version,
      description="A policy for Plone 4.0",
      long_description=open("README.txt").read() + "\n" +
                       open(os.path.join("docs", "HISTORY.txt")).read(),
      # Get more strings from http://www.python.org/pypi?%3Aaction=list_classifiers
      classifiers=[
        "Programming Language :: Python",
        "Topic :: Software Development :: Libraries :: Python Modules",
        ],
      keywords='web zope plone theme xdv knmp',
      author='Pareto',
      author_email='info@pareto.nl',
      url='http://pareto.nl',
      license='Proprietary',
      packages=find_packages(exclude=['ez_setup']),
      namespace_packages=['knmp'],
      include_package_data=True,
      zip_safe=True,
      install_requires=[
          'setuptools',
          'Plone',
          'Pillow',
          # 'Products.Ploneboard',
          'Products.PloneFormGen',
          'collective.uploadify',
          'Products.Collage',
          'collective.collage.portlets',
          'collective.carousel', # (grensgeval, stukje template, stukje visueel)
          'collective.portlet.feedmixer',
          # Dirty product using jquery ui badly
          # 'collective.idashboard',
          'pipbox.portlet.popform',
          'Products.feedfeeder',
          'collective.twitterportlet',
          'collective.googleanalytics',
          'collective.sharerizer',
          'collective.ads',
      ],
      entry_points="""
      # -*- Entry points: -*-
      """,
      )
