# See:
# http://plone.org/documentation/manual/developer-manual/indexing-and-searching/custom-indexing-strategies
from plone.indexer.decorator import indexer
from Products.ATContentTypes.interface import IATNewsItem, IATEvent, IATFile

def categories(obj, **kwargs):
    field = obj.getField('categories')
    if field is not None:
        return field.getAccessor(obj)()

@indexer(IATNewsItem)
def news_categories(object, **kwargs):
    return categories(object)

@indexer(IATEvent)
def event_categories(object, **kwargs):
    return categories(object)

@indexer(IATFile)
def file_categories(object, **kwargs):
    return categories(object)
