from Products.CMFCore.utils import getToolByName
from Products.CMFPlone.utils import _createObjectByType

from knmp.nl.config import KNMP_PROPERTIES

def setupVarious(context):

    # Ordinarily, GenericSetup handlers check for the existence of XML files.
    # Here, we are not parsing an XML file, but we use this text file as a
    # flag to check that we actually meant for this import step to be run.
    # The file is found in profiles/default.

    if context.readDataFile('knmp.nl_various.txt') is None:
        return

    # Add additional setup code here
    portal = context.getSite()
    logger = context.getLogger('knmp.nl')

    # Remove the default Plone content and put our stuff in place. We
    # will first clear out all the default Plone content.
    if 'Members' in portal.contentIds():
        portal.manage_delObjects(ids=portal.contentIds())

    if 'afbeeldingen' not in portal.contentIds() :
        # Add the "hidden from navigation" content containers.
        a = create_content(portal,
                           'Folder',
                           'afbeeldingen',
                           'Afbeeldingen')
        a.setLayout('atct_album_view')
        a.reindexObject()
    if 'verzamelingen' not in portal.contentIds() :
        # Add the "hidden from navigation" content containers.
        v = create_content(portal,
                           'Folder',
                           'verzamelingen',
                           'Verzamelingen')
        v.reindexObject()
        vh = create_content(v,
                           'Folder',
                           'hoofdmappen',
                           'Hoofdmappen')
        vh.reindexObject()

    # Add properties
    add_properties(portal, logger)

    # Global nav
    for n in [('zorgverlening-medicijnen', 'zorgverlening & medicijnen'),
              ('organisatie-regelgeving', 'organisatie & regelgeving'),
              ('samenwerken-kennis-delen', 'samenwerken & kennis delen'),
              ('opleiding-registratie', 'opleiding & registratie'),
              ('producten-diensten', 'producten & diensten'),
              ('nieuws', 'nieuws'),
              ('evenementen', 'evenementen'),
              ('dossiers', 'dossiers'),
              ('over-knmp', 'over KNMP'),
              ('helpdesk', 'helpdesk'),
              ('afbeeldingen', 'afbeeldingen'),
              ('documenten', 'documenten'),
              ]:
        if n[0] not in portal.contentIds():
            # Setup some test content to use for styling purposes, starting with hidden
            # container to rule them all.
            f = create_content(portal, 'Folder', n[0], n[1])

            f.reindexObject()

            if n[0] in ['zorgverlening-medicijnen', 'organisatie-regelgeving',
                        'samenwerken-kennis-delen', 'opleiding-registratie',
                        'producten-diensten']:

                # create topic
                ft = create_content(vh, 'Topic', n[0], n[1])
                ft_l = ft.addCriterion('path', 'ATPathCriterion')
                ft_l.setValue(f.UID())
                ft_s = ft.addCriterion('review_state', 'ATSimpleStringCriterion')
                ft_s.setValue('published')
                ft.addCriterion('created','ATSortCriterion')
                ft.setSortCriterion('effective', True)
                ft.reindexObject()

                ff = create_content(f, 'Folder', 'folder', 'Folder')
                ff.reindexObject()
                for i in range(3):
                    d = create_content(ff,
                                       'Document',
                                       'document-%s' % i,
                                       'Document',
                                       description= i == 1 and '''
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas at enim
eget neque laoreet viverra. Aenean dapibus mauris vitae mauris aliquet a
venenatis dui auctor. Vestibulum viverra aliquam lectus nec hendrerit?
                                       ''' or '',
                                       text='''
<h2>Lorem ipsum dolor</h2>
<h3>Lorem ipsum dolor</h3>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas at enim
eget neque laoreet viverra. Aenean dapibus mauris vitae mauris aliquet a
venenatis dui auctor. Vestibulum viverra aliquam lectus nec hendrerit?</p>
<h2>Lorem ipsum dolor</h2>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas at enim
eget neque laoreet viverra. Aenean dapibus mauris vitae mauris aliquet a
venenatis dui auctor. Vestibulum viverra aliquam lectus nec hendrerit?</p>
<h3>Lorem ipsum dolor</h3>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas at enim
eget neque laoreet viverra. Aenean dapibus mauris vitae mauris aliquet a
venenatis dui auctor. Vestibulum viverra aliquam lectus nec hendrerit?</p>
<ul>
<li>Lorem ipsum dolor</li>
<li>Lorem ipsum dolor</li>
<li>Lorem ipsum dolor</li>
</ul>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas at enim
eget neque laoreet viverra. Aenean dapibus mauris vitae mauris aliquet a
venenatis dui auctor. Vestibulum viverra aliquam lectus nec hendrerit?</p>
<ol>
<li>Lorem ipsum dolor</li>
<li>Lorem ipsum dolor</li>
<li>Lorem ipsum dolor</li>
</ol>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas at enim
eget neque laoreet viverra. Aenean dapibus mauris vitae mauris aliquet a
venenatis dui auctor. Vestibulum viverra aliquam lectus nec hendrerit?</p>
<dl>
<dt>Lorem ipsum dolor</dt>
<dd>Lorem ipsum dolor</dd>
<dt>Lorem ipsum dolor</dt>
<dd>Lorem ipsum dolor</dd>
</dl>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas at enim
eget neque laoreet viverra. Aenean dapibus mauris vitae mauris aliquet a
venenatis dui auctor. Vestibulum viverra aliquam lectus nec hendrerit?</p>
''')
                    d.reindexObject()

    if 'contact' not in portal.contentIds() :
        # Add the "hidden from navigation" content containers.
        c = create_content(portal,
                           'FormFolder',
                           'contact',
                           'contact')
        c.reindexObject()

    # Set some content to Exclude from navigation
    for folder in [portal['nieuws'],
                   portal['evenementen'],
                   portal['dossiers'],
                   portal['over-knmp'],
                   portal['helpdesk'],
                   portal['afbeeldingen'],
                   portal['verzamelingen'],
                   portal['documenten'],
                   portal['contact'],
                   ]:
        folder.setExcludeFromNav(True)
        folder.reindexObject()


def create_content(context, type, id, title, publish=True, *args, **kw):
    '''Create content within context and return the content item'''
    workflow_tool = getToolByName(context, 'portal_workflow')
    item=_createObjectByType(type, context, id=id, title=title, *args, **kw)
    item.reindexObject()
    if publish and type not in ['Image','File']:
        workflow_tool.doActionFor(item, 'publish')
    return item


def add_properties(portal, logger):
    """Add properties to portal_properties.knmp_properties.

    We do that in python code instead of in propertiestool.xml to
    avoid overwriting changes by the user.
    """
    portal_props = getToolByName(portal, 'portal_properties')
    props = portal_props.knmp_properties
    for propname, propdata in KNMP_PROPERTIES.items():
        if not props.hasProperty(propname):
            props._setProperty(propname, propdata['default'], propdata['type'])
            logger.info('Added property %r with default value %r',
                        propname, propdata['default'])

