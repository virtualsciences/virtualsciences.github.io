# Properties for portal_properties/knmp_properties
# Make a dict of dicts to list the properties.
KNMP_PROPERTIES = {}
# Maximum for auto_code of group:
# Maybe escaping of &
KNMP_PROPERTIES['categories'] = {
        'default': [
            'Zorgverlening & medicijnen|zorgverlening-medicijnen',
            'organisatie-regelgeving'],
        'type': 'lines'}

PROJECTNAME = 'knmp.nl'

ADD_PERMISSIONS = {
    'ContactPerson': 'knmp.nl: Add ContactPerson',
    'Dossier': 'knmp.nl: Add Dossier',
}
