from zope.interface import Interface
# -*- Additional Imports Here -*-


class IDossier(Interface):
    """Dossier content type"""

