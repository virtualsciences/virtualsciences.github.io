from zope.interface import Interface
# -*- Additional Imports Here -*-


class IContactPerson(Interface):
    """Contact Person"""

    # -*- schema definition goes here -*-
