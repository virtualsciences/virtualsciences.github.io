# -*- extra stuff goes here -*-
from contactperson import IContactPerson
from dossier import IDossier
