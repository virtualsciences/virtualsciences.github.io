jq(document).ready(function(){
	// Wrap the first word of the main sections in span.first-word
	var heading = jq([ "zorgverlening & medicijnen", "organisatie & regelgeving", 
				       "samenwerken & kennis delen", "opleiding & registratie", 
					   "producten & diensten" ]);
    var sectionHeading = jq("#main-nav,#footer .portletHeader");
    heading.each(function() {
		sectionHeading.highlight(this, 'section-heading');
	});
	jq(".section-heading").firstWord('first-word');
	
	// Wrap input submit and buttons
	jq('input[type="submit"]').wrap('<div class="button" />')
});

