"""Definition of the Dossier content type
"""

from zope.interface import implements

from Products.Archetypes import atapi
from Products.CMFPlone.interfaces import INonStructuralFolder
from Products.Collage.content import Collage
from Products.Collage.interfaces import ICollage
from Products.Collage.content._collage import CollageSchema

from knmp.nl.interfaces import IDossier
from knmp.nl.config import PROJECTNAME
from knmp.nl import nlMessageFactory as _

DossierSchema = CollageSchema.copy() + atapi.Schema((

    atapi.TextField(
        'text',
        required=False,
        searchable=True,
        storage=atapi.AttributeStorage(),
        validators = ('isTidyHtmlWithCleanup',),
        default_output_type = 'text/x-html-safe',
        widget=atapi.RichWidget(
            label = _(u'label_body_text',
                      default=u'Body Text'),
            rows=25,
            allow_file_uploads=True,
            ),
        ),

))


class Dossier(Collage):
    """Dossier content type"""
    implements(ICollage, INonStructuralFolder, IDossier)

    meta_type = "Dossier"
    schema = DossierSchema

atapi.registerType(Dossier, PROJECTNAME)
