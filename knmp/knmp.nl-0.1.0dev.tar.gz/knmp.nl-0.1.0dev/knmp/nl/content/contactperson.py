"""Definition of the ContactPerson content type
"""

from zope.interface import implements

from Products.Archetypes import atapi
from Products.ATContentTypes.content import base
from Products.ATContentTypes.content import schemata

# -*- Message Factory Imported Here -*-

from knmp.nl.interfaces import IContactPerson
from knmp.nl.config import PROJECTNAME
from knmp.nl import nlMessageFactory as _

ContactPersonSchema = schemata.ATContentTypeSchema.copy() + atapi.Schema((

    # -*- Your Archetypes field definitions here ... -*-

    atapi.ImageField(
        'image',
        storage=atapi.AnnotationStorage(),
        widget=atapi.ImageWidget(
            label=_(u"New Field"),
            description=_(u"Field description"),
        ),
        required=True,
        validators=('isNonEmptyFile'),
    ),

))

schemata.finalizeATCTSchema(ContactPersonSchema, moveDiscussion=False)


class ContactPerson(base.ATCTContent):
    """Contact Person"""
    implements(IContactPerson)

    meta_type = "ContactPerson"
    schema = ContactPersonSchema

    # XXX Not sure if we need a __bobo_traverse__ like in ATNewsItem

atapi.registerType(ContactPerson, PROJECTNAME)
