from zope.interface import directlyProvides
from zope.schema.interfaces import IVocabularyFactory
from zope.schema.vocabulary import SimpleVocabulary
from zope.component import adapts
from zope.interface import implements
from Products.CMFCore.utils import getToolByName
from archetypes.schemaextender.interfaces import ISchemaExtender
from Products.ATContentTypes.interface import IATNewsItem, IATEvent, IATFile
# from knmp.nl.interfaces import IKNMPCategories
from Products.Archetypes import atapi
from archetypes.schemaextender.field import ExtensionField

def categoriesVocabularyFactory(context):
    """Vocabulary factory for currently published films
    """
    props = getToolByName(context, 'portal_properties')
    knmp_sheet = props.knmp_properties
    categories = knmp_sheet.getProperty('categories', [])
    items = []
    for cat in categories:
        title_term = cat.split('|')
        if len(title_term) == 1:
            title, term = title_term[0], title_term[0]
        else:
            title, term = title_term
        items.append((title, term))

    return SimpleVocabulary.fromItems(items)

directlyProvides(categoriesVocabularyFactory, IVocabularyFactory)

class CategoriesField(ExtensionField, atapi.LinesField):
    """A categories field """

class CategoriesExtender(object):
    implements(ISchemaExtender)

    _fields = [
        CategoriesField('categories',
            vocabulary_factory='knmp.nl.categories',
            schemata = "categorization",
            enforceVocabulary=1,
            multiValued=True,
            widget = atapi.MultiSelectionWidget(
                label="Select a category")),
            ]

    def __init__(self, context):
        self.context = context

    def getFields(self):
        return self._fields

# We need three extender classes here
# adapts(I1, I2, I3) does not work
# create one superclass interface does not work either

class NewsExtender(CategoriesExtender):
    adapts(IATNewsItem)

class EventExtender(CategoriesExtender):
    adapts(IATEvent)
class FileExtender(CategoriesExtender):
    adapts(IATFile)
