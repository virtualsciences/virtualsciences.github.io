from zope.interface import implements
from zope.component import getMultiAdapter

from Acquisition import aq_inner
from Products.Five import BrowserView

from knmp.nl.browser.interfaces import IKNMPView

_marker = []


class KNMPView(BrowserView):
    implements(IKNMPView)

    # Utility methods

    def getColumnsClass(self, view=None):
        """Determine whether a column should be shown. The left column is called
        plone.leftcolumn; the right column is called plone.rightcolumn.
        """
        context = aq_inner(self.context)
        plone_view = getMultiAdapter((context, self.request), name=u'plone')
        sl = plone_view.have_portlets('plone.leftcolumn', view=view);
        portal_state = getMultiAdapter((context, self.request), name=u'plone_portal_state')

        if not sl:
            # we don't have columns, thus content takes the whole width
            return "cell width-full position-0"
        elif sl and (portal_state.is_rtl()):
            # We have left column and we are in RTL language
            return "cell width-3:5 position-2:5"
        elif sl and (not portal_state.is_rtl()):
            # We have left column and we are in NOT RTL language
            return "cell width-3:5 position-0"