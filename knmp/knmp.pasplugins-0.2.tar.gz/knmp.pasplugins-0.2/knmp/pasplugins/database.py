import logging

from zope import interface
from plone.memoize import ram
from Shared.DC.ZRDB.Results import Results as OrigResults
from Products.CMFCore.utils import getToolByName

from knmp.pasplugins.interfaces import IDatabase
from knmp.pasplugins.sqlcmds import SQL_CMDS

#def _fetch_data_cachekey(method, self, context, name, arg=None):
    #return (name, arg)

logger = logging.getLogger('Z-Index Website')


def _fetch_data_cachekey(method, self, context, name, username=None):
    return (name, username)


def safestrip(val):
    """Removed all trailing spaces if value is a string object."""
    try:
        return val.rstrip().decode('latin1')
    except AttributeError:
        return val


class Results(object):

    def __init__(self, *args, **kwargs):
        self.results = OrigResults(*args, **kwargs)

    def tuples(self):
        """Return the data set as tuples without trailing white space."""
        data = self.results.tuples()
        return [map(safestrip, r) for r in data]

    def __iter__(self):
        data = []
        for record in self.results:
            item = {}
            for key in self.results.names():
                item[key.lower()] = safestrip(record[key])
            data.append(item)
        return data.__iter__()

    def __getitem__(self, index):
        return list(self)[index]


class DB(object):
    """This class provides access to the database."""

    interface.implements(IDatabase)

    _connection = 'db'

    def getConnection(self, context):
        """Get a connection with which queries can be executed."""
        try:
            db = getToolByName(context, self._connection)
        except AttributeError:

            class NullConnection(object):
                def query(self, q):
                    return ([], [])
            return NullConnection()
        return db()

    def query(self, context, q, debug=False):
        """Execute a query."""
        if debug:
            logger.info("Running query mysql: %s", q)
        try:
            return Results(self.getConnection(context).query(q, max_rows=0))
        except:
            logger.exception("Query error: %s", q)
            raise

    @ram.cache(_fetch_data_cachekey)
    def fetch_data(self, context, name, *args):
        #arg - user name
        #cache data
        query = SQL_CMDS[name]
        if args:
            query = query % args
        return self.query(context, query)


class DB2(DB):
    _connection = 'db2'

    def query(self, context, q, debug=False):
        """Execute a query."""
        if debug:
            logger.info("Running query odbc: %s", q)
        try:
            return Results(self.getConnection(context).query(q))
        except:
            logger.exception("Query error: %s", q)
            raise
