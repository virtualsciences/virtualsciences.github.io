import csv
from smtplib import SMTPRecipientsRefused
from cStringIO import StringIO
import logging
from Acquisition import aq_inner
from five import grok
from plone.namedfile.field import NamedFile
from plone.directives import form
from z3c.form.button import buttonAndHandler
from Products.statusmessages.interfaces import IStatusMessage
from Products.CMFCore.interfaces import ISiteRoot
from Products.CMFCore.utils import getToolByName

log = logging.getLogger(__name__)


class IUserData(form.Schema):
    users = NamedFile(
            title=u"CSV user",
            required=True)


class UserDataDialect(csv.Dialect):
    delimiter = ";"
    skipinitialspace = True
    quotechar = '"'
    doublequote = True
    lineterminator = '\r\n'
    quoting = csv.QUOTE_MINIMAL


class UploadUsersForm(form.SchemaForm):
    grok.context(ISiteRoot)
    grok.name("upload-plone-users")
    grok.require("cmf.ManagePortal")

    ignoreContext = True
    schema = IUserData
    label = "Upload Plone gebruikers gegevens"
    description = "Voeg Plone gebruikers toe of pas ze aan."
    default_fieldset_label = None

# KNMPNR3;ADR013;ADR014;ADR010;ADR063;ABO037;ADE009;ABO018
# VOORLETT = ADR013
# TUSSENV = ADR014
# ACHTERNAAM = ADR010
# KNMPNR = KNMPNR3
# E-MAILADRES = ADE009

    def extract(self, input):
        reader = csv.DictReader(input, dialect=UserDataDialect)
        for row in reader:
            prefix = row["ADR013"].decode("cp850")
            inter = row["ADR014"].decode("cp850")
            surname = row["ADR010"].decode("cp850")
            yield {"uid": row["KNMPNR3"],
                   "fullname": u" ".join(
                       filter(None, [prefix, inter, surname])),
                   "surname": surname,
                   "email": row["ADE009"]}

    def activate_users(self, ldap_entries):
        """ Activate a user based on user_id """
        output = []
        log.warn("Trying activate_users with: {0}".format(ldap_entries))
        return

        propstool = getToolByName(self.context, 'portal_properties')
        urltool = getToolByName(self.context, 'portal_url')
        portal = urltool.getPortalObject()
        for ldap_entry in ldap_entries:
            output.append('{0}:{1}'.format(
                ' '.join(ldap_entry['uid']), ldap_entry['secret_code']))
        mail_text = 'Voor de volgende gebruikers is een code gegenereerd:\n\n'
        mail_text += '\n'.join(output)
        subject = 'Gebruikers van code voorzien'
        m_to = propstool.site_properties.getProperty('helpdesk_email')
        m_from = portal.getProperty('email_from_address')
        host = getToolByName(self.context, 'MailHost')
        try:
            host.send(mail_text, m_to, m_from, subject=subject)
        except SMTPRecipientsRefused:
            # add logging if needed
            log.warn("Problem mailing")

    def expireUsers(self, valid_users):
        """ Remove all users not in valid_users """
        return 0

    def send_activation_mails(self, entries):
        """ Send activation mails to the users """
        regtool = getToolByName(self.context, 'portal_registration')
        acl_users = getToolByName(self.context, 'acl_users')
        for entry in entries:
            email = entry['email']
            pw = regtool.generatePassword()
            try:
                # ... and set it on the member
                acl_users.userFolderEditUser(entry['uid'], pw,
                    ('Member',), ())
            except RuntimeError, msg:
            # push new_password on the request, for regtool.mailPassword
                log.warn("Activation mail not sent for: %s (msg: %s)" %
                                                (email, msg))
                continue
            self.context.REQUEST.form['new_password'] = pw
            # Now generate the mail
            try:
                regtool.mailPassword(entry['uid'], self.request)
            except ValueError, msg:
                log.warn("Activation mail not sent for: %s (msg: %s)" %
                                                (email, msg))
                continue

    def assert_user_in_source_user(self, user):
        """ """
        regtool = getToolByName(self.context, 'portal_registration')
        acl_users = getToolByName(self.context, 'acl_users')
        # add check if member is already there
        try:
            regtool.addMember(id=user['uid'],
                password='initialdummy',
                roles=('Member',),
                properties={
                    'fullname': user['fullname'],
                    'username': user['email'],
                    'email': user['email'],
                    })
            # XXX This is very specific, only for source_users !!
            # Change the user_name of the user to her e-mail (zodb specific)
            acl_users.source_users.updateUser(user['uid'], user['email'])
            log.info("Added user %s", user['uid'])
            return user
        except ValueError, msg:
            # if we skipped this user for a reason, tell the person
            log.warn("Skipped %s, reason: %s" % (user['uid'], msg))
            return {}

    @buttonAndHandler(u"Upload", name="upload")
    def handleUpload(self, action):
        flash = IStatusMessage(self.request).addStatusMessage
        data, errors = self.extractData()
        if errors:
            self.status = "Verbeter de aangegeven fouten"
            return

        valid_users = set()
        new_or_changed_users = []
        no_email_users = []
        for user in self.extract(StringIO(data["users"].data)):
            log.debug("Processing user %s", user["uid"])
            if not user.get('email'):
                no_email_users.append(user)
                continue
            valid_users.add(user["uid"])
            entry = self.assert_user_in_source_user(user)
            if entry:
                new_or_changed_users.append(entry)
        if new_or_changed_users:
            self.send_activation_mails(new_or_changed_users)
            flash("%d gebruikers zijn toegevoegd/gewijzigd" %
                            len(new_or_changed_users), "success")
        else:
            flash("Geen nieuwe gebruikers gevonden", "notice")

        if no_email_users:
            self.activate_users(no_email_users)
            flash("%d gebruikers zijn geregistreerd" %
                            len(no_email_users), "success")

        count = self.expireUsers(valid_users)
        if count:
            flash("%s gebruikers verwijderd" % count, "success")
        portal_url = aq_inner(self.context).absolute_url()
        self.request.response.redirect(portal_url)
